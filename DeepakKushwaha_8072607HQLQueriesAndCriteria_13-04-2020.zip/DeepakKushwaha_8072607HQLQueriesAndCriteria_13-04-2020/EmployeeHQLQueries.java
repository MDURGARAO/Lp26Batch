package com.virtusa.hibernate.entity;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class EmployeeHQLQueries {

	public static void main(String[] args) {

		Configuration configuration = new Configuration().configure();
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		session.beginTransaction();
		//Query query = session.createQuery("Select e from Employee as e");
		//Query query = session.createQuery("Select e from Employee as e where name ='Kapil' ");
		//Query query = session.createQuery("from Employee where name like 'K%' and  sal> 20000");
		//Query query = session.createQuery("select e.name from Employee e where name like 'K%' and  sal> 20000");
		//Query query = session.createQuery("select e.name, e.address from Employee e where name like 'K%' and  sal> 20000");
		//Query query = session.createQuery("select Min(sal), Avg(sal), Max(sal) from Employee e");
		//Query query = session.createQuery("update Employee set name = 'chandu' where id= 4");
		//Query query = session.createQuery("delete from Employee where id=4");
		Query query = session.createQuery("delete from Employee where id=:empid");
		query.setParameter("empid", new Scanner(System.in).nextInt());
		query.executeUpdate();
//		Query query = session.createQuery("select new Employee(e.name, e.address) from Employee e where name like 'K%' and  sal> 20000");
//		List<Employee> list = query.list();
		//list.stream().forEach(System.out::println);
//		for (Object[] objects : list) {
//			for (int i = 0; i < objects.length; i++) {
//				System.out.println(objects[i]+" ");
//			}
		
//		for (Employee employee : list) {
//			System.out.println(employee.getName()+" "+employee.getAddress());
//		}
		session.getTransaction().commit();
		session.close();
		
	}

}
