package com.virtusa.hibernate.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmployeeRunner {

	public static void main(String[] args) {

		Address address= new Address();

		address.setHouseNo(204);
		address.setCity("Delhi");
		address.setPincode(230087);
		Employee employee = new Employee();
		employee.setName("Manmohan");
		employee.setSal(21000);
		employee.setAddress(address);

		Configuration configuration = new Configuration().configure();
		SessionFactory factory =  configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(employee);
		transaction.commit();
		session.close();

	}

}
