package com.hibernate.practice.compositeMapping;
import java.io.Serializable;
import java.util.Objects;
 
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;
 
@Embeddable
public class Book implements Serializable {
 
    private static final long serialVersionUID = 1L;
 
    @Id
    @Column(name = "bk_name")
    private String bk_name;
 
    @Id
    @Column(name = "author_name")
    private String author_name;
 
    public Book() { }
 
    public Book(String book_name, String auth_name) {
        this.bk_name = book_name;
        this.author_name = auth_name;
    }
 
    public String getBk_name() {
        return bk_name;
    }
 
    public void setBk_name(String bk_name) {
        this.bk_name = bk_name;
    }
 
    public String getAuthor_name() {
        return author_name;
    }
 
    public void setAuthor_name(String author_name) {
        this.author_name = author_name;
    }
}
