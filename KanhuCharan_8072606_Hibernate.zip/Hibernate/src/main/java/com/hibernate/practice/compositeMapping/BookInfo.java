package com.hibernate.practice.compositeMapping;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
 
@Entity
@Table(name = "book_info")
@IdClass(Book.class)
public class BookInfo {
 
    @Column(name = "isbn")
    private String isbn;
 
    @Id
    @Column(name = "bk_name")
    private String bk_name;
 
    @Id
    @Column(name = "author_name")
    private String author_name;
 
    public BookInfo() { }
 
    public BookInfo(Book bkObj) { 
        bk_name = bkObj.getBk_name();
        author_name = bkObj.getAuthor_name();
    }
 
    @Id
    @AttributeOverrides(
            {
                @AttributeOverride(name = "bk_name",column = @Column(name="bk_name")),
                @AttributeOverride(name = "author_name", column = @Column(name="author_name"))
            }
    )
 
    public String getIsbn() {
        return isbn;
    }
 
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
}
