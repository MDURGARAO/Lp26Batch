package com.hibernate.association.one2one;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AppMain {

	
	public static void main(String[] args) {
		Configuration configuration=new Configuration();
  		configuration.configure("hibernate.cfg.xml");
  		SessionFactory buildSessionFactory= configuration.buildSessionFactory();
  		Session session=buildSessionFactory.openSession();
  		Transaction transaction=session.beginTransaction();
  		
			Book bookObj = new Book();
			bookObj.setTitle("Hibernate Made Easy");
			bookObj.setDescription("Simplified Data Persistence with Hibernate and JPA");
			bookObj.setPublishedDate(new Date());

			bookObj.setAuthor(new Author("Cameron Wallace McKenzie", "cameron.bckenzie@gmail.com"));

			
			session.save(bookObj);			

			
			transaction.commit();

				session.close();
			}
		
	}
