package com.hibernate.association.many2many;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AppMain {

	

	public static void main(String[] args) {		
		Configuration configuration=new Configuration();
  		configuration.configure("hibernate.cfg.xml");
  		SessionFactory buildSessionFactory= configuration.buildSessionFactory();
  		Session session=buildSessionFactory.openSession();
  		Transaction transaction=session.beginTransaction();
  		

			Meeting quaterlyMeet = new Meeting("Quaterly Status Meeting");
			Meeting weeklyMeet = new Meeting("Weekly Status Meeting");
			Meeting dailyMeet  = new Meeting("Daily Status Meeting");

			Employee empObj1 = new Employee("Happy", "Potter");
			empObj1.getMeetings().add(quaterlyMeet);
			empObj1.getMeetings().add(weeklyMeet);
			session.save(empObj1);

			Employee empObj2 = new Employee("Lucifer", "Morningstar");
			empObj2.getMeetings().add(quaterlyMeet);
			session.save(empObj2);

			Employee empObj3 = new Employee("April O'", "Neil");			
			empObj3.getMeetings().add(weeklyMeet);
			empObj3.getMeetings().add(dailyMeet);
			session.save(empObj3);

			
		    transaction.commit();

		
				session.close();
			}
		
	
}