package com.hibernate.association.one2many;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AppMain {
	public static void main(String[] args) {
	    Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory= configuration.buildSessionFactory();
		Session session=buildSessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
	

			Student studentObj = new Student("Java", "seeker",  "kanhucharan@gmail.com", "456767589");
			session.save(studentObj);

			MarksDetails marksObj1 = new MarksDetails("English", "100", "90",  "Pass");  
			marksObj1.setStudent(studentObj);  
			session.save(marksObj1);

			MarksDetails marksObj2 = new MarksDetails("Maths", "100", "99",  "Pass");  
			marksObj2.setStudent(studentObj);
			session.save(marksObj2);

			MarksDetails marksObj3 = new MarksDetails("Science", "100", "94",  "Pass");  
			marksObj3.setStudent(studentObj);
			session.save(marksObj3);

			
			transaction.commit();

				session.close();
			}
		}

