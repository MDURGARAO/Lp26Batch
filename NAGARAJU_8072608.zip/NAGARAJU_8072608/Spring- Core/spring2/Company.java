/**
 * 
 */
package com.virtusa.spring2;
public class Company {

	private int companyId;
	private String companyName;
	private String companyLocation;
	private int companyActiveClients;
	private Employee employee;
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyLocation() {
		return companyLocation;
	}
	public void setCompanyLocation(String companyLocation) {
		this.companyLocation = companyLocation;
	}
	public int getCompanyActiveClients() {
		return companyActiveClients;
	}
	public void setCompanyActiveClients(int companyActiveClients) {
		this.companyActiveClients = companyActiveClients;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", companyLocation="
				+ companyLocation + ", companyActiveClients=" + companyActiveClients + ", employee=" + employee + "]";
	}
	/**
	 * 
	 */
	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}
	
		
	
}

