/**
 * 
 */
package com.virusa.spring.main4;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring4.Employee;
public class PersonAndEmployeeMain {
	public static void main(String[] args) 
	{
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext( "spring-config4.xml");
//		Map<String, Person> beansOfType = applicationContext.getBeansOfType(Person.class);
//		System.out.println(beansOfType
		
		Employee employee5 = (Employee) applicationContext.getBean("employee1");
  System.out.println(employee5);	   	
	}
}
