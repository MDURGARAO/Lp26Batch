/**
 * 
 */
package com.virtusa.casestudy1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.virtusa.casestudy1.AppConfig;
import com.virtusa.casestudy1.Customer;

/**
 * @author Damodar Reddy10:06:50 AMApr 20, 2020
 * CaseStudy1Main.java
 */
public class CaseStudy1Main {
	
	public static void main(String[] args) {
		
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
		Customer customer = applicationContext.getBean(Customer.class);
		customer.verify();
	}

}
