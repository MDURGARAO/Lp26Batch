/**
 * 
 */
package com.virtusa.casestudy1;

import org.springframework.stereotype.Component;

/**
 * @author Damodar Reddy10:01:52 AMApr 20, 2020
 * Payment.java
 */
@Component
public class Payment {

	public void pay()
	{
		System.out.println("Do payment");
	}
}
