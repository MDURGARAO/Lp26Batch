/**
 * 
 */
package com.virtusa.spring3;

import java.util.List;

public class Company {

	private int companyId;
	private String companyName;
	private String companyLocation;
	private int companyActiveClients;
	private List<Employee> employeeList;
	
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyLocation() {
		return companyLocation;
	}
	public void setCompanyLocation(String companyLocation) {
		this.companyLocation = companyLocation;
	}
	public int getCompanyActiveClients() {
		return companyActiveClients;
	}
	public void setCompanyActiveClients(int companyActiveClients) {
		this.companyActiveClients = companyActiveClients;
	}
	
	
	public List<Employee> getEmployeeList() {
		return employeeList;
	}
	public void setEmployeeList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}
	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", companyLocation="
				+ companyLocation + ", companyActiveClients=" + companyActiveClients + ", employeeList=" + employeeList + "]";
	}
	/**
	 * 
	 */
	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}
	
		
	
}

