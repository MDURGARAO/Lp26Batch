/**
 * 
 */
package com.virtusa.spring;

/**
 * @author Damodar Reddy11:14:13 AMApr 17, 2020
 * Company.java
 */
public class Company {

	private int companyId;
	private String companyName;
	private String companyLocation;
	private int companyActiveClients;
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyLocation() {
		return companyLocation;
	}
	public void setCompanyLocation(String companyLocation) {
		this.companyLocation = companyLocation;
	}

	public int getCompanyActiveClients() {
		return companyActiveClients;
	}
	public void setCompanyActiveClients(int companyActiveClients) {
		this.companyActiveClients = companyActiveClients;
	}
	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", companyLocation="
				+ companyLocation + ", companyTotalClients=" + companyActiveClients + "]";
	}
	/**
	 * 
	 */
	public Company() {
		super();
	}
	
	
}
