/**
 * 
 */
package com.virusa.spring.main3;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.virtusa.spring3.Company;
public class CompanyAndEmployeeMain {
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring-config3.xml");
		Company com = applicationContext.getBean(Company.class,"comp");
		System.out.println(com);
	}
}
