/**
 * 
 */
package com.virtusa.spring4;

/**
 * @author Damodar Reddy12:25:45 PMApr 17, 2020
 * Person.java
 */
public class Person {
	String job;
     public void method1()
     {
    	 System.out.println("method1");
     }
	public String getJob() {
		return job;
	}

	@Override
	public String toString() {
		return "Person [job=" + job + "]";
	}

	public void setJob(String job) {
		this.job = job;
	}

	
	
}
