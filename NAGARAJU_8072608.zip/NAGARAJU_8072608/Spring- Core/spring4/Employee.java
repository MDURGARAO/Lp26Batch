/**
 * 
 */
package com.virtusa.spring4;

import org.springframework.context.annotation.Lazy;

/**
 * @author Damodar Reddy12:27:55 PMApr 17, 2020
 * Employee.java
 */

public class Employee {

	private int employeeId;
	private String name;

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @param employeeId
	 */
	public Employee(String name) {
		super();
		this.name = name;
		System.out.println("Argumented COnstructor");
	}

	public Employee() {
		super();
		System.out.println("In constructor");
		// TODO Auto-generated constructor stub
	}
}
