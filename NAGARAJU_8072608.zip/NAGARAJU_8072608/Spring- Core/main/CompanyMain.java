/**
 * 
 */
package com.virtusa.spring.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.Company;

/**
 * @author Damodar Reddy11:19:58 AMApr 17, 2020
 * CompanyMain.java
 */
public class CompanyMain {
	
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring-config.xml");
		Company company = applicationContext.getBean(Company.class,"company");
		System.out.println(company);
		
	}
}
