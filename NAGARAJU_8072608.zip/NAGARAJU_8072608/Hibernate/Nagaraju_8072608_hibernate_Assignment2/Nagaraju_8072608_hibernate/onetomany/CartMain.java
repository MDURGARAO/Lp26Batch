/**
 * 
 */
package com.virtusa.main.onetomany;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entity.onetomany.Cart1;
import com.virtusa.entity.onetomany.Items1;

/**
 * @author Damodar Reddy6:56:53 PMApr 9, 2020
 * CartMain.java
 */
public class CartMain {

	public static void main(String[] args) {
		Cart1 cart = new Cart1();
		cart.setName("MyCart1");
		
		Items1 item1 = new Items1("I10", 10, 1, cart);
		Items1 item2 = new Items1("I20", 20, 2, cart);
		Set<Items1> itemsSet = new HashSet<Items1>();
		itemsSet.add(item1); 
		itemsSet.add(item2);
		
		cart.setItems1(itemsSet);
		cart.setTotal(10*1 + 20*2);
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernatecfg2.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.save(cart);
		session.save(item1);
		session.save(item2);
		Transaction beginTransaction = session.beginTransaction();
		 beginTransaction.commit();
		session.close();
	}
}
