/**
 * 
 */
package com.virtusa.entity.onetoone;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Damodar Reddy12:15:18 PMApr 9, 2020
 * Laptop.java
 */
@Entity
@Table(name="Laptop")
public class Laptop {
	@Id
	private int laptopId;
	private String laptopName;
	/**
	 * @return the laptopId
	 */
	public int getLaptopId() {
		return laptopId;
	}
	/**
	 * @param laptopId the laptopId to set
	 */
	public void setLaptopId(int laptopId) {
		this.laptopId = laptopId;
	}
	/**
	 * @return the laptopName
	 */
	public String getLaptopName() {
		return laptopName;
	}
	/**
	 * @param laptopName the laptopName to set
	 */
	public void setLaptopName(String laptopName) {
		this.laptopName = laptopName;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Laptop [laptopId=" + laptopId + ", laptopName=" + laptopName + "]";
	}
	/**
	 * 
	 */
	public Laptop() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
