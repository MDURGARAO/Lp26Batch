/**
 * 
 */
package com.virtusa.main.onetoone;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entity.onetoone.Laptop;
import com.virtusa.entity.onetoone.User;

/**
 * @author Damodar Reddy12:18:06 PMApr 9, 2020
 * UserMain.java
 */
public class UserMain {

	public static void main(String[] args) {
		
		Laptop laptop = new Laptop();
		laptop.setLaptopId(55);
		laptop.setLaptopName("lenovo");
		User user = new User();
		user.setLaptop(laptop);
		user.setUserId(123);
		user.setUserName("Ngaraju");
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernatecfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.save(user);
		Transaction beginTransaction = session.beginTransaction();
		 beginTransaction.commit();
		session.close();

		
	}
}
