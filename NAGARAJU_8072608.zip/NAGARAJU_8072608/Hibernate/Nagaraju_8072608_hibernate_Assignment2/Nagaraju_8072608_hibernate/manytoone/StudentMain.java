/**
 * 
 */
package com.virtusa.main.manytoone;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entity.manytoone.Student;
import com.virtusa.entity.manytoone.University;

/**
 * @author Damodar Reddy7:28:56 PMApr 9, 2020
 * dc.java
 */
public class StudentMain {

	public static void main(String[] args) {
		Student student1 = new Student("Sam","us","Maths");
		Student student2 = new Student("raja", "eng", "Science");
		Student student3 = new Student("nag", "itly", "Physics");
		University university = new University("CAMBRIDGE", "ENGLAND");
		student1.setUniversity(university);
		student2.setUniversity(university);
		student3.setUniversity(university);
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernatecfg3.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.save(university);
		session.save(student1);
		session.save(student2);
		session.save(student3);
		Transaction beginTransaction = session.beginTransaction();
		 beginTransaction.commit();
		session.close();		
		
	}
}
