package com.virtusa.main;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.virtusa.entity.Employee;
import com.virtusa.entity.EmployeeAddress;

public class ComponentMapping
{
    public static void main(String args[])
    {
     
        
   
        EmployeeAddress address = new EmployeeAddress();
        address.setStreet("Tharamani");
        address.setCity("Chennai");
        address.setState("TamilNadu");
        Employee employee = new Employee();
        employee.setName("naga");
        employee.setAddress(address);
        Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(employee);
		transaction.commit();
		session.close();
    }
}