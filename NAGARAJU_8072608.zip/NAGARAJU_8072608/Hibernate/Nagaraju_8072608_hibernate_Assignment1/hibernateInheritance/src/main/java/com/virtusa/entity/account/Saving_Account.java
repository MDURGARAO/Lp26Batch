/**
 * 
 */
package com.virtusa.entity.account;

import javax.persistence.Entity;

/**
 * @author Damodar Reddy9:14:32 AMApr 9, 2020
 * Saving_Account.java
 */
@Entity
public class Saving_Account extends Bank_Account {
	
	private int interest;
	private int minBalance;
	/**
	 * @return the interest
	 */
	public int getInterest() {
		return interest;
	}
	/**
	 * @param interest the interest to set
	 */
	public void setInterest(int interest) {
		this.interest = interest;
	}
	/**
	 * @return the minBalance
	 */
	public int getMinBalance() {
		return minBalance;
	}
	/**
	 * @param minBalance the minBalance to set
	 */
	public void setMinBalance(int minBalance) {
		this.minBalance = minBalance;
	}
	/**
	 * 
	 */
	public Saving_Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Saving_Account [interest=" + interest + ", minBalance=" + minBalance + "]";
	}
	
	
}
