/**
 * 
 */
package com.virtusa.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.virtusa.entity.account.Current_Account;
import com.virtusa.entity.account.Saving_Account;

public class BankAccount_Main {

	public static void main(String[] args) {
		
		Saving_Account saving_Account = new Saving_Account();
		saving_Account.setBank_Id("ts12");
		saving_Account.setBank_Location("Guntur");
		saving_Account.setBank_Name("SBI");
		saving_Account.setIfsc_Code("sbi101sd");
		saving_Account.setInterest(10);
		saving_Account.setMinBalance(1000);
		
		Current_Account current_Account =new Current_Account();
		current_Account.setBank_Id("mp45");
		current_Account.setBank_Location("vizag");
		current_Account.setBank_Name("SBI");
		current_Account.setIfsc_Code("sbi102");
		current_Account.setMin_deposit(5000);
		current_Account.setMin_Transactions(5);
	
		Configuration configuration = new Configuration();
		configuration.configure("hibernatecfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		session.save(saving_Account);
		session.save(current_Account);
		t.commit();
		session.close();
	}
}
