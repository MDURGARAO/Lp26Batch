/**
 * 
 */
package com.virtusa.entity;
import javax.persistence.Embeddable;
import javax.persistence.Id;

@Embeddable
public class VechileOwner {

	@Id
	String ownerName;
	String ownerAddress;
	/**
	 * @return the ownerName
	 */
	public String getOwnerName() {
		return ownerName;
	}
	/**
	 * @param ownerName the ownerName to set
	 */
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	/**
	 * @return the ownerAddress
	 */
	public String getOwnerAddress() {
		return ownerAddress;
	}
	/**
	 * @param ownerAddress the ownerAddress to set
	 */
	public void setOwnerAddress(String ownerAddress) {
		this.ownerAddress = ownerAddress;
	}
	/**
	 * 
	 */
	public VechileOwner() {
		super();
		// TODO Auto-generated constructor stub
	}
	
		
}
