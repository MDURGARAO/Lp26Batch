/**
 * 
 */
package com.virtusa.entity;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author Damodar Reddy9:38:17 PMApr 8, 2020
 * Mobile.java
 */

@Entity
public class Vechile {

	@Id
	@Column(name="Numner")
	private String vechileNumner;

	@Column(name="vechileName")
	String vechileName;
	
	@Embedded
	VechileOwner vechileOwner;

	/**
	 * @return the vechileNumner
	 */
	public String getVechileNumner() {
		return vechileNumner;
	}

	/**
	 * @param vechileNumner the vechileNumner to set
	 */
	public void setVechileNumner(String vechileNumner) {
		this.vechileNumner = vechileNumner;
	}

	/**
	 * @return the vechileName
	 */
	public String getVechileName() {
		return vechileName;
	}

	/**
	 * @param vechileName the vechileName to set
	 */
	public void setVechileName(String vechileName) {
		this.vechileName = vechileName;
	}

	/**
	 * @return the vechileOwner
	 */
	public VechileOwner getVechileOwner() {
		return vechileOwner;
	}

	/**
	 * @param vechileOwner the vechileOwner to set
	 */
	public void setVechileOwner(VechileOwner vechileOwner) {
		this.vechileOwner = vechileOwner;
	}

	/**
	 * 
	 */
	public Vechile() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
