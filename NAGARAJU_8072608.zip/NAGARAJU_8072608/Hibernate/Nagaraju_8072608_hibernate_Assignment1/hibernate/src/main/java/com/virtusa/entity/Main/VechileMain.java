package com.virtusa.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entity.Vechile;
import com.virtusa.entity.VechileOwner;

public class VechileMain {
	public static void main(String[] args) {
		
		Vechile vechile = new Vechile();
		vechile.setVechileName("KTMBike");
		vechile.setVechileNumner("11");
		VechileOwner vechileOwner = new VechileOwner();
		vechileOwner.setOwnerAddress("1-2,hyd,sr nagar");
		vechileOwner.setOwnerName("nagaraju");
		vechile.setVechileOwner(vechileOwner);
		Configuration configuration = new Configuration();
		configuration.configure("hibernatecfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		session.save(vechile);
		t.commit();
		session.close();
		}
}
