package com.virtusa.advancejava;
import com.virtusa.corejava.*;
/**
 * Hello world!
 *
 */
public class AdvanceJava 
{
    public static void main( String[] args )
    {
		JavaBeginner .course();
        System.out.println( "Advance Java" );
    }
}
