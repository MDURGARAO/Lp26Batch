package com.virtusa.corejava;

/**
 * Hello world!
 *
 */
public class JavaBeginner 
{
    public static void course()
    {
        System.out.println( "Java Beginner" );
    }
}
