package com.virtusa.Entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Type;


@Entity
public class CustomerManyOne {

	@Id
	private int cusId;
	private double bill;
	private String name;
	@Type(type = "boolean")
	private boolean isNewCus;
	@ManyToOne( cascade = CascadeType.ALL)
	private AddressManyOne address;
	
	public CustomerManyOne(int cusId, double bill, String name, boolean isNewCus) {
		super();
		this.cusId = cusId;
		this.bill = bill;
		this.name = name;
		this.isNewCus = isNewCus;
		
	}

	public CustomerManyOne() {
	}

	public int getCusId() {
		return cusId;
	}

	public void setCusId(int cusId) {
		this.cusId = cusId;
	}

	public double getBill() {
		return bill;
	}

	public void setBill(double bill) {
		this.bill = bill;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isNewCus() {
		return isNewCus;
	}

	public void setNewCus(boolean isNewCus) {
		this.isNewCus = isNewCus;
	}
		
	public AddressManyOne getAddress() {
		return address;
	}

	public void setAddress(AddressManyOne address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [cusId=" + cusId + ", bill=" + bill + ", name=" + name + ", isNewCus=" + isNewCus
				+  "]";
	}
	
}
