package com.virtusa.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Type;

@Entity
public class AddressOne {

	@Id
	private int HouseRegNo;
	public int getHouseRegNo() {
		return HouseRegNo;
	}

	public void setHouseRegNo(int houseRegNo) {
		HouseRegNo = houseRegNo;
	}

	private int doorNo;
	private String street;
	private String city;
	@OneToOne(fetch = FetchType.LAZY)
	private CustomerOne customer;
	
	public CustomerOne getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerOne customer) {
		this.customer = customer;
	}

	public AddressOne(int doorNo, String street, String city) {
		super();
		this.doorNo = doorNo;
		this.street = street;
		this.city = city;
	}

	public AddressOne() {
	}

	public int getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address [doorNo=" + doorNo + ", street=" + street + ", city=" + city + "]";
	}
	
	
}
