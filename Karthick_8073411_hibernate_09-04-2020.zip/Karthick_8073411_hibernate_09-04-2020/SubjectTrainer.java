package com.virtusa.Entity;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@PrimaryKeyJoinColumn(name = "id")
public class SubjectTrainer extends Trainer {

	private String subject;
	private String session;
	
	public SubjectTrainer() {
	}

	public SubjectTrainer(String subject, String session) {
		super();
		this.subject = subject;
		this.session = session;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getSession() {
		return session;
	}

	public void setSession(String session) {
		this.session = session;
	}

	@Override
	public String toString() {
		return "SubjectTrainer [subject=" + subject + ", session=" + session + "]";
	}

}
