package com.virtusa.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AddressManyOne {

	@Id
	private int HouseRegNo;
	private int doorNo;
	private String street;
	private String city;

	public AddressManyOne(int doorNo, String street, String city) {
		super();
		this.doorNo = doorNo;
		this.street = street;
		this.city = city;
	}

	public int getHouseRegNo() {
		return HouseRegNo;
	}

	public void setHouseRegNo(int houseRegNo) {
		HouseRegNo = houseRegNo;
	}

	
	public AddressManyOne() {
	}

	public int getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "AddressOneMany [HouseRegNo=" + HouseRegNo + ", doorNo=" + doorNo + ", street=" + street + ", city="
				+ city + "]";
	}

		
}
