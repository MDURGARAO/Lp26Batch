package com.virtusa.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.Entity.Customer;
import com.virtusa.hibernate.association.Address;

public class CustomerMain {
	public static void main(String[] args) {
		Customer cus = new Customer(101, 1000, "Karthick", true, new Address(200, "BharathiyarStreet", "Chennai"));
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory = configuration.buildSessionFactory();
		Session session = buildSessionFactory.openSession();
		Transaction transaction = session.beginTransaction();		
		session.save(cus);
		Customer cus1 = session.get(Customer.class, 101);
		System.out.println(cus1);
		transaction.commit();
		session.close();
	}
}
