package com.virtusa.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.Entity.PhysicalTrainer;
import com.virtusa.Entity.SubjectTrainer;

public class TrainerMain {
	public static void main(String[] args) {
		PhysicalTrainer ptr = new PhysicalTrainer("Kabaddi","Thursday");
		ptr.setId(304);
		ptr.setName("Murugesh");
		SubjectTrainer str = new SubjectTrainer("Maths", "AN");
		str.setId(305);
		str.setName("Antony");
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory = configuration.buildSessionFactory();
		Session session = buildSessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(ptr);
		session.save(str);
		transaction.commit();
		session.close();
	}
}
