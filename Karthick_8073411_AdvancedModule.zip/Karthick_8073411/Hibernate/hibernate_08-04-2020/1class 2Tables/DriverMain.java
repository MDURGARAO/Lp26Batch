package com.virtusa.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.Entity.Driver;

public class DriverMain {
	public static void main(String[] args) {
		Driver dr = new Driver(101, "Ganesh", 20000, 3004, "Chennai", "Hydrabad");
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory = configuration.buildSessionFactory();
		Session session = buildSessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(dr);
		transaction.commit();
		session.close();
		}
}
