package com.virtusa.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Type;

@Entity
public class AddressOneMany {

	@Id
	private int regNo;
	private int doorNo;
	
	private String city;

	public AddressOneMany(int doorNo, String city) {
		super();
		this.doorNo = doorNo;
		this.city = city;
	}

	public int getHouseRegNo() {
		return regNo;
	}

	public void setHouseRegNo(int houseRegNo) {
		regNo = houseRegNo;
	}

	
	public AddressOneMany() {
	}

	public int getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}

	

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "AddressOneMany [HouseRegNo=" + regNo + ", doorNo=" + doorNo +  ", city="
				+ city + "]";
	}

		
}
