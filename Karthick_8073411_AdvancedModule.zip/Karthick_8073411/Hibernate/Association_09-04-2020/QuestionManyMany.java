package com.virtusa.Entity;

import java.util.List;  
import javax.persistence.*;    
    
@Entity  
public class QuestionManyMany {    
@Id  
@Column
private int id;    
private String qname;   
@ManyToMany(fetch = FetchType.LAZY)
@JoinTable
private List<AnswerManyMany> answers;  
  
public QuestionManyMany() {
	super();
	// TODO Auto-generated constructor stub
}

public QuestionManyMany(int id, String qname) {
	super();
	this.id = id;
	this.qname = qname;
}

public int getId() {  
    return id;  
}  

public void setId(int id) {  
    this.id = id;  
}  
public String getQname() {  
    return qname;  
}  
public void setQname(String qname) {  
    this.qname = qname;  
}  
public List<AnswerManyMany> getAnswers() {  
    return answers;  
}  
public void setAnswers(List<AnswerManyMany> answers) {  
    this.answers = answers;  
}

@Override
public String toString() {
	return "QuestionManyMany [id=" + id + ", qname=" + qname +  "]";
}      


}  
