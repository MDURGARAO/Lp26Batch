package com.virtusa.hibernate;

import java.util.List;

import javax.persistence.ParameterMode;
import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.procedure.ProcedureCall;

import com.virtusa.Entity.Customer;

public class CustomerCache {
	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory = configuration.buildSessionFactory();
		
		/***using secondary-cache***/
		Session session1 = buildSessionFactory.openSession();
		Transaction transaction1 = session1.beginTransaction();
		Customer cus1 = session1.get(Customer.class, 1003);
		cus1.setName("Mukesh");
		System.out.println(cus1);
		transaction1.commit();
		session1.close();
		Session session2 = buildSessionFactory.openSession();
		Transaction transaction2 = session2.beginTransaction();
		Customer cus2 = session2.get(Customer.class, 1003);
		cus2.setName("Mahesh");
		System.out.println(cus2);
		transaction2.commit();
		session2.close();
		
		/***named query***/
		Session session3 = buildSessionFactory.openSession();
		TypedQuery query = session3.getNamedQuery("findCustomerByName");
		query.setParameter("name","Priya");   
		List<Customer> cusList = query.getResultList();
		cusList.forEach(System.out::println);
		session3.close();
		
		/***calling pre-defined blocks of plsql***/
		Session session4 = buildSessionFactory.openSession();
		Query query1 = session4.createSQLQuery(                                             /***type 1***/
			    "CALL getCustomer(:param)")
			    .addEntity(Customer.class)
			    .setParameter("param", "Priya");
		List<Customer> cusList1 = query1.list();
		cusList1.forEach(System.out::println);
		
		ProcedureCall query2 = session4.createStoredProcedureCall("getCustomer", Customer.class);/***type 2***/
		query2.registerStoredProcedureParameter("param", String.class, ParameterMode.IN);
		query2.setParameter("param", "Priya");
		List<Customer> cusList2 = query2.getResultList();
		cusList2.forEach(System.out::println);
		session4.close();
	}
}
