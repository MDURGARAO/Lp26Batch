package com.virtusa.Entity;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;

import com.virtusa.hibernate.association.Address;

@Entity
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.TRANSACTIONAL)
@NamedQueries(  
	    {  
	        @NamedQuery(  
	        name = "findCustomerByName",  
	        query = "from Customer c where c.name = :name"  
	        )  
	    }  
	)  
@Table(name = "Customer")
public class Customer {

	@Id
	private int cusId;
	private double bill;
	private String name;
	@Type(type = "boolean")
	private boolean isNewCus;
	private Address address;
	
	
	public Customer(int cusId, double bill, String name, boolean isNewCus, Address address) {
		super();
		this.cusId = cusId;
		this.bill = bill;
		this.name = name;
		this.isNewCus = isNewCus;
		this.address = address;
	}

	public Customer(int cusId, double bill, Address address) {
		super();
		this.cusId = cusId;
		this.bill = bill;
		this.address = address;
	}

	public Customer() {
	}

	public int getCusId() {
		return cusId;
	}

	public void setCusId(int cusId) {
		this.cusId = cusId;
	}

	public double getBill() {
		return bill;
	}

	public void setBill(double bill) {
		this.bill = bill;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isNewCus() {
		return isNewCus;
	}

	public void setNewCus(boolean isNewCus) {
		this.isNewCus = isNewCus;
	}
		
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [cusId=" + cusId + ", bill=" + bill + ", name=" + name + ", isNewCus=" + isNewCus
				+ ", address=" + address + "]";
	}
	
}
