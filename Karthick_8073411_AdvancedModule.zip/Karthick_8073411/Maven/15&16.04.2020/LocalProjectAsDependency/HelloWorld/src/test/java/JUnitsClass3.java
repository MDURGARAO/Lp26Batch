package tests;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.apache.log4j.Logger;

public class JUnitsClass3 {

	@BeforeClass
	public static void before() {
		Logger logger = Logger.getLogger(JUnitsClass3 .class.getName());
		logger.info("before test");
		System.out.println("Before");
	}

	@Test
	public void test1() {
		Logger logger = Logger.getLogger(JUnitsClass3 .class.getName());
		logger.info("test");
		System.out.println("Hello World");
	}

	@AfterClass
	public static void after() {
		Logger logger = Logger.getLogger(JUnitsClass3 .class.getName());
		logger.info("after");
		System.out.println("After");
	}
}