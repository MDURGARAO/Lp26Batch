package com.hello;

import org.apache.log4j.Logger;

public class HelloWorld2{
public String hello(String name) {
return "Hello "+name;
}
}