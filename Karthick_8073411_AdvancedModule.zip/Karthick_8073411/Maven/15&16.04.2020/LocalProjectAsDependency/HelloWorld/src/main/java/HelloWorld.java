package com.hello;

import org.apache.log4j.Logger;

class HelloWorld{
 public static void main(String[] args) {
Logger logger = Logger.getLogger(HelloWorld.class.getName());
		logger.info("before main");
System.out.println("HelloWorld1");
HelloWorld2 h = new HelloWorld2();
System.out.println(h.hello("Karthick"));
logger.info("after main");
  }

}