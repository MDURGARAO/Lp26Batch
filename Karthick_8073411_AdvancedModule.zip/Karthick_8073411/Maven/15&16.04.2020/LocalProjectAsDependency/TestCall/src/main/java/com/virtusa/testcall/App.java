package com.virtusa.testcall;

import com.hello.HelloWorld2;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
	HelloWorld2 h = new HelloWorld2();
	System.out.println("Enter your name:");
	Scanner sc = new Scanner(System.in);
	String s = sc.next();
	System.out.println( h.hello(s) );
    }
}
