package com.virtusa.hibernate;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.Entity.Customer;
import com.virtusa.association.Address;

public class CustomerMain {
	public static void main(String[] args) {
		Customer cus = new Customer(77655, 4000, "Barath", false, new Address(345, "Saidapet","Chennai"));
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory = configuration.buildSessionFactory();
		Session session = buildSessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cus);
		transaction.commit();
		session.close();
	}
	
}