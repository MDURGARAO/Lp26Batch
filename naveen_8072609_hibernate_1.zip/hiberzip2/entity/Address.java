package com.virtusa.hibernate.entity;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
private String country;
private String state;
private String district;
private String street;
private int pincode;
private String doorNumber;
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getDistrict() {
	return district;
}
public void setDistrict(String district) {
	this.district = district;
}
public String getStreet() {
	return street;
}
public void setStreet(String street) {
	this.street = street;
}
public int getPincode() {
	return pincode;
}
public void setPincode(int pincode) {
	this.pincode = pincode;
}
public String getDoorNumber() {
	return doorNumber;
}
public void setDoorNumber(String doorNumber) {
	this.doorNumber = doorNumber;
}
public Address() {
}

}
