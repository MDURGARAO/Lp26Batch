package com.virtusa.hibernate.entity;

import java.io.File;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;

@Entity
@SecondaryTable(name = "ApplicantPersonalDetails")
public class Applicant {
	@Id
private String email;
	@Column(table= "ApplicantPersonalDetails")
private String lastName;
	@Column(table= "ApplicantPersonalDetails")
private String firstName;
	@Column(table= "ApplicantPersonalDetails")
private String qualification;
private String oppurtunityId;
private File resume;

public Applicant() {
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getQualification() {
	return qualification;
}
public void setQualification(String qualification) {
	this.qualification = qualification;
}
public String getOppurtunityId() {
	return oppurtunityId;
}
public void setOppurtunityId(String oppurtunityId) {
	this.oppurtunityId = oppurtunityId;
}
public File getResume() {
	return resume;
}
public void setResume(File resume) {
	this.resume = resume;
}

	
}
