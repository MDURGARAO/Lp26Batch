package com.virtusa.hibernate.manytoone;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Order {
	@Id
	private int orderId;
	  @OneToMany(mappedBy = "order",cascade = CascadeType.ALL)
	  private Set<Item> items = new HashSet<Item>();
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	 
}
