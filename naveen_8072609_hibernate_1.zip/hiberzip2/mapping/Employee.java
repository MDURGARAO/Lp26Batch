package com.virtusa.hibernate.mapping;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.virtusa.hibernate.entity.Person;
@Entity
@Table(name= "employee")
public class Employee {
	@Id
	private int empId;
	private double salary;
	private Date hireDate;
	@OneToOne(fetch = FetchType.LAZY)
	private Person person;

	public Employee() {
	}
	public Employee(int empId, double salary, Date hireDate, Person person) {
		super();
		this.empId = empId;
		this.salary = salary;
		this.hireDate = hireDate;
		this.person = person;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Date getHireDate() {
		return hireDate;
	}
	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}

}
