package com.virtusa.hibernate.client;


import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.entity.Employee;
import com.virtusa.hibernate.entity.Book;



public class EmployeeMain {
	public static void main(String[] args) {
		//Employee emp = new Employee();
	//	emp.setEmployeeId(68);
//		emp.setEmployeeName("emp01");
//		emp.setSalary(78000);
//		//Employee emp1 = new Employee(1,12345,45000,"emp1","tpt",'M');
		//Employee emp2 = new Employee(2,123456,50000,"emp2","bang",'F');
		//Employee emp3 = new Employee(3,123453,42000,"emp3","che",'M');
		//Employee emp4 = new Employee(4,123452,43000,"emp4","hyd",'M');
		//Employee emp5 = new Employee(5,12342,25000,"emp5","vza",'F');
		//Employee emp6 = new Employee(6,1232,36000,"emp6","nlr",'M');
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();	
		//Session session = sessionFactory.openSession();
		//Transaction transaction = session.beginTransaction();
		//session.remove(emp);
		//session.update(emp);
		//session.delete(emp);
			//Employee emp1 = (Employee)session.load(Employee.class,47);
			//Employee emp2= (Employee)session.get(Employee.class,3);
			//Employee emp3= (Employee)session.get(Employee.class,3);

			//System.out.println(emp1.getEmployeeName());
			//System.out.println(emp2);
			//emp2.setAddress("skht");
			//System.out.println(emp2);
			//session.
	//	transaction.commit();
		//session.close();
		//System.out.println(emp2);

		//System.out.println(emp.getEmployeeName());
		//System.out.println(emp1.getEmployeeName());

	}
}
