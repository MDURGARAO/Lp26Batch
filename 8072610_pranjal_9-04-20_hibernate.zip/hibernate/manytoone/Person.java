package com.virtusa.hibernate.manytoone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PersonProperty")
public class Person {
		@Id
		@Column(name="person_id")
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int personId;

		@Column(name="PERSONNAME")
		private String personName;

		public int getPersonId() {
			return personId;
		}

		public void setPersonId(int personId) {
			this.personId = personId;
		}

		public String getPersonName() {
			return personName;
		}

		public void setPersonName(String personName) {
			this.personName = personName;
		}

		@Override
		public String toString() {
			return "Person [personId=" + personId + ", personName=" + personName + "]";
		}
		
	}
