package com.virtusa.hibernate.manytoone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Property {
	@Id
	@Column(name="Property_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int propertyId;

	@Column(name="PROPERTY_NAME")
	private String propertyname;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name ="person_id")
	private Person person;

	public int getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}

		
	public String getPropertyname() {
		return propertyname;
	}

	public void setPropertyname(String propertyname) {
		this.propertyname = propertyname;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	@Override
	public String toString() {
		return "Property [propertyId=" + propertyId + ", PROPERTYNAME=" + propertyname + ", person=" + person + "]";
	}
	
}
