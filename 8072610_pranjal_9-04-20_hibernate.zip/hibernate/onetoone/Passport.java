package com.virtusa.hibernate.onetoone;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Passport {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)  
	@PrimaryKeyJoinColumn 
	private int passposrtId;
	private String passportLocation;
	private Date passportExpiry;
	
	@OneToOne(cascade=CascadeType.ALL)  
	private Person person;

	public int getPassposrtId() {
		return passposrtId;
	}

	public void setPassposrtId(int passposrtId) {
		this.passposrtId = passposrtId;
	}

	public String getPassportLocation() {
		return passportLocation;
	}

	public void setPassportLocation(String passportLocation) {
		this.passportLocation = passportLocation;
	}

	public Date getPassportExpiry() {
		return passportExpiry;
	}

	public void setPassportExpiry(Date passportExpiry) {
		this.passportExpiry = passportExpiry;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}
	
	public Passport() {
	
	}

	public Passport( String  passportLocation, Date passportExpiry, Person person) {
		
		this.passportLocation = passportLocation;
		this.passportExpiry = passportExpiry;
		this.person = person;
	}

	@Override
	public String toString() {
		return "Passport [passposrtId=" + passposrtId + ", passportLocation=" + passportLocation + ", passportExpiry="
				+ passportExpiry + ", person=" + person + "]";
	}
	
	
}
