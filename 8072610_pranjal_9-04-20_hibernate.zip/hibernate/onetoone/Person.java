package com.virtusa.hibernate.onetoone;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="person1")
public class Person {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)  
	private int personId;
	private long number;
	private String name;
	public int getPersonId() {
		return personId;
	}
	public void setPersonId(int personId) {
		this.personId = personId;
	}
	public long getNumber() {
		return number;
	}
	public void setNumber(long number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Person(long number, String name) {
		this.number = number;
		this.name = name;
	}
	public Person() {
	
	}
	@Override
	public String toString() {
		return "Person [personId=" + personId + ", number=" + number + ", name=" + name + "]";
	}
	
}
