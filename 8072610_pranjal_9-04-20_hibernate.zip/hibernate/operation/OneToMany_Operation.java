package com.virtusa.hibernate.operation;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.virtusa.hibernate.onetomany.User;
import com.virtusa.hibernate.onetomany.Vehicle;
import com.virtusa.hibernate.util.HibernateUtil;

public class OneToMany_Operation {

	User user = new User();
	
	public static Session getSessionObject() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		return session;
	}
	public void saveData(User user) {
		Session session = OneToMany_Operation.getSessionObject();
		session.beginTransaction();
		session.save(user);
		session.getTransaction().commit();
		session.close();
	}
	
	public void updateData(int userId,int vehicleId) {
		Session session = OneToMany_Operation.getSessionObject();
		session.beginTransaction();
		user = (User) session.get(User.class, userId);
		user.setUserName("pranjal");
		Collection<Vehicle> vehicle = user.getVehicle();
		for(Vehicle vh : vehicle)
		{
			if (vh.getVehicleId() == vehicleId) {
					vh.setVehicleName("nano");
			   }
		}		
		user.setVehicle(vehicle);
		session.saveOrUpdate(user);
		session.getTransaction().commit();
		session.close();
	}
	
	public void deleteData(int userId) {
		Session session = OneToMany_Operation.getSessionObject();
		session.beginTransaction();
		user = (User)session.get(User.class, userId);		
		session.delete(user);		
		session.getTransaction().commit();
		session.close();
	}
	
	public void viewAllData() {
		Session session = OneToMany_Operation.getSessionObject();
		session.beginTransaction();
		Query query = session.createQuery("from User");
		List<User> fetchData = query.list();
		Iterator<User> iterator = fetchData.iterator();
		while(iterator.hasNext())
		     {
	          	user = (User)iterator.next();
	            System.out.println(user);
		     }				
		session.getTransaction().commit();
		session.close();
	}

	
}
