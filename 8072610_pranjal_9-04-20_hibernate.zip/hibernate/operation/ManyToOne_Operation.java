package com.virtusa.hibernate.operation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.virtusa.hibernate.manytoone.Person;
import com.virtusa.hibernate.manytoone.Property;
import com.virtusa.hibernate.util.HibernateUtil;

public class ManyToOne_Operation {
	
	Property property = new Property();
	public void insertDataIntoTable(ArrayList<Property> propertyList) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Iterator<Property> iterator = propertyList.iterator();
		while(iterator.hasNext())
		{
			Property next = iterator.next();
			session.persist(next);
		}	
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}

	public void deleteDataFormTable() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		try {
			property = (Property) session.get(Property.class, 9);	
			session.delete(property);
			property = (Property) session.get(Property.class, 10);	
			session.delete(property);
			session.getTransaction().commit();
		} catch (Exception e) {
			System.err.println("!!!!Please Enter valid Id");
			HibernateUtil.shutdown();
		}
		finally {
			HibernateUtil.shutdown();
		}	
	}
	public void updateDataOfTable(int Id) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		try {
			property = (Property) session.get(Property.class, Id);
			property.setPropertyname("chennaiProperty");
			Person person = property.getPerson();
			person.setPersonName("mukesh");
			session.persist(person);
			session.getTransaction().commit();
		} catch (Exception e) {
			System.err.println("!!!!Please Enter valid Id");
			HibernateUtil.shutdown();
		}
		finally {
			HibernateUtil.shutdown();
		}
	}
	public void viewDataOfTable() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Property");
		List<Property> fetchData = query.list();
		Iterator<Property> iterator = fetchData.iterator();
		while(iterator.hasNext())
		     {
			    property = (Property)iterator.next();
	            System.out.println(property);
		     }		
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}

}
