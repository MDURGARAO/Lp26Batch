package com.virtusa.hibernate.operation;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.hibernate.entity.Employee;
import com.virtusa.hibernate.onetoone.Passport;
import com.virtusa.hibernate.onetoone.Person;
import com.virtusa.hibernate.util.HibernateUtil;

public class OneToOne_Operation {

	Passport passport = new Passport();
	//Person person = new Person();
	
	public static Session getSessionObject() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		return session;
	}
	public void saveData(Passport passport) {
		Session session = OneToOne_Operation.getSessionObject();
		session.beginTransaction();
		session.save(passport);
		session.getTransaction().commit();
		session.close();
	}
	
	public void updateData(int passportId) {
		Session session = OneToOne_Operation.getSessionObject();
		session.beginTransaction();
		passport = (Passport) session.get(Passport.class, passportId);
		passport.setPassportLocation("Indore");
		Person person = passport.getPerson();
		person.setName("Chandu");
		passport.setPerson(person);
		session.persist(passport);
		session.getTransaction().commit();
		session.close();
	}
	
	public void deleteData(int passportId) {
		Session session = OneToOne_Operation.getSessionObject();
		session.beginTransaction();
		passport = (Passport) session.get(Passport.class, passportId);
		//Person person = passport.getPerson();
		session.delete(passport);		
		session.getTransaction().commit();
		session.close();
	}
	
	public void viewAllData() {
		Session session = OneToOne_Operation.getSessionObject();
		session.beginTransaction();
		Query query = session.createQuery("from Passport");
		List<Passport> fetchData = query.list();
		Iterator<Passport> iterator = fetchData.iterator();
		while(iterator.hasNext())
		     {
	          	passport = (Passport)iterator.next();
	            System.out.println(passport);
	    }
				
		session.getTransaction().commit();
		session.close();
	}
	
	}
