package com.virtusa.hibernate.manytomany;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity    
public class Mobile {
	
	@Id  
    @GeneratedValue(strategy=GenerationType.AUTO)  
	private int mobileID;
	
	private String companyName;
	private String modelName;
	private String color;
	
	public int getMobileID() {
		return mobileID;
	}
	public void setMobileID(int mobileID) {
		this.mobileID = mobileID;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	@Override
	public String toString() {
		return "Mobile [mobileID=" + mobileID + ", companyName=" + companyName + ", modelName=" + modelName + ", color="
				+ color + "]";
	}	
}
