package com.virtusa.hibernate.main;

import java.util.ArrayList;

import com.virtusa.hibernate.manytomany.Mobile;
import com.virtusa.hibernate.manytomany.Person;
import com.virtusa.hibernate.operation.ManyToMany_Operation;

public class ManyToManyRunner {

	public static void main(String[] args) {
		   
			ManyToMany_Operation operation = new ManyToMany_Operation();
		
		    Mobile mob1 = new Mobile();
		    
		    mob1.setModelName("n4");
		    mob1.setCompanyName("micromox");
		    mob1.setColor("red");
		    
		    Mobile mob2 = new Mobile();
		    
		    mob2.setModelName("x11");
		    mob2.setCompanyName("apple");
		    mob2.setColor("golden");
		    
		    ArrayList<Mobile> li = new ArrayList<Mobile>();
		    li.add(mob1);
		    li.add(mob2);
		    
		    Person prsn1 = new Person();
	        prsn1.setName("chandu");
	        prsn1.setJob("developer");
	        prsn1.setMobile(li);
			 
		    
		    Mobile mob4 = new Mobile();
		    mob4.setModelName("v11");
		    mob4.setCompanyName("vivo");
		    mob4.setColor("skyblue");
		    
		    ArrayList<Mobile> li1 = new ArrayList<Mobile>();
		    li1.add(mob1);
		    li1.add(mob4);
		    
		    Person prsn2 = new Person();
	        prsn2.setName("pranjal");
	        prsn2.setJob("hr");
	        prsn2.setMobile(li1);
	        
	        ArrayList<Person> personList = new ArrayList<Person>();
	        personList.add(prsn1);
	        personList.add(prsn2);
	        
	     //   operation.insertDataIntoTable(personList);  
	      operation.viewDataOfTable();
	     //   operation.updateDataOfTable(1);
	      //  operation.deleteDataFormTable();
	}

}
