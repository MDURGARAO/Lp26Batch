package com.virtusa.hibernate.main;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.virtusa.hibernate.entity.Teacher;
import com.virtusa.hibernate.inheritance.Developer;
import com.virtusa.hibernate.inheritance.Employee;
import com.virtusa.hibernate.inheritance.Tester;
import com.virtusa.hibernate.operation.EmployeeOperation;
import com.virtusa.hibernate.twoclassonetable.Address;
import com.virtusa.hibernate.twoclassonetable.Employee1;
import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {
	
	public static void main(String[] args) {
		//EmployeeOperation operation = new EmployeeOperation(); 
	     Address address = new Address("12","annexeRoad",400001);
         Employee1 emp1 = new Employee1(101,"pranjal",30000,"java developer",address);
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	
		Session session = sessionFactory.openSession();
	    session.beginTransaction();
		
	    Teacher te = new Teacher();
	    te.setFirstName("chandu");
	    te.setLastName("bhramhan");
	    te.setElectrical("power");
	    te.setComputer("datastructure");		
		
		
		
		Employee emp = new Employee(101,"chandu",30000,"employee");
		Developer developer = new Developer(102,"scott",40000,"developer",10,"java","hibernate");
		Tester tester = new Tester(103,"martin",35000,"tester","selenium","webdeveloper");
		
		session.save(emp);
		session.save(developer);
		session.save(tester);
		
		session.getTransaction().commit();
		
//		Employee emp = new Employee(); 
//		Employee em; 
//		/* emp.setEmpId(104); 
//		 emp.setEmpName("Anwar");
//		 emp.setEmpSal(25000); 
//		 emp.setEmpDesignation("employee");
//		 operation.insertEmployee(emp);*/
//		 
//		 operation.deleteEmployee(104);
//		 List<Employee> allEmployeeInfo = operation.allEmployeeInfo();
//		 Iterator<Employee> it=allEmployeeInfo.iterator();
//		 while(it.hasNext())
//		     {
//		          	em = (Employee)it.next();
//		            System.out.println(em);
//
//		    }
		HibernateUtil.shutdown();
	}
}
