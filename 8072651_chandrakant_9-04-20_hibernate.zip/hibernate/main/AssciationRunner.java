package com.virtusa.hibernate.main;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;


import com.virtusa.hibernate.manytomany.Mobile;
import com.virtusa.hibernate.manytomany.Person;
import com.virtusa.hibernate.manytoone.College;
import com.virtusa.hibernate.manytoone.Student;
import com.virtusa.hibernate.onetomany.Company;
import com.virtusa.hibernate.onetomany.Products;
import com.virtusa.hibernate.onetoone.Person1;
import com.virtusa.hibernate.onetoone.ValidityCertificate;
import com.virtusa.hibernate.util.HibernateUtil;

public class AssciationRunner {
	
	public static void main(String[] args) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		
		Session session = sessionFactory.openSession();
	    session.beginTransaction();
	    
//	    Products product1 = new Products();
//	    
//	   // product1.setProductId(10);
//	    product1.setProductName("laptop");
//	    product1.setProductPrice(30000);
//	    
//        Products product2 = new Products();
//	   // product2.setProductId(20);
//	    product2.setProductName("mobile");
//	    product2.setProductPrice(10000);
//	    
//	    ArrayList<Products> list = new ArrayList<Products>();
//	    list.add(product1);
//	    list.add(product2);
//	    
//	    Company company = new Company();
//	    //company.setCompanyId(1234);
//	      company.setName("amazon");
//	      company.setLocation("hydrabad");
//	      company.setProducts(list);
//	    
//	   	
//	      session.persist(company);
//	      session.getTransaction().commit();
	 
	    
		/*
		 * College college = new College(); college.setName("IIT Bombay");
		 * college.setLocation("mumbai");
		 * 
		 * Student student1 = new Student(); student1.setAge(18);
		 * student1.setCollege(college); student1.setName("chandu");
		 * 
		 * Student student2 = new Student(); student2.setAge(19);
		 * student2.setCollege(college); student2.setName("pranjal");
		 * 
		 * session.persist(student1); session.persist(student2);
		 * session.getTransaction().commit(); 
		 * System.out.println("success");
		 */
	    
	/*    Mobile mob1 = new Mobile();
	    mob1.setModelName("z2");
	    mob1.setCompanyName("lenevo");
	    mob1.setColor("black");
	    
	    Mobile mob2 = new Mobile();
	    mob2.setModelName("v11");
	    mob2.setCompanyName("vivo");
	    mob2.setColor("skyblue");
	    
	    ArrayList<Mobile> li = new ArrayList<Mobile>();
	    li.add(mob1);
	    li.add(mob2);
	    
	    Person prsn1 = new Person();
        prsn1.setName("chandu");
        prsn1.setJob("developer");
        prsn1.setMobile(li);
		 
        Mobile mob3 = new Mobile();
	    mob3.setModelName("n4");
	    mob3.setCompanyName("micromox");
	    mob3.setColor("red");
	    
	    Mobile mob4 = new Mobile();
	    mob4.setModelName("X11");
	    mob4.setCompanyName("Apple");
	    mob4.setColor("golden");
	    
	    ArrayList<Mobile> li1 = new ArrayList<Mobile>();
	    li1.add(mob3);
	    li1.add(mob4);
	    
	    Person prsn2 = new Person();
        prsn2.setName("pranjal");
        prsn2.setJob("hr");
        prsn2.setMobile(li1);
	
        session.persist(prsn1);
        session.persist(prsn2);
	   
        session.getTransaction().commit();*/
	   
	    
	    SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
	    Date d = new Date();
	    String d1 = sdf.format(d);
	    Person1 person1 = new Person1();
	    person1.setMobNumber(8087701142l);
	    person1.setName("chandu");
	    ValidityCertificate certificate = new ValidityCertificate();
	    certificate.setIssueDate(d1);
	    certificate.setIssuedOfficeLoaction("Akola");
	    certificate.setPerson1(person1);
	    
	    session.save(certificate);
	    session.getTransaction().commit();
	    
        HibernateUtil.shutdown();
	    System.out.println("Success");
	}
}
