package com.virtusa.hibernate.main;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.virtusa.hibernate.onetoone.Person1;
import com.virtusa.hibernate.onetoone.ValidityCertificate;
import com.virtusa.hibernate.operation.OneToOne_Operation;

public class OneToOneRunner {

	public static void main(String[] args) {
		
		OneToOne_Operation operation = new OneToOne_Operation();
		ValidityCertificate certificate = new ValidityCertificate();
		Person1 person = new Person1();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
		Date d = new Date(2019,03,31);
	    String d1 = sdf.format(d);
		
	    person.setMobNumber(7896584525l);
	    person.setName("King");
	    
		certificate.setIssuedOfficeLoaction("Buldhana");
		certificate.setIssueDate(d1);
		certificate.setPerson1(person);
		
		//operation.insertDataIntoTable(certificate);
		
		operation.deleteDataFormTable(5);
		
		//operation.updateDataOfTable(3);
		
		//operation.viewDataOfTable();
	}

}
