package com.virtusa.hibernate.onetoone;
import javax.persistence.*;

import com.virtusa.hibernate.onetoone.Person1;

@Entity
public class ValidityCertificate {
	
	@Id  
    @GeneratedValue(strategy=GenerationType.AUTO)  
    @PrimaryKeyJoinColumn  
	private int validityId;
	private String issueDate;
	private String issuedOfficeLoaction;
	@OneToOne(targetEntity=Person1.class,cascade=CascadeType.ALL)  
	private Person1 person1;
	public int getValidityId() {
		return validityId;
	}
	public void setValidityId(int validityId) {
		this.validityId = validityId;
	}
	public String getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}
	public String getIssuedOfficeLoaction() {
		return issuedOfficeLoaction;
	}
	public void setIssuedOfficeLoaction(String issuedOfficeLoaction) {
		this.issuedOfficeLoaction = issuedOfficeLoaction;
	}
	public Person1 getPerson1() {
		return person1;
	}
	public void setPerson1(Person1 person1) {
		this.person1 = person1;
	}
	
	@Override
	public String toString() {
		return "ValidityCertificate [validityId=" + validityId + ", issueDate=" + issueDate + ", issuedOfficeLoaction="
				+ issuedOfficeLoaction + ", person1=" + person1 + "]";
	}
	
}
