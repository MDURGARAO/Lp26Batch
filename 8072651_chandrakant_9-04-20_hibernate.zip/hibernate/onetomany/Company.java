package com.virtusa.hibernate.onetomany;

import java.util.Collection;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;

@Entity
public class Company {
	
	@Id   
	@GeneratedValue(strategy=GenerationType.TABLE)  
	private int companyId;
	private String name;
	private String location;
	@OneToMany( targetEntity = Products.class,cascade = CascadeType.ALL)  
	@JoinColumn(name="cid")  
	private Collection<Products> products;  
	
	public Collection<Products> getProducts() {
		return products;
	}

	public void setProducts(Collection<Products> products) {
		this.products = products;
	}

	public Company(int companyId, String name, String location) {
		super();
		this.companyId = companyId;
		this.name = name;
		this.location = location;
	}

	public Company() {
		super();
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", name=" + name + ", location=" + location + ", products="
				+ products + "]";
	}
	
}
