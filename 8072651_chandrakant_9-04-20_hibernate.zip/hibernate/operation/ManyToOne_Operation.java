package com.virtusa.hibernate.operation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.virtusa.hibernate.manytoone.College;
import com.virtusa.hibernate.manytoone.Student;
import com.virtusa.hibernate.onetomany.Company;
import com.virtusa.hibernate.util.HibernateUtil;

public class ManyToOne_Operation {

	Student student = new Student();
	
	public void insertDataIntoTable(ArrayList<Student> studentList) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Iterator<Student> iterator = studentList.iterator();
		while(iterator.hasNext())
		{
			Student next = iterator.next();
			session.persist(next);
		}	
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}

	public void deleteDataFormTable() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		try {
			student = (Student) session.get(Student.class, 3);	
			session.delete(student);
			student = (Student) session.get(Student.class, 4);	
			session.delete(student);
			session.getTransaction().commit();
		} catch (Exception e) {
			System.err.println("!!!!Please Enter valid Id");
			HibernateUtil.shutdown();
		}
		finally {
			HibernateUtil.shutdown();
		}	
	}
	public void updateDataOfTable(int Id) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		try {
			student = (Student) session.get(Student.class, Id);
			student.setAge(23);
			student.setName("mukesh");
			College college = student.getCollege();
			college.setLocation("chennai");
			college.setName("IIT Madras");
			student.setCollege(college);
			session.persist(student);
			session.getTransaction().commit();
		} catch (Exception e) {
			System.err.println("!!!!Please Enter valid Id");
			HibernateUtil.shutdown();
		}
		finally {
			HibernateUtil.shutdown();
		}
	}
	public void viewDataOfTable() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Student");
		List<Student> fetchData = query.list();
		Iterator<Student> iterator = fetchData.iterator();
		while(iterator.hasNext())
		     {
			    student = (Student)iterator.next();
	            System.out.println(student);
	    }		
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}
}
