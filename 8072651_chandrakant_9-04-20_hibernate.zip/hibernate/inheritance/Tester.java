package com.virtusa.hibernate.inheritance;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@PrimaryKeyJoinColumn(name="ID")
public class Tester extends Employee{
	
	public Tester(int empId, String empName, double empSal, String empDesignation, String tool, String tech) {
		super(empId, empName, empSal, empDesignation);
		this.tool = tool;
		this.tech = tech;
	}
	private String tool;
	private String tech;
	public String getTool() {
		return tool;
	}
	public void setTool(String tool) {
		this.tool = tool;
	}
	public String getTech() {
		return tech;
	}
	public void setTech(String tech) {
		this.tech = tech;
	}
	
	
	
}
