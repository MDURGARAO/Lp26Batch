package com.inheritance;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Tester {
    @Id
	private int testerId;
	private String testerName;
	public Tester(int testerId, String testerName) {
		super();
		this.testerId = testerId;
		this.testerName = testerName;
	}
	public int getTesterId() {
		return testerId;
	}
	public void setTesterId(int testerId) {
		this.testerId = testerId;
	}
	public String getTesterName() {
		return testerName;
	}
	public void setTesterName(String testerName) {
		this.testerName = testerName;
	}
	@Override
	public String toString() {
		return "Tester [testerId=" + testerId + ", testerName=" + testerName + "]";
	}
	
}
