package com.inheritance;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		Employee employee=new Employee(1111,"Harsh",30000,"Patna");
		Developer developer=new Developer(3333,"Vedant","java");
		Tester tester=new Tester(2222,"Sundari");
		
		Configuration configuration=new Configuration();
		configuration.configure("hibernate3.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(employee);
		session.save(developer);
		session.save(tester);
		
		transaction.commit();
		session.close();
	}
}
