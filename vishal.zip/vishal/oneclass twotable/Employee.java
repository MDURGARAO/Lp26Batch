package com.oneclass.twotable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name="employee")
@SecondaryTable(name="employeedetail")
public class Employee {

	   @Id
	   private int id;
	   @Column(name="name")
	   private String name;
	   @Column(name="address", table="employeedetail")
	   private String address;
	   @Column(name="bloodgroup", table="employeedetail")
	   private String bloodGroup;
	   @Column(name="zipcode", table="employeedetail")
	   private String zipCode;
	   public Employee(int id, String name, String address, String bloodGroup, String zipCode) {
		this.id = id;
		this.name = name;
		this.address = address;
		this.bloodGroup = bloodGroup;
		this.zipCode = zipCode;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", address=" + address + ", bloodGroup=" + bloodGroup
				+ ", zipCode=" + zipCode + "]";
	}
	   
	  
}
