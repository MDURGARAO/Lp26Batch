package com.virtusa.student;


import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_info")
public class Student {
    
	@Id
	private int sid;
	private String sname;
	private String department;
	@Embedded
	private Address address;
	public Student(int sid, String sname, String department,Address address) {
		this.sid = sid;
		this.sname = sname;
		this.department = department;
		this.address = address;
	}
	 
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", department=" + department + ", address=" + address + "]";
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
}
