package com.virtusa.hibernate.operation;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.virtusa.hibernate.entity.Employee;
import com.virtusa.hibernate.util.HibernateUtil;

public class EmployeeOperation {
	
	private List list;
	 Transaction transaction = null;
	public int insertEmployee(Employee emp) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Serializable primarykey = session.save(emp);
		Integer id = (Integer)primarykey;
		transaction.commit();
		return id;		
	} 
	
	public List<Employee> allEmployeeInfo(){
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Employee");
		List<Employee> fetchData = query.list();
		return fetchData;		
	}
	
	public void deleteEmployee(int pk){
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		Employee emp1 = (Employee) session.get(Employee.class, pk);
		if(emp1!=null)
		{
		  session.delete(emp1);
		}
		else System.err.println("please enter valid value for delete operation");
        transaction.commit();
          	
	}
	public int insertEmbedded(Employee emp)
	{
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Serializable primarykey = session.save(emp);
		Integer id = (Integer)primarykey;
		transaction.commit();
		return id;	
	}
}