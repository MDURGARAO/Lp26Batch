package com.virtusa.hibernate.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.hibernate.entity.CompositeKey;
import com.virtusa.hibernate.entity.Employee;
import com.virtusa.hibernate.util.HibernateUtil;

public class Runner1 {

	public static void main(String[] args) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
//    	Employee emp = new Employee(90,"Deepak", 18000, "fullstackdeveloper");
//    	System.out.println(emp);
//    	session.merge(emp);
//    	//emp.setEmpName("manipal");
//	    System.out.println(emp);
		CompositeKey comp = new CompositeKey();
		comp.setName("chandrakant");
		comp.setAddress("maharashtra");
		comp.setSalary(20000);
		session.save(comp);
	    session.getTransaction().commit();
	    session.close();
	
	

//	(Employee) session.get(Employee.class,27 );
//		System.out.println(emp);
//		emp.setEmpName("pranjal");
//		emp.setEmpId(22);
//		session.save(emp);
//	emp=(Employee) session.load(Employee.class,28);
//	emp.setEmpId(27);
//	emp.setEmpName("bandu");
	//emp=(Employee) session.get(Employee.class,28);
//	System.out.println(emp);
//		System.out.println(emp);
	}
}
