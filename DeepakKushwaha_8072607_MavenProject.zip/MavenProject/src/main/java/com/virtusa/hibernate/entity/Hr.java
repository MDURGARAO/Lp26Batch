package com.virtusa.hibernate.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name="Hr")
@SecondaryTable(name="Department")
public class Hr {
	
	@Id
	@Column(updatable = false)
	private int id;
	private String name;
	private long mobile;
	
	@Column(table="Department")
	private String delivery;
	
	@Column(table="Department")
	private String technology;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getDelivery() {
		return delivery;
	}

	public void setDelivery(String delivery) {
		this.delivery = delivery;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public Hr(int id, String name, long mobile, String delivery, String technology) {
		super();
		this.id = id;
		this.name = name;
		this.mobile = mobile;
		this.delivery = delivery;
		this.technology = technology;
	}

	public Hr() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
