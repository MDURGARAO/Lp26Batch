package com.virtusa.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity   
@Inheritance(strategy=InheritanceType.JOINED)  
public class Employee1 {

	
	@Id  
	@GeneratedValue(strategy=GenerationType.AUTO)  
	@Column(name="EmployeeId")
	private int id;
	private String name;
	private double sal;
	private String designation;
	
	
	public Employee1() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Employee1(int id, String name, double sal, String designation) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
		this.designation = designation;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	

}
