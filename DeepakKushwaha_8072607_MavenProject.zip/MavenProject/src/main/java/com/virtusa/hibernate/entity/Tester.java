package com.virtusa.hibernate.entity;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity    
@PrimaryKeyJoinColumn(name="ID")  
public class Tester extends Employee1 {
	
	
	private String technology;
	private String project;
	
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	
	
}
