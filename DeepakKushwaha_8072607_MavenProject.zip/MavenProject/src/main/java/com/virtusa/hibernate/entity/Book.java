package com.virtusa.hibernate.entity;

public class Book implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private int bookId;
	private String bookname; 
	private double price;
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Book(int bookId, String bookname, double price) {
		super();
		this.bookId = bookId;
		this.bookname = bookname;
		this.price = price;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
