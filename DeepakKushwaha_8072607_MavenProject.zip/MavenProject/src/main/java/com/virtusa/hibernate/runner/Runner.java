package com.virtusa.hibernate.runner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.hibernate.entity.Address;
import com.virtusa.hibernate.entity.Book;
import com.virtusa.hibernate.entity.Employee;
import com.virtusa.hibernate.utility.Utility;

public class Runner {
public static void main(String[] args) {
	
	
	Address address = new Address(514,"Chennai", 560076);
	Employee employee = new Employee(232,"Chandu",20000,address);

	//Book book = new Book(123,"book",234.00);
	SessionFactory factory = Utility.getFactory();
	
	Session session = factory.openSession();
	Transaction transaction = session.beginTransaction();
	session.save(employee);
	session.getTransaction().commit();
	
//	
//	//StudentOperation studentOperation =  new StudentOperation();
////	Student student = new Student(1,"Deepak", 8962118957L);
////	studentOperation.insertEmployee(student);
//	Session session=factory.openSession();
//Query query=session.createQuery("from  Student");
//List<Student> ls=query.list();
//for (Student student : ls) {
//	System.out.println(student);
//	
//}
	
}
}
