package com.virtusa.hibernate.entity;

public class Address {
	private int houseNo;
	private String city;
	private int pincode;
	
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Address(int houseNo, String city, int pincode) {
		super();
		this.houseNo = houseNo;
		this.city = city;
		this.pincode = pincode;
	}
}
