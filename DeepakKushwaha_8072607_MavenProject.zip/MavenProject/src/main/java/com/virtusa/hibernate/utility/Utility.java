package com.virtusa.hibernate.utility;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Utility {

	private static SessionFactory factory= null;
	static{
		Configuration config= new Configuration();
		config.configure("hibernate.cfg.xml");
		factory = config.buildSessionFactory();
	     }
	public static SessionFactory getFactory() {
		return factory;
	}
	
	private Utility() {
		super();
	}
}
