package com.virtusa.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Student")
public class Student {
	@Id
	@Column(name="StudentId")   //to give column name into the database table(not necessary if you not give by default it takes the variable name )
	private int id;
	@Column(name="StudentName")
	private String name;
	
	private long moblie;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMoblie() {
		return moblie;
	}

	public void setMoblie(int moblie) {
		this.moblie = moblie;
	}

	public Student(int id, String name, long moblie) {
		super();
		this.id = id;
		this.name = name;
		this.moblie = moblie;
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", moblie=" + moblie + "]";
	}

}
