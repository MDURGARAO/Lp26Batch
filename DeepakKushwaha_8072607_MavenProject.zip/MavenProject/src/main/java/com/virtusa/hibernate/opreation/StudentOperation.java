package com.virtusa.hibernate.opreation;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.virtusa.hibernate.entity.Student;
import com.virtusa.hibernate.utility.Utility;

public class StudentOperation {

	public int insertEmployee(Student student) {
		SessionFactory factory = Utility.getFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Serializable pk =session.save(student);
		Integer id = (Integer)pk;
		transaction.commit();
		return id;
	}
	public Student fetchEmployee(int pk) {
		SessionFactory factory = Utility.getFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Student student = (Student) session.get(Student.class, pk);
		return student; 
	}
	
	public void deleteEmployee(int pk) {
		SessionFactory factory = Utility.getFactory();
		Session session = factory.openSession();
		Transaction transaction =  session.beginTransaction();
		Student student = (Student) session.get(Student.class, pk);
		session.delete(student);
		transaction.commit();
		
	}
	
	public void updateEmployee(Student student, int pk) {
		SessionFactory factory = Utility.getFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Student studentData = (Student) session.get(Student.class, pk);
		String studentName = student.getName();
		int studentMobile = (int) student.getMoblie();
		studentData.setName(studentName);
		studentData.setMoblie(studentMobile);
		session.update(studentData);
		transaction.commit();
	
	}
	
}
