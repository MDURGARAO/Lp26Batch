package com.virtusa.hibernate.runner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.hibernate.entity.Developer;
import com.virtusa.hibernate.entity.Employee1;
import com.virtusa.hibernate.entity.Hr;
import com.virtusa.hibernate.entity.Tester;
import com.virtusa.hibernate.utility.Utility;

public class Runner1 {
public static void main(String[] args) {
	
	
	SessionFactory factory = Utility.getFactory();
	Session session = factory.openSession();
	Transaction transaction = session.beginTransaction();
	
	
	 Employee1 e1=new Employee1();    
     e1.setName("Gaurav Chawla"); 
     e1.setDesignation("developer");
     e1.setSal(20000);
         
     Developer e2=new Developer();  
     e2.setName("Deepak");
     e2.setTechnology("Java");    
     e2.setProject("LeavemanagementSystem");   
         
     Tester e3=new Tester();
     e3.setName("Chandu");
     e3.setProject("LeavemanagementSystem"); 
     e3.setTechnology("java");
	
	session.save(e1);
	session.save(e2);
	session.save(e3);
	session.getTransaction().commit();    
    session.close();    
    System.out.println("success");      
}
}
