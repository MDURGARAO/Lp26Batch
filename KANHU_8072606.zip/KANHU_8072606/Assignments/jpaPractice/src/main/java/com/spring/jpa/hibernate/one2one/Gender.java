package com.spring.jpa.hibernate.one2one;

public enum Gender {
    MALE, FEMALE
}
