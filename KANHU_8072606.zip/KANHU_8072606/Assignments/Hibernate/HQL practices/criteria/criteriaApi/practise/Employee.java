package com.criteriaApi.practise;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="Employee")
public class Employee {
	
	
	public Employee() {
		
	}
	@Id
	@Column(name="id")
	int id ;
	@Column(name="Name")
	String empName;
	@Override
	public String toString() {
		return "Employee [id=" + id + ", empName=" + empName + ", salary=" + salary + ", address=" + address + "]";
	}
	@Column(name="Salary")
	double salary;
	@Column(name="address")
	String address;
	public void setId(int id) {
		this.id = id;
	}
	public void setempName(String empName) {
		empName = empName;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Employee(int id, String empName, double salary, String address) {
		super();
		this.id = id;
		empName = empName;
		this.salary = salary;
		this.address = address;
	}
	
	

	
}

