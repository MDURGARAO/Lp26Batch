package com.hibernate.main;

import java.util.Random;

//import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.practise.Players;

public class PlayersMain {
	
	public static void main(String[] args) {
	
	Configuration configuration = new Configuration();
	configuration.configure("hibernate.cfg.xml");
	SessionFactory sessionFactory = configuration.buildSessionFactory();
//	Transaction transaction = session.beginTransaction();
//	
//	Random random =new Random();
//                    
//	for(int i=1; i<=10; i++) {
//	Players players = new Players();
//	players.setPlayerId(i);
//	players.setPlayerName("Players" + i);
//	players.setPlayerScore(random.nextInt(100));
//	session.save(players);
//	}
//	transaction.commit();
//	 session.close();    

	Session session1 = sessionFactory.openSession();
	Players player1 = session1.get(Players.class, 3);
	System.out.println(player1);

	session1.close();
	
	Session session2 = sessionFactory.openSession();
	Players player2 = session2.get(Players.class, 3);
	System.out.println(player2);

	session2.close();
	

}
}
