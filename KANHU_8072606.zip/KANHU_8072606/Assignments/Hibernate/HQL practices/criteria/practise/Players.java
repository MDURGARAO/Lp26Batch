package com.virtusa.practise;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name="Players")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class Players {

	@Id
	private int playerId;
	private String playerName;
	private int playerScore;
	
	public Players() {
		
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public int getPlayerScore() {
		return playerScore;
	}
	public void setPlayerScore(int playerScore) {
		this.playerScore = playerScore;
	}
	@Override
	public String toString() {
		return "Players [playerId=" + playerId + ", playerName=" + playerName + ", playerScore=" + playerScore + "]";
	}
	public Players(int playerId, String playerName, int playerScore) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.playerScore = playerScore;
	}
	
}
