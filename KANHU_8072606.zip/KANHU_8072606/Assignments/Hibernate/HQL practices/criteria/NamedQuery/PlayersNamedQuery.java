package com.virtusa.NamedQuery;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name="PlayersInfo")

@NamedQuery(
	name = "findPlayerById",
	query = "from PlayersNamedQuery as p where p.playerName = :playerName")					

public class PlayersNamedQuery {

	@Id
	private int playerId;
	private String playerName;
	private int playerScore;
	
	public PlayersNamedQuery() {
		
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public PlayersNamedQuery(int playerId, String playerName, int playerScore) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.playerScore = playerScore;
	}
	public int getPlayerScore() {
		return playerScore;
	}
	public void setPlayerScore(int playerScore) {
		this.playerScore = playerScore;
	}
	@Override
	public String toString() {
		return "PlayersNamedQuery [playerId=" + playerId + ", playerName=" + playerName + ", playerScore=" + playerScore
				+ "]";
	}
	
	
}
