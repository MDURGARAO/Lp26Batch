package com.hibernate.practice.compositeMapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
 
public class Main {
 
    
 
    public static void main(String[] args) {
    	
    	 Configuration configuration=new Configuration();
 		configuration.configure("hibernate.cfg.xml");
 		SessionFactory buildSessionFactory= configuration.buildSessionFactory();
 		Session session=buildSessionFactory.openSession();
 		Transaction transaction=session.beginTransaction();
      
       
        BookInfo bkInfo = new BookInfo(new Book("Harry Potter & The Philosopher's Stone", "J. K. Rowling"));
        bkInfo.setIsbn("978-1-4028-9462-6");
        session.persist(bkInfo);
        transaction.commit();
       
 
        session.clear();
       
        System.out.println("Record Successfully Inserted In The Database");
    }
}
