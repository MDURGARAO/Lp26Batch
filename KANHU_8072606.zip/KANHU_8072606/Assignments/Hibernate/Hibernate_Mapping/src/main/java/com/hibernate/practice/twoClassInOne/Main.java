package com.hibernate.practice.twoClassInOne;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
public class Main {
   public static void main(String[] args) {
	    Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory= configuration.buildSessionFactory();
		Session session=buildSessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
     
     EmployeeDetail detail = new EmployeeDetail();
     
     detail.setAge(25);
     detail.setCountry("India");
     detail.setBloodGroup("B+");
     
     Employee employee = new Employee();
   
     employee.setName("kanhu charan das");
     employee.setEmployeeId("EMP001");
     
     employee.setEmpDetails(detail);
     
     session.save(employee);
     
     transaction.commit();
     session.flush();
     session.close();
     
   }
}
