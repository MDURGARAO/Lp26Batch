package com.hibernate.association.many2one;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AppMain {

	
	public static void main(String[] args) {
		
		Configuration configuration=new Configuration();
  		configuration.configure("hibernate.cfg.xml");
  		SessionFactory buildSessionFactory= configuration.buildSessionFactory();
  		Session session=buildSessionFactory.openSession();
  		Transaction transaction=session.beginTransaction();
  		
			Department department = new Department("Technology", "Sector 18, Gurugram");

		
			Employee employee1 = new Employee("ABC", department);
			Employee employee2 = new Employee("XYZ", department);

			session.save(employee1);
			session.save(employee2);

			
			transaction.commit();

		
				session.close();
			}
		
	
}
