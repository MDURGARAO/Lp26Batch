package com.spring.tasks.setterInjections;

public class Printer {

	public void printBalanceInformation(String accountNumber) {
		System.out.println("The printer has printed the balance information for the account number " + accountNumber);
		
	}

}