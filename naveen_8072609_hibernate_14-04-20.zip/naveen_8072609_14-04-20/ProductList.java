package com.virtusa.hibernate.hql;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name ="productList")

@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)


@NamedNativeQueries({
	   @NamedNativeQuery(name="get_all_productlist", query="select * from ProductList"),
	   @NamedNativeQuery(name="get_all_namesprices", query="select name , price from ProductList ")
	})

@NamedQueries({
	   @NamedQuery(name="get_all_products", query="select p from ProductList p"),
	   @NamedQuery(name="get_all_names_prices", query="select p.name , p.price from ProductList p")
	})

public class ProductList {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String name;
	private float price;
	public  ProductList() {
	}
	public long getId() {
		return id;
	}
	public ProductList(String name, float price) {
		super();
		this.name = name;
		this.price = price;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	
}
