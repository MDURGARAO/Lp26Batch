package com.virtusa.hibernate.hql;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class SecondLevelCache {
	public static void main(String[] args) {
		ProductList product=null;
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		 product = (ProductList)session.load(ProductList.class,8L);
		System.out.println(product.getName() + " " +product.getPrice());
		System.out.println(product.getName() + " " +product.getPrice());
		session.evict(product);
		System.out.println(product.getName() + " " +product.getPrice());
		session.close();
		
		
		Session session1 = sessionFactory.openSession();
		//ProductList product = (ProductList)session.load(ProductList.class, 4);
		System.out.println(product.getName() + " " +product.getPrice());
		session1.close();
		
		

	}
}
