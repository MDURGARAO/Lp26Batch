package com.hibernate.main;

import java.util.Iterator;
import java.util.List;
import java.util.Random;

import javax.persistence.TypedQuery;

//import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.NamedQuery.PlayersNamedQuery;



public class NamedQuery_Main {

	public static void main(String[] args) {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
//		Random random =new Random();
//	                    
//		for(int i=1; i<=10; i++) {
//		PlayersNamedQuery PlayersNamedQuery = new PlayersNamedQuery();
//		PlayersNamedQuery.setPlayerId(i);
//		PlayersNamedQuery.setPlayerName("PlayersNamedQuery" + i);
//		PlayersNamedQuery.setPlayerScore(random.nextInt(100));
//		session.save(PlayersNamedQuery);
//		}
//		transaction.commit();
//		 session.close();    
//
		TypedQuery<PlayersNamedQuery> plyr = session.getNamedQuery("findPlayerById");
		plyr.setParameter("playerName", "PlayersNamedQuery2");
		
		   List<PlayersNamedQuery> plyr4 =plyr.getResultList();  
		   Iterator<PlayersNamedQuery> itr=plyr4.iterator();    
		     while(itr.hasNext()){    
		    	 PlayersNamedQuery e=itr.next();    
		    System.out.println(e);    
		     } 
//		   System.out.println(plyr4);
		   session.close();
	}
}
