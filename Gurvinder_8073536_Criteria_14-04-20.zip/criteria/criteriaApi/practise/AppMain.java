package com.hibernate.main;

import java.util.List;
import java.util.Random;

import org.hibernate.Criteria;
//import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import com.criteriaApi.practise.Employee;
import com.mysql.cj.x.protobuf.MysqlxCrud.Projection;

public class AppMain {
	public static void main(String[] args) {

		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
//		Random random=new Random();
//		for(int i=1; i<=10; i++) {
//			Employee employee=new Employee();
//			employee.setId(i);
//			employee.setEmpName("employeedent" + i);
//			employee.setSalary(random.nextInt(20000));
//			
//			session.save(employee);
//		}
//		
//	    transaction.commit();
//	Criteria criteria =session.createCriteria(Employee.class);
//		
//		
//	SimpleExpression expression1=Restrictions.ge("salary", 5000.00);
//	criteria.add(expression1);
//	List<Employee> list =criteria.list();
//	list.forEach(System.out::println);
	
	
//	Criteria criteria =session.createCriteria(Employee.class);
//	SimpleExpression expression1=Restrictions.ge("salary", 5000.00);
//	criteria.add(expression1);
//	criteria.addOrder(Order.desc("salary"));
//	List<Employee> list =criteria.list();
//	list.forEach(System.out::println);
//	
	
		Criteria criteria =session.createCriteria(Employee.class);
		ProjectionList projectlist = Projections.projectionList();
		projectlist.add(Projections.property("empName"))
				   .add(Projections.property("salary"));
		criteria.setProjection(projectlist);
		List<Object[]> obj = criteria.list();
		for (Object[] objects : obj) {
			System.out.println(objects[0] +" "+ objects[1]);
			
			
		}
		
		
	
	session.close();
	
	}
}
