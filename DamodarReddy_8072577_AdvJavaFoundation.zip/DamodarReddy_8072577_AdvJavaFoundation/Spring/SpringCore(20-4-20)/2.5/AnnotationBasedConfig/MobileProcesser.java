/**
 * 
 */
package com.virtusa.casestudy2;

public interface MobileProcesser {
	void process();
}
