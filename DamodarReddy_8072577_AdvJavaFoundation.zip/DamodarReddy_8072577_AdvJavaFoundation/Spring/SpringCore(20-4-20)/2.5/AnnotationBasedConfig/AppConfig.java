/**
 * 
 */
package com.virtusa.casestudy2;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**virtusa
 * @author Damodar Reddy9:47:44 AMApr 20, 2020
 * AppConfig.java
 */
@Configuration
@ComponentScan(basePackages="com.virtusa.casestudy2")
public class AppConfig {

}
