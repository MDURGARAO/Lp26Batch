package com.virtusa;

/**
 * Hello world!
 *
 */
 import com.virtusa.classs.*;
public class App 
{
    public static void main( String[] args )
    {
      int result= Calculator.add(10,20);
	  System.out.println(result);
    }
}
