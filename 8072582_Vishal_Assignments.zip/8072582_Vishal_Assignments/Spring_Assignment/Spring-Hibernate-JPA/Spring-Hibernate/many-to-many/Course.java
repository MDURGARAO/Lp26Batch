package com.virtusa.spring.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
@Entity
public class Course {

	@Id
        @GeneratedValue
	private int courseId;
	private String courseName;
	@ManyToMany
	@JoinTable(name="Student_Course",joinColumns={@JoinColumn                                (name="courseId")},
	inverseJoinColumns={@JoinColumn(name="studentId")})
	private List<Student> course=new ArrayList<Student>();
	public Course(){
		
	}
	public Course(int courseId, String courseName, List<Student> course) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.course = course;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public List<Student> getCourse() {
		return course;
	}
	public void setCourse(List<Student> course) {
		this.course = course;
	}
	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName + ", course=" + course + "]";
	}
	
}
