package com.virtusa.spring.repository;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.spring.model.Student;

@Repository
public class StudentRepository {

	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void saveStudent(Student student) {
		Session session = sessionFactory.getCurrentSession();
		session.save(student);

	}
	
	@Transactional
	public void updateStudent(Student student) {
		Session session = sessionFactory.getCurrentSession();
		session.update(student);
	}

	@Transactional
	public void deleteStudent(Student student) {
		Session session = sessionFactory.getCurrentSession();
		session.delete(student);
	}
	
	@Transactional
	public Student fetchStudent(int studentId) {
		Session session = sessionFactory.getCurrentSession();
		return (Student) session.get(Student.class,studentId);
	}

}
