package com.virtusa.spring.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Student {

	@Id
        @GeneratedValue
	private int studentId;
	private String studentName;
	
        @ManyToMany
	@JoinTable(name="Student_Course",joinColumns={@JoinColumn                                (name="studentId")},
	inverseJoinColumns={@JoinColumn(name="courseId")})
	private List<Course> course=new ArrayList<Course>();
	public Student(){
		
	}
	public Student(int studentId, String studentName, List<Course> course) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.course = course;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public List<Course> getCourse() {
		return course;
	}
	public void setCourse(List<Course> course) {
		this.course = course;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", course=" + course + "]";
	}
	
}
