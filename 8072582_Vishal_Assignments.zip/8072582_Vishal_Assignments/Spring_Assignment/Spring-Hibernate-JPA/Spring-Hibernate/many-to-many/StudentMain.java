package com.virtusa.spring.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.model.Student;
import com.virtusa.spring.repository.StudentRepository;

public class StudentMain {

public static void main(String args[]) {
		
		Scanner scanner = new Scanner(System.in);

		ApplicationContext context = new ClassPathXmlApplicationContext("student.cfg.xml");

		StudentRepository studentRepository = context.getBean(StudentRepository.class, "studentRepository");

		Student student1 = (Student) context.getBean("student1");

		Student student2 = (Student) context.getBean("student2");
		
		Student student3 = (Student) context.getBean("student3");

		studentRepository.saveStudent(student1);
		studentRepository.saveStudent(student2);
		
		System.out.println("Enter Customer ID");
		System.out.println(studentRepository.fetchStudent(scanner.nextInt()).toString());
		

		studentRepository.updateStudent(student3);
		
		System.out.println("Enter Customer ID");
		System.out.println(studentRepository.fetchStudent(scanner.nextInt()).toString());


	}
}
