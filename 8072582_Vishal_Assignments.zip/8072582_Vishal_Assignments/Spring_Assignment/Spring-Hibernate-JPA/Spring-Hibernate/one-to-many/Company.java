package com.virtusa.spring.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Company_ONe_To_Many")
public class Company {
    @Id
    @GeneratedValue
    @Column(name="Company_Id")
	private int companyId;
    @Column(name="Company_Name")
	private String companyName;
    @OneToMany(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	private Set<Employee> employee;
    
    public Company(){
    	
    }

	public Company(int companyId, String companyName, Set<Employee> employee) {
		this.companyId = companyId;
		this.companyName = companyName;
		this.employee = employee;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Set<Employee> getEmployee() {
		return employee;
	}

	public void setEmployee(Set<Employee> employee) {
		this.employee = employee;
	}

	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", employee=" + employee + "]";
	}
    
}
