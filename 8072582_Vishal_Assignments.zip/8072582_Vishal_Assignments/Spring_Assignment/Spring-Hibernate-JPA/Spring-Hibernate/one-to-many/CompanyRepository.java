package com.virtusa.spring.repository;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.spring.model.Company;
@Repository
public class CompanyRepository {

	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void saveCompany(Company company) {
		Session session = sessionFactory.getCurrentSession();
		session.save(company);
	}

	@Transactional
	public void updateCompany(Company company) {
		Session session = sessionFactory.getCurrentSession();
		session.update(company);
	}

	@Transactional
	public void deleteCompany(Company company) {
		Session session = sessionFactory.getCurrentSession();
		session.delete(company);
	}
	
	@Transactional
	public Company fetchCompany(int companyId) {
		Session session = sessionFactory.getCurrentSession();
		return (Company) session.get(Company.class,companyId);
	}

}

