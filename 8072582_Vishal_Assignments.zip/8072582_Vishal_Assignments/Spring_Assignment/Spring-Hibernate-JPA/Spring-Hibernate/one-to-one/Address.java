package com.virtusa.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Address {
    @Id
    @GeneratedValue
    @Column(name="Street_No")
	private int streetNo;
    @Column(name="Street_Name")
	private String street;
    @Column(name="City")
	private String city;
    @Column(name="State")
	private String state;
    @Column(name="Pin_Code")
	private int pinCode;
    public Address(){
    	
    }
	public Address(int streetNo, String street, String city, String state, int pinCode) {
		super();
		this.streetNo = streetNo;
		this.street = street;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
	}
	public int getStreetNo() {
		return streetNo;
	}
	public void setStreetNo(int streetNo) {
		this.streetNo = streetNo;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	@Override
	public String toString() {
		return "Address [streetNo=" + streetNo + ", street=" + street + ", city=" + city + ", state=" + state
				+ ", pinCode=" + pinCode + "]";
	}
    
}
