package com.virtusa.client.entitymanager;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.model.Customer;
import com.virtusa.spring.repository.CustomerRepository;

public class CustomerMain {

public static void main(String args[]) {
		
		Scanner scanner = new Scanner(System.in);

		ApplicationContext context = new ClassPathXmlApplicationContext("spring_customer.cfg.xml");

		CustomerRepository CustomerRepository = (CustomerRepository) context.getBean("customerRepository");
		
		Customer customer1 = (Customer) context.getBean("customer1");
		
		Customer customer2 = (Customer) context.getBean("customer2");

		CustomerRepository.saveCustomer(customer1);
		
		System.out.println("Enter Customer ID");
		System.out.println(CustomerRepository.fetchCustomer(scanner.nextInt()).toString());
}
}
