package com.virtusa.spring.entitymanager;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.virtusa.spring.model.Company;
import com.virtusa.spring.model.Student;
@Component
@Repository
public class StudentRepository {


	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public void saveStudent(Student student) {
		entityManager.persist(student);
		
	}

	@Transactional
	public Student fetchStudent(int studentId) {
		return entityManager.find(Student.class, studentId);
		
	}
}
