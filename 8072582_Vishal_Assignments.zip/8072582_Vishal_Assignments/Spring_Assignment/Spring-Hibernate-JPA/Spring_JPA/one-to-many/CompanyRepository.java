package com.virtusa.spring.entitymanager;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.virtusa.spring.model.Company;
import com.virtusa.spring.model.Customer;
@Repository
@Component
public class CompanyRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public void saveCompany(Company company) {
		entityManager.persist(company);
		
	}

	@Transactional
	public Company fetchCompany(int companyId) {
		return entityManager.find(Company.class, companyId);
		
	}
}
