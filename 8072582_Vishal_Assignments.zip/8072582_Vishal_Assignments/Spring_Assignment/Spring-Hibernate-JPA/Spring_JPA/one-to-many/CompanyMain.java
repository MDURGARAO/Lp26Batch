package com.virtusa.client.entitymanager;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.model.Company;
import com.virtusa.spring.repository.CompanyRepository;

public class CompanyMain {

public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring_company.cfg.xml");
		
		CompanyRepository companyRepository =  context.getBean(CompanyRepository.class,"companyRepository");
		
		Company company1 = (Company) context.getBean("comp1");
		
		companyRepository.saveCompany(company1);
		
		System.out.println("Enter Company ID");
		System.out.println(companyRepository.fetchCompany(scanner.nextInt()).toString());
}
}
