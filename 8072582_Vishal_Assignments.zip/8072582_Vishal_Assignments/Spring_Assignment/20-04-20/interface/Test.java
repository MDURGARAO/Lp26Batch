package com.virtusa.twoclass.interfac;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("springinterface.xml");
		Shape shape=(Shape)context.getBean("triangle");
		shape.draw();
	}
}
