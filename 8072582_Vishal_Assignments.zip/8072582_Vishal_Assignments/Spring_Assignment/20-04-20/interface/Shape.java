package com.virtusa.twoclass.interfac;

public interface Shape {

	public void draw();
}
