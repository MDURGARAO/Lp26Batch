package com.virtusa.twoclass.interfac;

public class Triangle implements Shape{

	private Point pointA;
	private Point pointB;
	public Point getPointA() {
		return pointA;
	}
	public void setPointA(Point pointA) {
		this.pointA = pointA;
	}
	public Point getPointB() {
		return pointB;
	}
	public void setPointB(Point pointB) {
		this.pointB = pointB;
	}
	@Override
	public String toString() {
		return "Triangle [pointA=" + pointA + ", pointB=" + pointB + "]";
	}
	public void draw() {
		System.out.println("Drawing Triangle...");
		System.out.println("Point A=("+getPointA().getX()+","+getPointA().getY()+")");
		System.out.println("Point B=("+getPointB().getX()+","+getPointB().getY()+")");
	}
	
	
}
