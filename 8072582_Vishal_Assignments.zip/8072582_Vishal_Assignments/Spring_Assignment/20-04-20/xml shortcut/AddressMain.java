package com.virtusa.xmlshortcut;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AddressMain {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("springxmlshortcut.xml");
		Address  addr=(Address)context.getBean("address");
		System.out.println(addr);
	}
}
