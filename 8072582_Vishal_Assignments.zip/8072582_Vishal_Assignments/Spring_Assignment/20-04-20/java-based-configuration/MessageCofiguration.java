package com.virtusa.java.based.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MessageCofiguration {
    @Bean
	public Message getMessage(){
		return new Message();
	}
}
