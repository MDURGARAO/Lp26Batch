package com.virtusa.java.based.configuration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MessageTest {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(MessageCofiguration.class);
		Message message=context.getBean(Message.class,"message");
		System.out.println(message);
	}
}
