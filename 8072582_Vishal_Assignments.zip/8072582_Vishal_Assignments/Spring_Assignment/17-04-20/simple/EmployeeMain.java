package com.spring.employee.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.employee.Employee;

public class EmployeeMain {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("springemployee.xml");
		Employee  employee=(Employee) context.getBean(Employee.class,"Employee");
		Employee employee2=new Employee(222,"Golu");
		Employee employee3=new Employee();
		employee3.setEmployeeId(666);
		employee3.setEmployeeName("Gabru");
		System.out.println(employee);
		System.out.println(employee3);
		
		//ApplicationContext context=new ClassPathXmlApplicationContext("springemployee.xml");
		//Employee  employee1=(Employee) context.getBean(Employee.class,"Employee");
		System.out.println(employee2==employee);
		System.out.println(employee2==employee3);
		System.out.println(employee2);
	}
}
