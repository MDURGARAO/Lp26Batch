package com.employye.has.a;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeMain {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("springhasa.xml");
		Employee employee=context.getBean(Employee.class, "Employee");
		System.out.println(employee);
	}
}
