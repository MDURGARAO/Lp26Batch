package com.virtusa.collection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CountryMain {

	public static void main(String[] args) {
        ApplicationContext appContext = new ClassPathXmlApplicationContext("springcollection.xml");
        Country countryObj = (Country) appContext.getBean("CountryBean");
        System.out.println(countryObj);
    }
}
