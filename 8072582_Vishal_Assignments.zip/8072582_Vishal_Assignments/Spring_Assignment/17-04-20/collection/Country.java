package com.virtusa.collection;

import java.util.List;

public class Country {

	String countryName;
	List listOfStates;
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public List getListOfStates() {
		return listOfStates;
	}
	public void setListOfStates(List listOfStates) {
		this.listOfStates = listOfStates;
	}
	@Override
	public String toString() {
		return "Country [countryName=" + countryName + ", listOfStates=" + listOfStates + "]";
	}
	
}
