package com.employee.inheritance;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeMain {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("springinheritance.xml");
		Developer employee=context.getBean(Developer.class, "developer");
		System.out.println(employee);
	}
}
