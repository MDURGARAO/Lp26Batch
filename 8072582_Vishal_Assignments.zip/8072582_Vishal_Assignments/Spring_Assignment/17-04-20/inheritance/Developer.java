package com.employee.inheritance;

public class Developer{
 
	private String designation;

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "Developer [designation=" + designation + "]";
	}
	
}
