package com.virtusa.constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CountryMain {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("springconstructor.xml");
		Country count=context.getBean(Country.class,"country");
		System.out.println(count);
	}
}
