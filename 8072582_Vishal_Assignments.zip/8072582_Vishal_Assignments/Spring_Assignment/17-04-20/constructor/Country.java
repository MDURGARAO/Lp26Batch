package com.virtusa.constructor;

public class Country {

	private int countryCode;
	private String countryName;
	private int noOfStates;
	public Country(int countryCode, String countryName, int noOfStates) {
		this.countryCode = countryCode;
		this.countryName = countryName;
		this.noOfStates = noOfStates;
	}
	@Override
	public String toString() {
		return "Country [countryCode=" + countryCode + ", countryName=" + countryName + ", noOfStates=" + noOfStates
				+ "]";
	}
	
}
