package com.virtusa.student;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;

@Embeddable
public class Address {
	
	private int StreetNo;
	private String streetName;
	private String city;
	public Address(){
		
	}
	public Address(int streetNo, String streetName, String city) {
		this.StreetNo = streetNo;
		this.streetName = streetName;
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [StreetNo=" + StreetNo + ", streetName=" + streetName + ", city=" + city + "]";
	}
	public int getStreetNo() {
		return StreetNo;
	}
	public void setStreetNo(int streetNo) {
		StreetNo = streetNo;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
}
