package com.virtusa.student;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.student.Address;
import com.virtusa.student.Student;

public class StudentMain {

	public static void main(String[] args) {
		
		Address address=new Address(11,"Giri Nagar","Chennai");
		
		Student student=new Student(111,"Raju","Ece",address);
		
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(student);
		session.save(address);
		
		transaction.commit();
		session.close();
	}
}
