package com.compound.mapping;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Account {
    @Id
	User user;
	private int accountBalance;
	public Account(User user, int accountBalance) {
		this.user = user;
		this.accountBalance = accountBalance;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public int getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}
	@Override
	public String toString() {
		return "Account [user=" + user + ", accountBalance=" + accountBalance + "]";
	}
	
	
}
