package com.compound.mapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AccountMain {

	public static void main(String[] args) {
		
		User user=new User(101, 500011132);
		Account account=new Account(user, 20000);
		Configuration configuration=new Configuration();
		configuration.configure("hibernate2.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(user);
		session.save(account);
		
		transaction.commit();
		session.close();
	}
}
