package com.inheritance;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.ForeignKey;

@Entity
public class Tester extends Employee{
    
	private String testerDegignation;

	public String getTesterDegignation() {
		return testerDegignation;
	}

	public void setTesterDegignation(String testerDegignation) {
		this.testerDegignation = testerDegignation;
	}
	 
	
}
