package com.inheritance;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		
		Configuration configuration=new Configuration();
		configuration.configure("hibernate3.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
		Employee employee=new Employee();
		employee.setEmployeeName("Vedant");
		employee.setCity("Danapur");
		employee.setSalary(20000);
		
		Developer developer=new Developer();
		developer.setDeveloperDesignation("Java Developer");
		
		Tester tester=new Tester();
		tester.setTesterDegignation("Automation Testing");
		
		session.save(employee);
		session.save(developer);
		session.save(tester);
		
		transaction.commit();
		session.close();
	}
}
