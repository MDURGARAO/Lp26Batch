package com.inheritance;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.ForeignKey;

@Entity
public class Developer extends Employee {
  
	private String developerDesignation;

	public String getDeveloperDesignation() {
		return developerDesignation;
	}

	public void setDeveloperDesignation(String developerDesignation) {
		this.developerDesignation = developerDesignation;
	}
}
