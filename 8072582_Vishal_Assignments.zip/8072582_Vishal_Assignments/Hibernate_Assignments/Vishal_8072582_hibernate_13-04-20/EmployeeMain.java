package com.hql.operation;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.lang.String;

import org.hibernate.Query;

import org.hibernate.*;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

public class EmployeeMain {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure("hqloperation.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
//		for(int i=1;i<=10;i++){
//		Employee employee=new Employee();
//		employee.setEmployeeName("employeeName" +i);
//		employee.setSalary(15000);
//		session.save(employee);
//		}
		
//		Query query=session.createQuery("from Employee");
//		List<Employee> empList=query.list();
//		empList.stream().forEach(System.out::println);
		
//		Query query=session.createQuery("from Employee");
//		Iterator<Employee> empList=query.iterate();
//		while(empList.hasNext()){
//			Employee emp=empList.next();
//			System.out.println(emp);
//		}
		
//		Query query=session.createQuery("select employeeId from Employee");
//		List<Integer> list=query.list();
//		list.stream().forEach(System.out::println);
		
//		Query query=session.createQuery("select employeeName from Employee");
//		List<String> list=query.list();
//		list.stream().forEach(System.out::println);
		
//		Query query=session.createQuery("select employeeId,employeeName from Employee");
//		List<Object[]> empList=query.list();
//		for(Object[] array:empList){
//			System.out.println(array[0] +"    " +array[1]);
//		}
		
//		Employee employee=(Employee) session.get(Employee.class, 5);
//		employee.setSalary(10000);
//		session.update(employee);
//		
//		Employee employee1=(Employee) session.get(Employee.class, 7);
//		employee1.setSalary(20000);
//		session.update(employee1);
		
//		Query query=session.createQuery("select min(salary),avg(salary),max(salary),sum(salary) from Employee");
//		List<Object[]> list=query.list();
//		for(Object[] array:list){
//			System.out.println(array[0]+ "  "+ array[1] + "  "+ array[2] +"  "+array[3]);
//		}
		/*
		Query query=session.createQuery("from Employee where employeeId>'employeeId'");
		query.setInteger("employeeId",new Scanner(System.in).nextInt());
		List<Employee> list=query.list();
		list.stream().forEach(System.out::println);*/
		
//		Query query=session.createQuery("update Employee set salary=13000 where employeeId=3");
//		query.executeUpdate();
//		
//		query=session.createQuery("Delete from Employee where employeeId=:employeeId");
//		query.setInteger("employeeId",8);
//		int x=query.executeUpdate();
//		System.out.println("no of rows deleted :"+x);
		
//		Query query=session.createQuery("insert into Employee(employeeName,salary) "
//				+ "select employeeName,salary from Employee");
//		query.setInteger("employeeId",111);
//		query.setString("employeeName", "Kapil");
//		query.setDouble("salary", 22000);
//		query.executeUpdate();
		
//		Query query=session.createQuery("select new Employee(employeeId,'employeeNAme',salary) from Employee");
//		List<Employee> list=query.list();
//		for(Employee emp:list){
//			System.out.println(emp);
//		}
		
//		Criteria criteria=session.createCriteria(Employee.class);
//		List<Employee> empList=criteria.list();
//		empList.forEach(System.out::println);
		
		Criteria criteria=session.createCriteria(Employee.class);
		SimpleExpression expression=Restrictions.eq("employeeId", 9);
		criteria.add(expression);
		List<Employee> empList=criteria.list();
		empList.forEach(System.out::println);
		transaction.commit();
		session.close();
	}
}
