package com.named.query;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmployeeTest {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure("namedquery.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
//		for(int i=1;i<=5;i++){
//			Employee employee=new Employee();
//			employee.setEmployeeName("employeeName "+i);
//			employee.setSalary(10000);
//			employee.setDesignation("HR");
//			session.save(employee);
//		}
		org.hibernate.Query query=session.getNamedQuery("Employee.byId");
		query.setInteger(0, 2);
		List list=query.list();
		list.stream().forEach(System.out::println);
		transaction.commit();
		session.close();
	}
}
