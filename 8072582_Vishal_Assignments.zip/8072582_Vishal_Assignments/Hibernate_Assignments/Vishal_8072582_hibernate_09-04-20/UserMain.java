package com.twoclass.onetable.twoaddress;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UserMain {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure("twoclassonetabletwoaddress.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
		User user=new User();
		user.setUserName("Vishal");
		
		Address presentAddress=new Address();
		presentAddress.setStreet("Giri Nagar");
		presentAddress.setCity("Chennai");
		presentAddress.setState("Tamilnadu");
		presentAddress.setPinCode("5600106");
		user.setPresentAddress(presentAddress);
		
		Address address1=new Address();
		address1.setStreet("ghareya");
		address1.setCity("Gaya");
		address1.setState("Bihar");
		address1.setPinCode("805131");
		user.setPresentAddress(address1);
		
		session.save(user);
		session.save(presentAddress);
		session.save(address1);
		
		transaction.commit();
		session.close();
	}
}
