package com.twoclass.onetable.twoaddress;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="USER_DETAILS_TWOADDRESS")
public class User {
	@Id
	@GeneratedValue
	private int userId;
	private String userName;
	@Embedded
	private Address presentAddress;
	@Embedded
	@AttributeOverrides({
		@AttributeOverride(name="street",column=@Column(name="permanemt_street_name")),
		@AttributeOverride(name="city",column=@Column(name="permanemt_city_name")),
		@AttributeOverride(name="state",column=@Column(name="permanemt_state_name")),
		@AttributeOverride(name="pinCode",column=@Column(name="permanemt_pin_code"))
	})
	private Address permanentAddress;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Address getAddress() {
		return presentAddress;
	}
	public void setPresentAddress(Address address) {
		this.presentAddress = address;
	}
}
