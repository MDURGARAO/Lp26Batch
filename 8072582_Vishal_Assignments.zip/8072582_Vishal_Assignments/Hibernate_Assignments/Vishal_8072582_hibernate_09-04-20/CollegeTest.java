package com.onetomany.mapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CollegeTest {

	public static void main(String[] args) {
		
		Configuration configuration=new Configuration();
		configuration.configure("onetomany.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
		College college=new College();
		college.setCollegeName("Gaya College");
		
		Student student1=new Student();
		student1.setStudentName("Rohit");
		
		Student student2=new Student();
		student2.setStudentName("Vikash");
		
		student1.setCollege(college);
		student2.setCollege(college);
		
		session.save(college);
		session.save(student1);
		session.save(student2);
		
		transaction.commit();
		session.close();
	}
}
