package com.manytomany.mapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.onetomany.mapping.College;
import com.onetomany.mapping.Student;

public class EventTest {

	public static void main(String[] args) {
		
		Configuration configuration=new Configuration();
		configuration.configure("manytomany.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
		Delegate delegate1=new Delegate();
		delegate1.setDelegateName("Dhoni");
		Delegate delegate2=new Delegate();
		delegate2.setDelegateName("Virat");
		Delegate delegate3=new Delegate();
		delegate3.setDelegateName("Rohit");
		Delegate delegate4=new Delegate();
		delegate4.setDelegateName("Bumrah");
		
		Event event1=new Event();
		event1.setEventName("WordCup");
		Event event2=new Event();
		event2.setEventName("Fifa");
		Event event3=new Event();
		event3.setEventName("Olampic");
		
		event1.getDelegate().add(delegate1);
		event1.getDelegate().add(delegate2);
		event1.getDelegate().add(delegate3);
		event2.getDelegate().add(delegate2);
		event2.getDelegate().add(delegate3);
		event3.getDelegate().add(delegate4);
		 
		session.save(delegate1);
		session.save(delegate2);
		session.save(delegate3);
		session.save(delegate4);
		session.save(event1);
		session.save(event2);
		session.save(event3);
		
		transaction.commit();
		session.close();
	}

}
