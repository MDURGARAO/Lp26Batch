package com.shubham.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shubham.bean.Employee;

public class Main {
	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("spring-bean.xml");
		
		System.out.println("**********Singleton************");
		Employee employee1 = ac.getBean("singleton", Employee.class);
		employee1.setId(1);
		employee1.setName("Shubham");
		employee1.setSalary(20000);
		
		System.out.println(employee1);
		
		Employee employee2 = ac.getBean("singleton", Employee.class);
		
		System.out.println(employee2);
		
		System.out.println(employee1 == employee2);
		
		((AbstractApplicationContext)ac).close();

	}
}
