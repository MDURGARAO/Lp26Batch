package com.shubham.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.shubham.bean.Employee;
import com.shubham.bean.EmployeeConfig;

public class MainJavaBased {
	public static void main(String[] args) {
	      ApplicationContext ctx = 
	         new AnnotationConfigApplicationContext(EmployeeConfig.class);
	   
	      System.out.println("**********Singleton************");
			Employee employee1 = ctx.getBean(Employee.class);
			employee1.setId(1);
			employee1.setName("Shubham");
			employee1.setSalary(20000);
			
			System.out.println(employee1);
			
			Employee employee2 = ctx.getBean(Employee.class);
			
			System.out.println(employee2);
			
			System.out.println(employee1 == employee2);
			
			((AbstractApplicationContext)ctx).close();
	   }
}
