package com.shubham.bean;

public interface DBConnection {
	public void connect();
	public void disconnect();
}
