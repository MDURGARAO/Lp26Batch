package com.shubham.bean;

public class SybaseDB implements DBConnection{
	public void connect() {
		System.out.println("Sybase is connecting now....");
	}
	
	public void disconnect() {
		System.out.println("Sybase is disconnecting now....");
	}
}
