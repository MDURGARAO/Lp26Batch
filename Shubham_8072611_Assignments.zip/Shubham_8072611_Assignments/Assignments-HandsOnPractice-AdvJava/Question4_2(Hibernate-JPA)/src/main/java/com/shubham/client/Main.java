package com.shubham.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.shubham.bean.Address;
import com.shubham.bean.Person;
import com.shubham.bean.PersonDAO;

public class Main {
	
	public static PersonDAO pDao;
	public static void main(String[] args) {
		Resource resource = new ClassPathResource("spring-bean.xml");  
	    BeanFactory factory = new XmlBeanFactory(resource);
	
	    pDao=(PersonDAO)factory.getBean("pDao");
	    
//		Address permAddress = new Address();
//		permAddress.setType("Permanent");
//		permAddress.setAddress1("Barahiya");
//		permAddress.setCity("Lakhisarai");
//		permAddress.setState("Bihar");
//		permAddress.setZipcode(811302);
//		
//		Address tempAddress = new Address();
//		tempAddress.setType("Temporary");
//		tempAddress.setAddress1("Ramapuram");
//		tempAddress.setCity("Chennai");
//		tempAddress.setState("Tamilnadu");
//		tempAddress.setZipcode(600125);
//		
//		Person person = new Person();
//		person.setFirstName("Shubham");
//		person.setLastName("Shandilya");
		
//		savePerson(person, permAddress, tempAddress);
		
//		deletePerson(2);
		
		showAllPerson();
	}
	
	public static void savePerson(Person person, Address permAddress, Address tempAddress) {
		List<Address> personAddress = new ArrayList<Address>();
		personAddress.add(permAddress);
		personAddress.add(tempAddress);
		
		person.setAddress(personAddress);
		permAddress.setPerson(person);
		tempAddress.setPerson(person);
		
		pDao.savePerson(person, permAddress, tempAddress);
	}
	
	public static void deletePerson(long personId) {
		Person person = new Person();
		person.setPersonId(personId);
		
		pDao.deletePerson(person);
	}
	
	public static void showAllPerson() {
		pDao.showAllPerson();
	}
	
}
