package com.shubham.bean;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate4.HibernateTemplate;


public class PersonDAO {
	HibernateTemplate template;  
	 
	public HibernateTemplate getTemplate() {
		return template;
	}

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	public void savePerson(Person person, Address permAddress, Address tempAddress) {
		SessionFactory sessionFactory = template.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(permAddress);
		session.save(tempAddress);
		session.save(person);
		session.getTransaction().commit();
	}
	
	public void deletePerson(Person person){  
		SessionFactory sessionFactory = template.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.delete(person);
		session.getTransaction().commit();  
	} 
	
	public void showAllPerson() {
		SessionFactory sessionFactory = template.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		List person = session.createQuery("from Person").list();
		 
        for (Iterator iterator = person.iterator(); iterator.hasNext();) {
            Person person2 = (Person) iterator.next();
            System.out.println(person2.getFirstName() + "  "
                    + person2.getLastName() + "\n" + person2.getAddress().get(0).getType()
                    + " Address: " + person2.getAddress().get(0).getAddress1()+ "  " + person2.getAddress().get(0).getCity()
                    + "  " + person2.getAddress().get(0).getState()+ "  " + person2.getAddress().get(0).getZipcode()
                    + "\n" + person2.getAddress().get(1).getType()
                    + " Address: " + person2.getAddress().get(1).getAddress1()+ "  " + person2.getAddress().get(1).getCity()
                    + "  " + person2.getAddress().get(1).getState()+ "  " + person2.getAddress().get(1).getZipcode());
        }
        session.getTransaction().commit();
	}
}
