package com.shubham.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shubham.bean.Employee;

public class Main {
	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("spring-bean.xml");
		
		System.out.println("**********Singleton************");
		Employee employee1 = ac.getBean("singleton", Employee.class);
		employee1.setId(1);
		employee1.setName("Shubham");
		employee1.setSalary(20000);
		
		System.out.println(employee1);
		
		Employee employee2 = ac.getBean("singleton", Employee.class);
		
		System.out.println(employee2);
		
		System.out.println(employee1 == employee2);
		
		System.out.println("**********Prototype************");
		Employee employee3 = ac.getBean("prototype", Employee.class);
		employee3.setId(1);
		employee3.setName("Shubham");
		employee3.setSalary(20000);
		
		System.out.println(employee3);
		
		Employee employee4 = ac.getBean("prototype", Employee.class);
		
		System.out.println(employee4);
		
		System.out.println(employee3 == employee4);
		
		
		
	}
}
