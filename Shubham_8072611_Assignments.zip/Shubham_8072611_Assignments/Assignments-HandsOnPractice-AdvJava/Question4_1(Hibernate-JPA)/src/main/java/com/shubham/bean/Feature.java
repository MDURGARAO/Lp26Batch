package com.shubham.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="Feature")
public class Feature {

	@Id
	@Column(name="carId", unique=true, nullable=false)
	@GeneratedValue
	private long id;
	
	@Column(name="modelType")
	private String mType;
	
	@Column(name="engineType")
	private String eType;
	
	@Column(name="gearType")
	private String gType;
	
	@OneToOne(cascade=CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private Car car;

	public Feature() {
		
	}
	
	public Feature(long id, String mType, String eType, String gType, Car car) {
		super();
		this.id = id;
		this.mType = mType;
		this.eType = eType;
		this.gType = gType;
		this.car = car;
	}

	public String getmType() {
		return mType;
	}

	public void setmType(String mType) {
		this.mType = mType;
	}

	public String geteType() {
		return eType;
	}

	public void seteType(String eType) {
		this.eType = eType;
	}

	public String getgType() {
		return gType;
	}

	public void setgType(String gType) {
		this.gType = gType;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

    
}
