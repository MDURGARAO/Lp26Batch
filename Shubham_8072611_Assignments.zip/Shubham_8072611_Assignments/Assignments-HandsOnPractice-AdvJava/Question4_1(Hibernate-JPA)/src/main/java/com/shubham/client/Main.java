package com.shubham.client;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.shubham.bean.Car;
import com.shubham.bean.CarDAO;
import com.shubham.bean.Feature;

public class Main {
	static CarDAO dao;
    public static void main(String[] args) {
    	Resource r=new ClassPathResource("spring-bean.xml");  
	    BeanFactory factory=new XmlBeanFactory(r);  
	      
	    dao=(CarDAO)factory.getBean("dao");
    	
        saveCar(new Date(),"Renault Duster","Petrol","SUV","Manual");
        saveCar(new Date(),"Fortuner","Petrol","SUV","Manual");
        saveCar(new Date(),"Honda City","Petrol","ZX","Manual");
	    
//	    deleteCar(2);
	   
//	    updateFeature(1,"SUV","diesel","automatic");
	    
//	    updateFeature(1,new Date(),"Fortuner");
	    
        showCars();
    }

    public static void saveCar(Date purchaseDate, String modelName, String eType, String mType, String gType) {
            Car car = new Car();
    		car.setPurchaseDate(purchaseDate);
    		car.setModelName(modelName);
    		
    		Feature feature = new Feature();
    		feature.seteType(eType);
    		feature.setmType(mType);
    		feature.setgType(gType);
    		
    		car.setFeatures(feature);
    		feature.setCar(car);
    		dao.saveCar(car,feature);
    }
 
    public static void showCars() {
      dao.showCars();
    }
 
    public static void deleteCar(long carId) {
        Car car = new Car();
        car.setId(carId);
        dao.deleteCar(car);
    }
 
    public static void updateFeature(long carId, String mType, String eType, String gType) {
    	Feature f = new Feature();
    	f.setId(carId);
    	f.seteType(eType);
    	f.setmType(mType);
    	f.setgType(gType);
    	dao.updateCar(f);
    }
    
    public static void updateFeature(long carId, Date purchaseDate, String name) {
    	Car car = new Car();
    	car.setId(carId);
    	car.setPurchaseDate(new Date());
    	car.setModelName(name);
    	dao.updateCar(car);
    }
}
