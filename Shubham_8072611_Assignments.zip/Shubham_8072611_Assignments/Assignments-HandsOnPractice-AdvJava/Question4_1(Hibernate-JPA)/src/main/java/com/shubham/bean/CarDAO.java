package com.shubham.bean;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate4.HibernateTemplate;

public class CarDAO {
	HibernateTemplate template;  
	 
	public HibernateTemplate getTemplate() {
		return template;
	}

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}

	public void saveCar(Car car, Feature feature){ 
		SessionFactory sessionFactory = template.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(feature);
		session.save(car);
		session.getTransaction().commit();
	}  
 
	public void updateCar(Feature f){ 
		SessionFactory sessionFactory = template.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.update(f);
		session.getTransaction().commit(); 
	}
	
	public void updateCar(Car car){ 
		SessionFactory sessionFactory = template.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.update(car);
		session.getTransaction().commit(); 
	}

	public void deleteCar(Car car){  
		SessionFactory sessionFactory = template.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.delete(car);
		session.getTransaction().commit();  
	}  

	public void showCars(){  
		List<Car> list=new ArrayList<Car>();  
		list=template.loadAll(Car.class);  
	    for(Car car: list) {
	    	System.out.println(car);
	    } 
	}  
}
