package com.shubham.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class EmpConfig {
	   @Autowired
	   @Qualifier("employee1")
	   private Employee employee1;
	   
	   @Autowired
	   @Qualifier("employee2")
	   private Employee employee2;
       
	   
	   public void showEmployee1() {
		   System.out.println(employee1.getId()+" "+employee1.getName()+" "+employee1.getSalary());
	   }
	   
	   public void showEmployee2() {
		   System.out.println(employee2.getId()+" "+employee2.getName()+" "+employee2.getSalary());
	   }
}