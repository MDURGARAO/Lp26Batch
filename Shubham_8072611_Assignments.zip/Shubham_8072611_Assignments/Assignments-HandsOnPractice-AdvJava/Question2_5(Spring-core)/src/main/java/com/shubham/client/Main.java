package com.shubham.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shubham.bean.EmpConfig;

public class Main {
	 public static void main(String[] args) {
         ApplicationContext context = new ClassPathXmlApplicationContext("spring-bean.xml");
         EmpConfig empConfig = (EmpConfig) context.getBean("emp");
         empConfig.showEmployee1();
         empConfig.showEmployee2();
       }
}
