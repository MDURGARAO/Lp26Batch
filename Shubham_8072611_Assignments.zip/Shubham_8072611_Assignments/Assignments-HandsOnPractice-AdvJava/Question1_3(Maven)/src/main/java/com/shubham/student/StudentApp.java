package com.shubham.student;

import com.shubham.calculator.App;

public class StudentApp 
{
    public static void main( String[] args )
    {
       System.out.println(App.add(15, 30));
       System.out.println(App.subtract(30,20));
       System.out.println(App.multiply(10, 10));
    }
}
