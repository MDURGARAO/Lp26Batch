package com.shubham.calculator;

public class App 
{
	public static void main( String[] args )
	{
		if (args.length < 1) {
			System.err.println("Please provide an input!");
			System.exit(0);
		}
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[1]);
		
		System.out.println(add(num1,num2));
		System.out.println(subtract(num1,num2));
		System.out.println(multiply(num1,num2));
	}
	
	public static int add(int num1,int num2) {
		return (num1 + num2);
	}
	
	public static int subtract(int num1,int num2) {
		return (num1 - num2);
	}
	
	public static int multiply(int num1,int num2) {
		return (num1*num2);
	}
}
