package com.shubham.calculator;

import org.junit.Test;

import junit.framework.Assert;


public class AppTest 
{
   private int num1 = 20;
   private int num2 = 15;
   
    @Test
    public void testAdd()
    {
        int expected = 35;
        Assert.assertEquals(expected, App.add(num1, num2));
    }
    
    @Test
    public void testSubtract()
    {
        int expected = 5;
        Assert.assertEquals(expected, App.subtract(num1, num2));
    }
    
    @Test
    public void testMultiply()
    {
        int expected = 300;
        Assert.assertEquals(expected, App.multiply(num1, num2));
    }
}
