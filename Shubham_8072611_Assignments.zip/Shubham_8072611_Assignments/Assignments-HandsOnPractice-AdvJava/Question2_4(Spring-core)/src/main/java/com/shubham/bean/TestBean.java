package com.shubham.bean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TestBean {
	DBConnection dbType1;
	DBConnection dbType2;

	
	public TestBean(DBConnection dbType1, DBConnection dbType2) {
		super();
		this.dbType1 = dbType1;
		this.dbType2 = dbType2;
	}


	public void run() throws InterruptedException {
		dbType1.connect();
		Thread.sleep(2000);
		dbType1.disconnect();
		Thread.sleep(2000);
		System.out.println("Switching database...");
		Thread.sleep(2000);
		dbType2.connect();
		Thread.sleep(2000);
		dbType2.disconnect();
		Thread.sleep(2000);
	}
}
