package com.shubham.client;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.shubham.bean.Address;
import com.shubham.bean.Person;
import com.shubham.bean.PersonDAO;

public class Main {
	public static PersonDAO pDao;
	public static void main(String[] args) {
		Resource resource = new ClassPathResource("spring-bean.xml");  
	    BeanFactory factory = new XmlBeanFactory(resource);
	
	    pDao=(PersonDAO)factory.getBean("pDao");
	
		Address permAddress = new Address();
		permAddress.setType("Permanent");
		permAddress.setAddress1("Barahiya");
		permAddress.setCity("Lakhisarai");
		permAddress.setState("Bihar");
		permAddress.setZipcode(811302);
		
		Address tempAddress = new Address();
		tempAddress.setType("Temporary");
		tempAddress.setAddress1("Ramapuram");
		tempAddress.setCity("Chennai");
		tempAddress.setState("Tamilnadu");
		tempAddress.setZipcode(600125);
		
		Person person1 = new Person();
		person1.setFirstName("Shubham");
		person1.setLastName("Shandilya");
		
		Person person2 = new Person();
		person2.setFirstName("Aman");
		person2.setLastName("Kumar");

		savePerson(person1, person2, permAddress, tempAddress);
		
		showAllPerson();

	}
	
	public static void savePerson(Person person1, Person person2, Address permAddress, Address tempAddress) {
		List<Person> person = new ArrayList<Person>();
		person.add(person1);
		person.add(person2);
		
		List<Address> person1Address = new ArrayList<Address>();
		person1Address.add(permAddress);
		person1Address.add(tempAddress);
		
		List<Address> person2Address = new ArrayList<Address>();
		person2Address.add(permAddress);
		person2Address.add(tempAddress);
		
		person1.setAddress(person1Address);
		person2.setAddress(person2Address);

		permAddress.setPerson(person);
		tempAddress.setPerson(person);
		
		pDao.savePerson(person1, person2, permAddress, tempAddress);
	}
	
	public static void deletePerson(long personId) {
		Person person = new Person();
		person.setPersonId(personId);
		
		pDao.deletePerson(person);
	}
	
	public static void showAllPerson() {
		pDao.showAllPerson();
	}
	
	
}
