package com.shubham.bean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DBConfig {
	
	@Bean(name="getDB")
	public TestBean getDB() {
		TestBean tb = new TestBean();
		tb.setDbType1(new OracleDB());
		tb.setDbType2(new SybaseDB());
		return tb;
	}
}
