package com.shubham.manytomany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
	public static void main(String[] args) {
		
		System.out.println("Hello");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		Session session = cfg.buildSessionFactory().openSession();
		Transaction txn = session.beginTransaction();
	
		Address permAddress = new Address();
		permAddress.setType("Permanent");
		permAddress.setAddress1("Barahiya");
		permAddress.setCity("Lakhisarai");
		permAddress.setState("Bihar");
		permAddress.setZipcode(811302);
		
		Address tempAddress = new Address();
		tempAddress.setType("Temporary");
		tempAddress.setAddress1("Ramapuram");
		tempAddress.setCity("Chennai");
		tempAddress.setState("Tamilnadu");
		tempAddress.setZipcode(600125);
		
		Person person1 = new Person();
		person1.setFirstName("Shubham");
		person1.setLastName("Shandilya");
		
		Person person2 = new Person();
		person2.setFirstName("Aman");
		person2.setLastName("Kumar");
		
		List<Person> person = new ArrayList<Person>();
		person.add(person1);
		person.add(person2);
		
		List<Address> person1Address = new ArrayList<Address>();
		person1Address.add(permAddress);
		person1Address.add(tempAddress);
		
		List<Address> person2Address = new ArrayList<Address>();
		person2Address.add(permAddress);
		person2Address.add(tempAddress);
		
		person1.setAddress(person1Address);
		person2.setAddress(person2Address);
		
		permAddress.setPerson(person);
		tempAddress.setPerson(person);
		
		session.save(permAddress);
		session.save(tempAddress);
		session.save(person1);
		session.save(person2);
		txn.commit();
		session.close();
	}
}
