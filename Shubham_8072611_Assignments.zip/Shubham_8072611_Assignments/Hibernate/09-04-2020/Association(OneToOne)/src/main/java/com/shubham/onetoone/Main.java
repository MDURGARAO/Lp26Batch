package com.shubham.onetoone;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
	public static void main(String[] args) {
		
		System.out.println("Hello");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		Session session = cfg.buildSessionFactory().openSession();
		Transaction txn = session.beginTransaction();
		
		Car car1 = new Car();
		car1.setPurchaseDate(new Date());
		car1.setModelName("Renault Duster");
		
		Feature feature1 = new Feature();
		feature1.seteType("Petrol");
		feature1.setmType("SUV");
		feature1.setgType("Manual");
		
		car1.setFeatures(feature1);
		feature1.setCar(car1);
		
		session.save(feature1);
		session.save(car1);
		
		txn.commit();
		session.close();
	}
}
