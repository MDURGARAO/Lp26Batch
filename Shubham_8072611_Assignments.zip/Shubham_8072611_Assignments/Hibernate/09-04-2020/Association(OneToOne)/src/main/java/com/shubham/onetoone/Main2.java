package com.shubham.onetoone;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main2 {
    public static void main(String[] args) {
        saveCar(new Date(),"Renault Duster","Petrol","SUV","Manual");
        saveCar(new Date(),"Fortuner","Petrol","SUV","Manual");
        saveCar(new Date(),"Honda City","Petrol","ZX","Manual");
        showCars();
//        deleteCar(16);
//        showCars();
//        updateFeature(13,"SV");
//        showCars();
    }
    
    public static SessionFactory getSessionFactory() {
        final SessionFactory sessionFactory;
            try {
                sessionFactory = new Configuration().configure()
                        .buildSessionFactory();
            } catch (Throwable ex) {
                System.err.println("SessionFactory creation failed" + ex);
                throw new ExceptionInInitializerError(ex);
            }
            return sessionFactory;
        }

    public static void saveCar(Date purchaseDate, String modelName, String eType, String mType, String gType) {
        Session session = getSessionFactory().openSession();
        Transaction transaction = null;
 
        try {
            transaction = session.beginTransaction();
            
            Car car = new Car();
    		car.setPurchaseDate(purchaseDate);
    		car.setModelName(modelName);
    		
    		Feature feature = new Feature();
    		feature.seteType(eType);
    		feature.setmType(mType);
    		feature.setgType(gType);
    		
    		car.setFeatures(feature);
    		feature.setCar(car);
    		
    		session.save(feature);
    		session.save(car);
    		transaction.commit();
            System.out.println("Records inserted sucessessfully");
        } catch (HibernateException e) {
            transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        } 
    }
 
    public static void showCars() {
        Session session = getSessionFactory().openSession();
        Transaction transaction = null;
        
        try {
            transaction = session.beginTransaction();
            
            List car = session.createQuery("from Car").list();
 
            for (Iterator iterator = car.iterator(); iterator.hasNext();) {
                Car car1 = (Car) iterator.next();
                System.out.println(car1.getPurchaseDate() + "  "
                        + car1.getModelName() + "  " + car1.getFeatures().getmType()
                        + "   " + car1.getFeatures().geteType()+ "   " + car1.getFeatures().getgType());
            }
            transaction.commit();
        } catch (HibernateException e) {
            transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
 
    public static void deleteCar(long carId) {
 
        Session session = getSessionFactory().openSession();
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();
            
            String queryString = "from Car where carId = :temp";
            Query query = session.createQuery(queryString);
            query.setLong("temp", carId);
            Car Car = (Car) query.uniqueResult();
            session.delete(Car);
            System.out.println("Car records deleted!");
            transaction.commit();
        } catch (HibernateException e) {
            transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
 
    public static void updateFeature(long carId, String mType) {
 
        Session session = getSessionFactory().openSession();
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();
            
            String queryString = "from Feature where carId = :temp";
            Query query = session.createQuery(queryString);
            query.setLong("temp", carId);
            Feature feature = (Feature) query.uniqueResult();
            feature.setmType(mType);
            session.update(feature);
            System.out.println("Car records updated!");
			  transaction.commit();
        } catch (HibernateException e) {
            transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
