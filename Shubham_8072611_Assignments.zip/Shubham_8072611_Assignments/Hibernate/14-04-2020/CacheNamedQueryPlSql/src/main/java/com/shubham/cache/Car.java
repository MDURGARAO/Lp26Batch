package com.shubham.cache;

import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name="Car")
@Cacheable  
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY) 
public class Car {

	@Id
	@GeneratedValue
	@Column(name="carId")
	private int id;
	
	@Column(name="purchaseDate",columnDefinition="date")
	private Date purchaseDate;
	
	@Column(name="modelName")
	private String modelName;
	
	public Car(Date purchaseDate, String modelName) {
		super();
		this.purchaseDate = purchaseDate;
		this.modelName = modelName;
	}

	public Car() {
	}
	@OneToOne
	private Feature feature;

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public Feature getFeatures() {
		return feature;
	}

	public void setFeatures(Feature feature) {
		this.feature = feature;
	}

	@Override
	public String toString(){
		return id+", "+modelName+", "+purchaseDate+", "+feature.getmType()+", "+feature.geteType()+", "+feature.getgType();
	}
}
