package com.shubham.nativeSql;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.*; 

import org.hibernate.HibernateException; 
import org.hibernate.SQLQuery;

public class Main {
   private static SessionFactory factory; 
   public static void main(String[] args) {
      
      try {
         factory = new Configuration().configure().buildSessionFactory();
      } catch (Throwable ex) { 
         System.err.println("Failed to create sessionFactory object." + ex);
         throw new ExceptionInInitializerError(ex); 
      }
      
      Main main = new Main();

//      main.addCar(new Date(), "Renault Duster", "SUV", "Petrol", "Manual");
//      main.addCar(new Date(), "Honda City", "ZX", "Petrol", "Manual");
//      main.addCar(new Date(), "Fortuner", "SUV", "Petrol", "Manual");

      main.listCarValues();
      
      main.listCarDetails();
   }
   
   public void addCar(Date purchaseDate, String modelName, String mType, String eType, String gType){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         CarList car = new CarList(purchaseDate, modelName, mType, eType, gType);
         session.save(car); 
         tx.commit();
      } catch (HibernateException e) {
  
      } finally {
         session.close(); 
      }
   }
   
   public void listCarValues( ){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         String sql = "SELECT modelName, modelType FROM CarList";
         SQLQuery query = session.createSQLQuery(sql);
         query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
         List data = query.list();

         for(Object object : data) {
            Map row = (Map)object;
            System.out.print("Model Name: " + row.get("modelName")); 
            System.out.println(", Model type: " + row.get("modelType")); 
         }
         tx.commit();
      } catch (HibernateException e) {
    
      } finally {
         session.close(); 
      }
   }

   public void listCarDetails( ){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         String sql = "SELECT * FROM CarList";
         SQLQuery query = session.createSQLQuery(sql);
         query.addEntity(CarList.class);
         List cars = query.list();

         for (Iterator iterator = cars.iterator(); iterator.hasNext();){
        	 CarList car = (CarList) iterator.next(); 
            System.out.println(car); 
         }
         tx.commit();
      } catch (HibernateException e) {
         
      } finally {
         session.close(); 
      }
   }
}
