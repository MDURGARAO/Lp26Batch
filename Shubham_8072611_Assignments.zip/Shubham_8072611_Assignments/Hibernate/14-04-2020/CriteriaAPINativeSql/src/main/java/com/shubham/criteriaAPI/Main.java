package com.shubham.criteriaAPI;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.PropertyProjection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

public class Main {
	public static void main(String[] args) {
		System.out.println("Hello");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		Session session = cfg.buildSessionFactory().openSession();

//		Criteria criteria = session.createCriteria(Car.class);
//		List<Car> list = criteria.list();
//		list.forEach(System.out::println);
		
		Criteria criteria = session.createCriteria(Car.class);
//		SimpleExpression expression1 = Restrictions.eq("modelName","Renault Duster");
//		SimpleExpression expression2 = Restrictions.ge("modelName","Honda City");
//		LogicalExpression expression3 = Restrictions.and(expression1,expression2);
//		criteria.add(expression3);
		
//		SimpleExpression expression2 = Restrictions.ge("modelName","Honda City");
//		criteria.add(expression2);
//		criteria.addOrder(Order.desc("id"));
	
//		PropertyProjection property1 = Projections.property("modelName");
		ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("modelName")).add(Projections.property("purchaseDate"));
		
		criteria.setProjection(projectionList);
		
		List<Object[]> list = criteria.list();
		for(Object[] array: list) {
			System.out.println(array[0]+" "+array[1]);
		}
		
		session.close();
	}
}
