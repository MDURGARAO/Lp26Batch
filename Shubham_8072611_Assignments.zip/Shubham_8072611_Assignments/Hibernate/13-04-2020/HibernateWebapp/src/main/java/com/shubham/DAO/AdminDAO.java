package com.shubham.DAO;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.shubham.model.Admin;

public class AdminDAO {
	
	public boolean registerAdmin(String userName, String email, String password) {
		boolean isRecordInserted = false;
		
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		Session session = cfg.buildSessionFactory().openSession();
		Transaction txn = session.beginTransaction();
		
		Query query = session.createQuery("select from Admin a where a.username:=temp");
		query.setString("temp", userName);
		List<Admin> car = query.list();
		if(car.size()==0) {
			Admin admin = new Admin(userName,email,password);
			session.save(admin);
			txn.commit();
			session.close();
			isRecordInserted = true;
		}
		return isRecordInserted;
	}
	
	public boolean loginAdmin(String userName, String password) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		Session session = cfg.buildSessionFactory().openSession();
		Transaction txn = session.beginTransaction();
		
		Query query = session.createQuery("select from Admin a where a.username=:name and a.password=:pass");
		query.setString("name", userName);
		query.setString("pass", password);
		List<Object[]> car = query.list();
		if(car==null) {
			return false;
		}else {
			return true;
		}
	}
}
