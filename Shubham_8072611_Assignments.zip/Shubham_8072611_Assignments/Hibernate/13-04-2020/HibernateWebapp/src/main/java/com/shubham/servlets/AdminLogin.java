package com.shubham.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shubham.DAO.AdminDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/ALogin")
public class AdminLogin extends HttpServlet {

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			AdminDAO admin = new AdminDAO();
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			
			boolean success = admin.loginAdmin(username, password);
			if (success) {
				request.getRequestDispatcher("AddRoom.jsp").forward(request, response);
			} else {
				request.getRequestDispatcher("Admin.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
