package com.shubham.hibernateExample;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
	public static void main(String[] args) {
		
		System.out.println("Hello");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		Session session = cfg.buildSessionFactory().openSession();
		Transaction txn = session.beginTransaction();
		
//		Car car1 = new Car();
//		car1.setPurchaseDate(new Date());
//		car1.setModelName("Fortuner");
//		Feature feature1 = new Feature();
//		feature1.seteType("Petrol");
//		feature1.setmType("SUV");
//		feature1.setgType("Manual");
//		
//		car1.setFeatures(feature1);
//		feature1.setCar(car1);
//		
//		session.save(feature1);
//		session.save(car1);
		
//		Query query = session.createQuery("from Car");
//		List<Car> car = query.list();
//		car.stream().forEach(System.out::println);
		
//		Query query = session.createQuery("from Car");
//		Iterator<Car> list = query.iterate();
//		while(list.hasNext()) {
//			Car car = list.next();
//			System.out.println(car);
//		}
		
//		Query query = session.createQuery("select c.modelName from Car c");
//		List<String> car = query.list();
//		car.stream().forEach(System.out::println);
		
//		Query query = session.createQuery("select c.modelName,c.purchaseDate from Car c");
//		List<Object[]> car = query.list();
//		for(Object[] array: car) {
//			System.out.println(array[0]+" "+array[1]);
//		}
		
//		Query query = session.createQuery("select c.modelName,c.purchaseDate from Car c where c.modelName=:temp");
//		query.setString("temp", new Scanner(System.in).next());
//		List<Object[]> car = query.list();
//		for(Object[] array: car) {
//			System.out.println(array[0]+" "+array[1]);
//		}
		
//		Query query = session.createQuery("from Car");
////	query.setMaxResults(2);
//		query.setFirstResult(1);
//		List<Car> car = query.list();
//		car.stream().forEach(System.out::println);
		
//		Query query = session.createQuery("update Car c set c.modelName='Xylo' where c.id=:id");
//		query.setLong("id",2);
//		query.executeUpdate();
//		query = session.createQuery("from Car");
//		List<Car> car = query.list();
//		car.stream().forEach(System.out::println);
		
//		CarList list = new CarList(new Date(),"Xylo","SUV","Petrol","Manual");
//		session.save(list);
		
//		Query query = session.createQuery("insert into CarList(purchaseDate,modelName) select list.purchaseDate"
//				+ ",list.modelName from Car list" );
//		query.executeUpdate();
//		query = session.createQuery("from CarList");
//		List<Car> car = query.list();
//		car.stream().forEach(System.out::println);
		
//		Query query = session.createQuery("delete from Car c where c.id=1" );
//		query.executeUpdate();
//		query = session.createQuery("from CarList");
//		List<Car> car = query.list();
//		car.stream().forEach(System.out::println);
		
//		Query query = session.createQuery("select new Car(purchaseDate,modelName) from Car");
//		List<Car> car = query.list();
//		for(Car c1: car) {
//			System.out.println(c1.getPurchaseDate()+" "+c1.getModelName());
//		}
		
		txn.commit();
		session.close();
	}
}
