package com.shubham.type2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.SecondaryTable;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
@Table(name="movie")
@SecondaryTable(name="moviedetail")
public class Movie {
    
   @Id
   @GeneratedValue
   private int id;
     
   @Column(name="movieName")
   private String name;
   
   @Column(name="genre", table="moviedetail")
   private String genre;
   
   @Column(name="leadRole", table="moviedetail")
   private String actorName;
   
   @Column(name="releaseYear", table="moviedetail")
   private int releaseYear;

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getGenre() {
	return genre;
}

public void setGenre(String genre) {
	this.genre = genre;
}

public String getActorName() {
	return actorName;
}

public void setActorName(String actorName) {
	this.actorName = actorName;
}

public int getReleaseYear() {
	return releaseYear;
}

public void setReleaseYear(int releaseYear) {
	this.releaseYear = releaseYear;
}

}