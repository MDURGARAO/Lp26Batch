package com.shubham.type3;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
public class Main {
	public static void main(String[] args) {
		System.out.println("Hello");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		Session session = cfg.buildSessionFactory().openSession();
		Transaction txn = session.beginTransaction();

		Music music = new Music();
		music.setId(1);
		music.setSongName("Havana");
		music.setSinger("Camila Cabello");
		music.setAlbum("Camila");
        
		session.save(music);
		txn.commit();
		session.close(); 
	}
}
