package com.shubham.SimpleMapping;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name="Feature1")
public class Features {

	@Id
	@Column(name="carId", unique=true, nullable=false)
	@GeneratedValue
	private int id;
	
	@Column(name="modelType")
	private String mType;
	
	@Column(name="engineType")
	private String eType;
	
	@Column(name="gearType")
	private String gType;
	
	@OneToOne
	@PrimaryKeyJoinColumn
	private Cars car;

	public String getmType() {
		return mType;
	}

	public void setmType(String mType) {
		this.mType = mType;
	}

	public String geteType() {
		return eType;
	}

	public void seteType(String eType) {
		this.eType = eType;
	}

	public String getgType() {
		return gType;
	}

	public void setgType(String gType) {
		this.gType = gType;
	}

	public Cars getCar() {
		return car;
	}

	public void setCar(Cars car) {
		this.car = car;
	}

    
}
