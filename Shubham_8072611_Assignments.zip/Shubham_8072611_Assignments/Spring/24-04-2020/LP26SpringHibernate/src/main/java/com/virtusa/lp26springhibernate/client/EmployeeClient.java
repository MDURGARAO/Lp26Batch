package com.virtusa.lp26springhibernate.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.lp26.springhibernate.repository.EmployeeRepository;
import com.virtusa.lp26springhibernate.model.Employee;

public class EmployeeClient {
	public static void main(String[] args) {
		Employee emp1 = new Employee();
		emp1.setEmployeeId(1);
		emp1.setEmployeeName("Shubham");
		emp1.setSalary(20000);
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-hibernate-config.xml");
		EmployeeRepository repository = context.getBean(EmployeeRepository.class);
		repository.saveEmployee(emp1);
	}
}
