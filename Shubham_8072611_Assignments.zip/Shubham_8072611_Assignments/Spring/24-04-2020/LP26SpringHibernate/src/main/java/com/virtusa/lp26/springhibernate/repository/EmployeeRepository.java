package com.virtusa.lp26.springhibernate.repository;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.virtusa.lp26springhibernate.model.Employee;

@Repository
public class EmployeeRepository {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Transactional
	public void saveEmployee(Employee employee) {
		Session session = sessionFactory.openSession();
		session.save(employee);
		session.close();
	}
}
