package com.shubham.client;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.shubham.bean.Employee;
import com.shubham.bean.EmployeeDAO;

public class Main {
	public static void main(String[] args) {  
	    Resource r=new ClassPathResource("spring-bean.xml");  
	    BeanFactory factory=new XmlBeanFactory(r);  
	      
	    EmployeeDAO dao=(EmployeeDAO)factory.getBean("dao");  
	      
	    Employee e=new Employee();
	    e.setId(1);
	    e.setName("shubham");  
	    e.setSalary(20000);  
	      
	    dao.saveEmployee(e);    
	}   
}
