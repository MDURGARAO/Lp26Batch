package com.shubham.bean;

import java.util.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
 

public class EmployeeDAO {  

	HibernateTemplate template;  
 
	public HibernateTemplate getTemplate() {
		return template;
	}

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}

	public void saveEmployee(Employee e){ 
		SessionFactory sessionFactory = template.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(e);
		session.getTransaction().commit();
	}  
 
	public void updateEmployee(Employee e){  
		template.update(e);  
	}  

	public void deleteEmployee(Employee e){  
		template.delete(e);  
	}  
 
	public Employee getById(int id){  
		Employee e=(Employee)template.get(Employee.class,id);  
		return e;  
	}  

	public List<Employee> getEmployees(){  
		List<Employee> list=new ArrayList<Employee>();  
		list=template.loadAll(Employee.class);  
		return list;  
	}  
}
