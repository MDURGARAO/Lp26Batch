package com.shubham.DAO;


import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import com.shubham.model.Employee;

public class EmployeeDAOSimpleTemplate {
	SimpleJdbcTemplate jdbcTemplate;

	public EmployeeDAOSimpleTemplate() {
		
	}
	
	public EmployeeDAOSimpleTemplate(SimpleJdbcTemplate jdbcTemplate) {
		super();
		this.jdbcTemplate = jdbcTemplate;
	}  
	
	public SimpleJdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(SimpleJdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int update (Employee e){  
		//String query="update employee set name=? where id=?";  
		//return jdbcTemplate.update(query,e.getName(),e.getId());  
		  
		String query="update employee set name=?,salary=? where id=?";  
		return jdbcTemplate.update(query,e.getName(),e.getSalary(),e.getId());  
		}  
}
