package com.shubham.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shubham.DAO.EmployeeDAOTemplate;
import com.shubham.model.Employee;

public class MainTemplate {
	public static void main(String[] args) {  
	    ApplicationContext ctx=new ClassPathXmlApplicationContext("spring-template.xml");  
	      
	    EmployeeDAOTemplate dao=(EmployeeDAOTemplate)ctx.getBean("employeeDAO");  
	    dao.saveEmployee(new Employee(1,"Shubham",20000));  
	 
//	    dao.saveEmployee(new Employee(2,"Aman",21000));  

//	    dao.updateEmployee(new Employee(1,"Shubham",25000)); 
	       
//	    Employee e=new Employee(); 
//	    e.setId(2); 
//	    dao.deleteEmployee(e); 
	      
	}  
}
