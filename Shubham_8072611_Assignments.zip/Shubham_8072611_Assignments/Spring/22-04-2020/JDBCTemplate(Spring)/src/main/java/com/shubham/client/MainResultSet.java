package com.shubham.client;

import java.util.List;
import org.springframework.context.ApplicationContext;  
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shubham.DAO.EmployeeDAOResultSet;
import com.shubham.model.Employee; 

public class MainResultSet {
	public static void main(String[] args) {  
	    ApplicationContext ctx=new ClassPathXmlApplicationContext("spring-resultSet.xml");  
	    EmployeeDAOResultSet dao=(EmployeeDAOResultSet)ctx.getBean("edao");  
	    List<Employee> list=dao.getAllEmployees();  
	          
	    for(Employee e:list)  
	        System.out.println(e);  
	          
	    } 
}
