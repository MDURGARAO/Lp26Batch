package com.shubham.client;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.shubham.DAO.EmployeeDAOSimpleTemplate;
import com.shubham.model.Employee;

public class MainSimpleTemplate {
	public static void main(String[] args) {  
	      
	    Resource r=new ClassPathResource("spring-simpleTemplate.xml");  
	    BeanFactory factory=new XmlBeanFactory(r);  
	      
	    EmployeeDAOSimpleTemplate dao=(EmployeeDAOSimpleTemplate)factory.getBean("edao");  
	    dao.update(new Employee(3,"Ayush",27000));  
	}  
}
