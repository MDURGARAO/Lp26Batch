package com.shubham.client;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.shubham.DAO.EmployeeDAONamedParameter;
import com.shubham.model.Employee;

public class MainNamedParameter {
	public static void main(String[] args) {  
	      
	    Resource r=new ClassPathResource("spring-nParameter.xml");  
	    BeanFactory factory=new XmlBeanFactory(r);  
	      
	    EmployeeDAONamedParameter dao=(EmployeeDAONamedParameter)factory.getBean("edao");  
	    dao.save(new Employee(3,"Aman",22000));  
	      
	  } 
}
