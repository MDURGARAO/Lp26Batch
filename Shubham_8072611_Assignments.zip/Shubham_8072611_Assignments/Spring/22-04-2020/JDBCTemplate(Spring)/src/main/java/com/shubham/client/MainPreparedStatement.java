package com.shubham.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shubham.DAO.EmployeeDAOPreparedStatement;
import com.shubham.model.Employee;

public class MainPreparedStatement {
	public static void main(String[] args) {  
	    ApplicationContext ctx=new ClassPathXmlApplicationContext("spring-pStatement.xml");  
	          
	    EmployeeDAOPreparedStatement eDAO = (EmployeeDAOPreparedStatement)ctx.getBean("edao");  
	    eDAO.saveEmployeeByPreparedStatement(new Employee(2,"Manav",20000));  
	}  
}
