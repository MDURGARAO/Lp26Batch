package com.shubham.DAO;

import java.sql.PreparedStatement;  
import java.sql.SQLException;  
import org.springframework.dao.DataAccessException;  
import org.springframework.jdbc.core.PreparedStatementCallback;  
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.shubham.model.Employee;

import java.util.*; 

public class EmployeeDAONamedParameter {
	NamedParameterJdbcTemplate jdbcTemplate;  

	public EmployeeDAONamedParameter() {
	}

	public EmployeeDAONamedParameter(NamedParameterJdbcTemplate jdbcTemplate) {
		super();
		this.jdbcTemplate = jdbcTemplate;
	}

	public NamedParameterJdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(NamedParameterJdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public  void save (Employee e){  
	String query="insert into employee values (:id,:name,:salary)";  
	  
	Map<String,Object> map=new HashMap<String,Object>();  
	map.put("id",e.getId());  
	map.put("name",e.getName());  
	map.put("salary",e.getSalary());  
	  
	jdbcTemplate.execute(query,map,new PreparedStatementCallback() {  
	    public Object doInPreparedStatement(PreparedStatement ps)  
	            throws SQLException, DataAccessException {  
	        return ps.executeUpdate();  
	    }  
	});  
	}
}
