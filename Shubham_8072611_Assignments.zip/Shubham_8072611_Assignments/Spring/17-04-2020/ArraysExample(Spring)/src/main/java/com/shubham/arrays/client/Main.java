package com.shubham.arrays.client;

import java.io.FileNotFoundException;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.shubham.arrays.bean.ArrayExample;

public class Main {
	public static void main(String[] args) throws BeansException, FileNotFoundException {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-bean.xml");
		ArrayExample ex1 = context.getBean(ArrayExample.class,"arrayExampleBean");
		System.out.println(ex1);
	}
}
