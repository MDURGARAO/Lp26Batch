package com.shubham.hasarelationship.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shubham.hasarelationship.bean.Car;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-bean.xml");
		Car car1 = context.getBean(Car.class,"carBean");
		System.out.println(car1);
	}
}
