package com.shubham.hasarelationship.bean;

public class Feature {
	private String mType;
	private String eType;
	private String gType;

	public String getmType() {
		return mType;
	}

	public void setmType(String mType) {
		this.mType = mType;
	}

	public String geteType() {
		return eType;
	}

	public void seteType(String eType) {
		this.eType = eType;
	}

	public String getgType() {
		return gType;
	}

	public void setgType(String gType) {
		this.gType = gType;
	}

	@Override
	public String toString() {
		return "Features: [mType=" + mType + ", eType=" + eType + ", gType=" + gType + "]";
	}
	
}
