package com.shubham.hasarelationship.bean;

public class Car {
	private String modelName;
	private Feature feature;

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public Feature getFeature() {
		return feature;
	}

	public void setFeature(Feature feature) {
		this.feature = feature;
	}

	@Override
	public String toString() {
		return "Car: [modelName=" + modelName +"]\n"+feature;
	}

}
