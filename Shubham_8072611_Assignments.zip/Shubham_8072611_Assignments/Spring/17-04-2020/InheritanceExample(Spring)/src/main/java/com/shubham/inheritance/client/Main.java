package com.shubham.inheritance.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shubham.inheritance.bean.Address;
import com.shubham.inheritance.bean.LocalAddress;

public class Main {
	 public static void main(String[] args) {
	      ApplicationContext context = new ClassPathXmlApplicationContext("spring-bean.xml");
	      
	      Address address = context.getBean(Address.class,"addressBean");
	      System.out.println("Parent address:");
	      System.out.println(address.getCountry());
	      System.out.println(address.getZip());
	      
	      LocalAddress localAddress = context.getBean(LocalAddress.class, "localAddressBean");
	      System.out.println("Child local address:");
	      System.out.println(localAddress.getCity());
	      System.out.println(localAddress.getState());
	      System.out.println(localAddress.getCountry());
	      System.out.println(localAddress.getZip());
	   }
}
