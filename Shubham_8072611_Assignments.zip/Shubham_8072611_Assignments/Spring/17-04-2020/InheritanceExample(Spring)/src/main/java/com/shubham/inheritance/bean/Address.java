package com.shubham.inheritance.bean;

public class Address {
	String country;
	String zip;
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	@Override
	public String toString() {
		return "Address [country=" + country + ", zip=" + zip + "]";
	}
	
}
