package com.shubham.simplevalues.bean;

public class CalculatorFactory {
	public CalculatorFactory() {
		
	}
	public static Calculator checkCalculator(int desiredOutput) {
		Calculator cal = new Calculator();
		if(desiredOutput==50) {
			cal.setNum1(25);
			cal.setNum2(25);
		}
		if(desiredOutput==80) {
			cal.setNum1(40);
			cal.setNum2(40);
		}
		else {
			System.out.println("Pass either 50 or 80");
		}
		return cal;
	}
	
}
