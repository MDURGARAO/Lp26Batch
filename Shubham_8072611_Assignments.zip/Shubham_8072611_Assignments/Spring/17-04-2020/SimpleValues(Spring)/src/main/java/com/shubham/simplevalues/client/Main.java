package com.shubham.simplevalues.client;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.shubham.simplevalues.bean.Calculator;

public class Main {
	public static void main(String[] args) {
		Calculator cal1 = new Calculator();
		cal1.setNum1(15);
		cal1.setNum2(10);
		System.out.println("Normal add:"+cal1.add());
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-bean.xml");
//		Resource resource = new ClassPathResource("spring-bean.xml");
//        BeanFactory bf = new XmlBeanFactory(resource);
		Calculator cal = (Calculator)context.getBean("factoryBean");
		System.out.println("Factory add:" +cal.add());
	}
}
