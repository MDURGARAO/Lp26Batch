package com.shubham.collection.bean;

import java.util.List;

public class ListExample {
	List nameList;

	public List getNameList() {
		return nameList;
	}

	public void setNameList(List nameList) {
		this.nameList = nameList;
	}

	@Override
	public String toString() {
		return "ListExample [nameList=" + nameList + "]";
	}

	
}
