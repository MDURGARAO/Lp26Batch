package com.shubham.collection.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shubham.collection.bean.ListExample;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-bean.xml");
		ListExample ex1 = context.getBean(ListExample.class,"listExampleBean");
		System.out.println(ex1);
	}
}
