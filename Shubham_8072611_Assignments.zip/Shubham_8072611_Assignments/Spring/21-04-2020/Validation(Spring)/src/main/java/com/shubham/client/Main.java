package com.shubham.client;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.ObjectError;

import com.shubham.bean.Employee;
import com.shubham.bean.EmployeeValidator;

public class Main {
public static void main(String[] args) {
		
		ApplicationContext cfg = new ClassPathXmlApplicationContext("spring-bean.xml");
		Employee emp = (Employee)cfg.getBean("employee");
		EmployeeValidator empVal = (EmployeeValidator)cfg.getBean("employeeValidator");
		Map<String, Employee> map = new HashMap<String, Employee>();
		MapBindingResult err = new MapBindingResult(map, Employee.class.getName());
		
		empVal.validate(emp, err);
		List<ObjectError> list = err.getAllErrors();
		for(ObjectError objErr : list)
		{
			System.out.println(objErr.getDefaultMessage());
		}
	}
}
