package com.shubham.bean;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

public class EmployeeValidator implements Validator{

	public boolean supports(Class<?> clazz) {
		return Employee.class.equals(clazz);
	}

	public void validate(Object obj, Errors errors) {
		ValidationUtils.rejectIfEmpty(errors, "name", "field.required","name is required");
		ValidationUtils.rejectIfEmpty(errors, "id", "field.required","id is required");
		ValidationUtils.rejectIfEmpty(errors, "sal", "field.required","salary is required");
       
		Employee emp = (Employee) obj;
        if (emp.getAge() < 0) {
        	errors.rejectValue("age", "negativevalue","age is not been negative");
        } else if (emp.getAge()> 110) {
        	errors.rejectValue("age", "too.darn.old","age should be less than 110");
        }
	}
}
