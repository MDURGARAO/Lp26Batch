package com.shubham.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shubham.xmlshortcut.TestBean;

public class Main {
	public static void main(String[] args) throws InterruptedException {
		ApplicationContext context = new ClassPathXmlApplicationContext("c-name.xml");
		TestBean db = (TestBean)context.getBean("testBean");
		db.run();
	}
}
