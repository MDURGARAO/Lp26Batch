package com.shubham.xmlshortcut;

public interface DBConnection {
	public void connect();
	public void disconnect();
}
