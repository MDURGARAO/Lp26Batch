package com.shubham.dependency.bean;

public class TestBean {
	DBConnection dbType1;
	//DBConnection dbType2;
	
	public void setDbType1(DBConnection dbType1) {
		this.dbType1 = dbType1;
	}
	
public TestBean(DBConnection dbType1) {
		super();
		this.dbType1 = dbType1;
	}

	//	public void setDbType2(DBConnection dbType2) {
//		this.dbType2 = dbType2;
//	}
	public void run() throws InterruptedException {
		dbType1.connect();
		Thread.sleep(2000);
		dbType1.disconnect();
		Thread.sleep(2000);
//		System.out.println("Switching database...");
//		Thread.sleep(2000);
//		dbType2.connect();
//		Thread.sleep(2000);
//		dbType2.disconnect();
//		Thread.sleep(2000);
	}
}
