package com.shubham.dependency.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shubham.dependency.bean.TestBeanAnnotation;

public class MainAnnotation {
	public static void main(String[] args) throws InterruptedException {
		ApplicationContext context = new ClassPathXmlApplicationContext("annotation.xml");
		TestBeanAnnotation db = (TestBeanAnnotation)context.getBean("annotationBean");
		db.run();
	}
}
