package com.shubham.dependency.bean;

public interface DBConnection {
	public void connect();
	public void disconnect();
}
