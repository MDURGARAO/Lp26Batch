package com.shubham.dependency.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shubham.dependency.bean.TestBean;

public class Main {
	public static void main(String[] args) throws InterruptedException {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-bean.xml");
		TestBean db = (TestBean)context.getBean("testBean");
		db.run();
	}
}
