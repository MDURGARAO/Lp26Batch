package com.shubham.dependency.bean;

public class OracleDB implements DBConnection{
	public void connect() {
		System.out.println("Oracle is connecting now....");
	}
	
	public void disconnect() {
		System.out.println("Oracle is disconnecting now....");
	}
}
