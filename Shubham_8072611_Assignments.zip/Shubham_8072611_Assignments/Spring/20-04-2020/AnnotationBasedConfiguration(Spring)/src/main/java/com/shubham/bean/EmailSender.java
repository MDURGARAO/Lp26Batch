package com.shubham.bean;

public class EmailSender {
	private String message;

	public void setMessage(String message){
		this.message  = message;
	}
	public void getMessage(){
		System.out.println("Your mail is : " + message);
	}
}
