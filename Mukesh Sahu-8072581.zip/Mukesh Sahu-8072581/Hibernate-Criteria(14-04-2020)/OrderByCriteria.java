package com.virtusa.hibernate.criteria;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import com.virtusa.hibernate.embedded.Employee;
import com.virtusa.hibernate.util.HibernateUtil;

public class OrderByCriteria {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Criteria criteria=session.createCriteria(Employee.class);
		ProjectionList projectionlist=Projections.projectionList();
		projectionlist.add(Projections.property("id")).add(Projections.property("name")).add(Projections.property("salary"));
		criteria.setProjection(projectionlist);
		SimpleExpression expression1=Restrictions.gt("salary",10000.00);
		SimpleExpression expression2=Restrictions.ge("id",1);
		LogicalExpression exp3=Restrictions.and(expression1,expression2);
		criteria.add(exp3);
		criteria.addOrder(Order.desc("salary"));
		List<Object[]> list=criteria.list();
		for (Object[] objects : list) {
			for(int i=0;i<objects.length;i++)
			{
				System.out.print(objects[i]+" ");
			}
			System.out.println();
		}
	}

}
