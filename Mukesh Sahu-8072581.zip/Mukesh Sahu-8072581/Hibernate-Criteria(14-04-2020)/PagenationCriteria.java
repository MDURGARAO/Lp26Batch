package com.virtusa.hibernate.criteria;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import com.virtusa.hibernate.embedded.Employee;
import com.virtusa.hibernate.util.HibernateUtil;

public class PagenationCriteria {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Criteria criteria=session.createCriteria(Employee.class);
		criteria.setFirstResult(1);
		criteria.setMaxResults(2);
		
		List<Employee> list=criteria.list();
		
		list.forEach(System.out::println);
		session.close();
	}

}
