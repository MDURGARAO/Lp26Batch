package com.virtusa.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Calender {
@Id
private String date;
private String topic;
@Override
public String toString() {
	return "Calender [date=" + date + ", topic=" + topic + "]";
}
public Calender(String date, String topic) {
	this.date = date;
	this.topic = topic;
}
public Calender() {
	super();
	// TODO Auto-generated constructor stub
}
public String getDate() {
	return date;
}
public String getTopic() {
	return topic;
}
public void setDate(String date) {
	this.date = date;
}
public void setTopic(String topic) {
	this.topic = topic;
}

}
