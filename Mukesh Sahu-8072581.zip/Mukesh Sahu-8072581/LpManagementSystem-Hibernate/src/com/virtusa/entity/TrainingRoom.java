package com.virtusa.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class TrainingRoom {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int roomId;
private String roomName;
private int roomCapacity;
private String roomStatus="empty";
@Embedded
private Address address;
public TrainingRoom() {
	super();
	// TODO Auto-generated constructor stub
}

public TrainingRoom(String roomName, int roomCapacity, String roomStatus) {
	this.roomName = roomName;
	this.roomCapacity = roomCapacity;
	this.roomStatus = roomStatus;
}

public int getRoomId() {
	return roomId;
}
public String getRoomName() {
	return roomName;
}
public int getRoomCapacity() {
	return roomCapacity;
}
public String getRoomStatus() {
	return roomStatus;
}
public Address getAddress() {
	return address;
}
public void setRoomId(int roomId) {
	this.roomId = roomId;
}
public void setRoomName(String roomName) {
	this.roomName = roomName;
}
public void setRoomCapacity(int roomCapacity) {
	this.roomCapacity = roomCapacity;
}
public void setRoomStatus(String roomStatus) {
	this.roomStatus = roomStatus;
}
public void setAddress(Address address) {
	this.address = address;
}
@Override
public String toString() {
	return "TrainingRoom [roomId=" + roomId + ", roomName=" + roomName + ", roomCapacity=" + roomCapacity
			+ ", roomStatus=" + roomStatus + ", address=" + address + "]";
}


}
