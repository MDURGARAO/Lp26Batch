package com.virtusa.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Lp {
	
private	String name;
@Id
private	String email;
private	String password;
private	long mobile;
private	String profession;
private	String address;
private	String gender;
public Lp() {
	super();
	// TODO Auto-generated constructor stub
}
public Lp(String name, String email, String password, long mobile, String profession, String address, String gender) {
	this.name = name;
	this.email = email;
	this.password = password;
	this.mobile = mobile;
	this.profession = profession;
	this.address = address;
	this.gender = gender;
}
@Override
public String toString() {
	return "Lp [name=" + name + ", email=" + email + ", password=" + password + ", mobile=" + mobile + ", profession="
			+ profession + ", address=" + address + ", gender=" + gender + "]";
}
public String getName() {
	return name;
}
public String getEmail() {
	return email;
}
public String getPassword() {
	return password;
}
public long getMobile() {
	return mobile;
}
public String getProfession() {
	return profession;
}
public String getAddress() {
	return address;
}
public String getGender() {
	return gender;
}
public void setName(String name) {
	this.name = name;
}
public void setEmail(String email) {
	this.email = email;
}
public void setPassword(String password) {
	this.password = password;
}
public void setMobile(long mobile) {
	this.mobile = mobile;
}
public void setProfession(String profession) {
	this.profession = profession;
}
public void setAddress(String address) {
	this.address = address;
}
public void setGender(String gender) {
	this.gender = gender;
}
}
