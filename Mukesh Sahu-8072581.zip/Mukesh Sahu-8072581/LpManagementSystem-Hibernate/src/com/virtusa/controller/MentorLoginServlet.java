package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.virtusa.entity.Lp;
import com.virtusa.entity.Mentor;
import com.virtusa.util.HibernateUtil;

/*@WebServlet(urlPatterns="/mentorlogin"
)*/
public class MentorLoginServlet extends HttpServlet {
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	String email=req.getParameter("em");
	String password=req.getParameter("pass");
	resp.setContentType("text/html");  
    PrintWriter out = resp.getWriter();  
    Session session=null;
    String query1="from Mentor where email=? and password=?";
try {
		
		SessionFactory factory=HibernateUtil.getFactory();
		  session=factory.openSession();
		 Transaction transaction=session.beginTransaction();
		 Query query=session.createQuery(query1);
		 query.setString(0, email);
		 query.setString(1, password);
		 List<Mentor> list=query.list();
if(list.size()>0)
{
	req.getRequestDispatcher("/mentorService.jsp").forward(req, resp); 
}else {out.print("Sorry UserName or Password Error! please try again");  
req.getRequestDispatcher("/mentorLogin.jsp").include(req, resp); 
	 } 
	
	} catch (Exception e) {
		
		e.printStackTrace();
	}
	finally
	{
		session.close();
	}
	System.out.println("everything is working fine");
}

}
