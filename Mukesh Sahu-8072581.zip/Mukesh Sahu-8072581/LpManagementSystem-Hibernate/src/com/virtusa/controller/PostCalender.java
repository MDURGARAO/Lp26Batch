package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.entity.Calender;
import com.virtusa.util.HibernateUtil;

public class PostCalender extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String[] dates=req.getParameterValues("date");
		String[] topics=req.getParameterValues("topic");
		resp.setContentType("text/html");  
	    PrintWriter out = resp.getWriter();  
	    Session session=null;
	    Transaction transaction=null;
		
		try {
			SessionFactory factory=HibernateUtil.getFactory();
		 session=factory.openSession();
		 transaction=session.beginTransaction();
		 int count=0;
		 for (int i=0;i<dates.length;i++) {
			session.persist(new Calender(dates[i], topics[i]));
			count++;
			
		}
		
		
		if(dates.length==count)
		{
			out.print("Successfully you have published calender ");
			req.getRequestDispatcher("/mentorService.jsp").include(req, resp);
		} 
		else
		{ transaction.rollback();
		out.print("Something went wrong  when publishing calender please try again");
		req.getRequestDispatcher("/mentorService.jsp").include(req, resp);
			
		}
		
		} catch (Exception e) {
			e.printStackTrace();
			 transaction.rollback();
			out.print("Failed to publish calender- Date should not be duplicate please try with other Date");
			req.getRequestDispatcher("/postCalender.jsp").include(req, resp);
		}
		finally
		{
			session.close();
		}
		System.out.println("everything is working fine in publish calender");
		

	}
}
