package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.virtusa.entity.*;
import com.virtusa.util.HibernateUtil;

public class CreateBatch extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String batchName=req.getParameter("bname");
		resp.setContentType("text/html");  
	    PrintWriter out = resp.getWriter();  
		Session session=null;
		Transaction transaction=null;
		String query1="from Lp";
		
		try {
			SessionFactory factory=HibernateUtil.getFactory();
			  session=factory.openSession();
			  transaction=session.beginTransaction();
			  BatchDetail batch=new BatchDetail(batchName);
	Query query=session.createQuery(query1);
	List<Lp> list=query.list();
	System.out.println("list size"+list.size());
	List<Trainee> trainees=new ArrayList();
	int count=0;
	for (Lp lp : list) {
		String name=lp.getName();
		String email=lp.getEmail();
		long mobile=lp.getMobile();
		String profession=lp.getProfession();
		String address=lp.getAddress();
		String gender=lp.getGender();
		String password=lp.getPassword();
		trainees.add(new Trainee(name, email, mobile, profession, address, gender));
		count++;
	}
	batch.setTrainee(trainees);
	session.save(batch);
	
	if(count==list.size())
	{transaction.commit();
		out.print("Batch has been created successfully !");
		req.getRequestDispatcher("/mentorService.jsp").include(req, resp); 
	}
	else  {
		transaction.rollback();
	out.print("error while creating Batch!");
		req.getRequestDispatcher("/mentorService.jsp").include(req, resp); 
	}
		
		} 
	catch (Exception  e) {
		e.printStackTrace();
		transaction.rollback();
		
		out.print("Exception while creating Batch  !");
		req.getRequestDispatcher("/mentorService.jsp").include(req, resp); 
			
		}
		finally
		{
			session.close();
		}
		System.out.println("everything is working fine in create batch");
	}

}
