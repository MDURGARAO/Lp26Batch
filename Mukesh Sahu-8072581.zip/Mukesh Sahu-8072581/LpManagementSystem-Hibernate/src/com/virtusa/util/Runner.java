package com.virtusa.util;

public class Runner {

	public static void main(String[] args) {
		HibernateUtil.getFactory();
	}

}
