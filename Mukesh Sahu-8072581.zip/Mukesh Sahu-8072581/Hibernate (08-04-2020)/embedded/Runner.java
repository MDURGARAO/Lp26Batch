package com.virtusa.hibernate.embedded;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
	
Session session=factory.openSession();
Transaction transaction=session.beginTransaction();
Address address1=new Address("Bhopal", "madhya pradesh", 534456l, "rachana nagar");
Address address2=new Address("Chennai", "Tamil nadu", 534459l, "rachana nagar");
Address address3=new Address("Sagar", "madhya pradesh", 5344567, "rachana nagar");

Employee employee1=new Employee("mukesh sahu", "software",30000)	;
Employee employee2=new Employee("chandan", "testing",20000)	;
Employee employee3=new Employee("pranjal", "marketing",10000)	;
employee1.setAddress(address1);
employee2.setAddress(address2);
employee3.setAddress(address3);
session.save(employee1);
session.save(employee2);
session.save(employee3);
/*Employee emp=session.get(Employee.class, 1);
System.out.println(emp);
emp.setName("ravindra");
//session.update(emp);
session.delete(emp);*/


transaction.commit();
session.close();
		
	}

}
