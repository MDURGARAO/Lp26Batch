package com.virtusa.hibernate.inheritance;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;
@Entity
@PrimaryKeyJoinColumn(name="ID")  
public class Tester extends Employee{
	private String profile;
	private Date dateOfJoin;
	
	public Tester( String employeeName, double employeeSalary, long contact,String profile,Date date) {
		super(employeeName, employeeSalary, contact);
		this.profile=profile;
		this.dateOfJoin=date;
	}

	public Tester()
	{
		
	}

	public String getProfile() {
		return profile;
	}

	public Date getDateOfJoin() {
		return dateOfJoin;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public void setDateOfJoin(Date dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
		public int getEmployeeId() {
		return employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
}
