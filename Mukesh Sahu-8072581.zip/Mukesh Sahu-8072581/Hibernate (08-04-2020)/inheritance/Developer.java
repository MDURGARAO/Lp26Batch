package com.virtusa.hibernate.inheritance;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;
@Entity
@PrimaryKeyJoinColumn(name="ID")  
public class Developer extends Employee {
	private String project;
	private int experience;
	
	public String getProject() {
		return project;
	}


	public int getExperience() {
		return experience;
	}


	public void setProject(String project) {
		this.project = project;
	}


	public void setExperience(int experience) {
		this.experience = experience;
	}


	public Developer( String employeeName, double employeeSalary, long contact,String project,int ex) {
		super( employeeName, employeeSalary, contact);
		this.project=project;
		this.experience=ex;
		
	}

	
	public Developer()
	{
		
	}
}
