package com.virtusa.hibernate.hql;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.virtusa.hibernate.embedded.Address;
import com.virtusa.hibernate.embedded.Employee;
import com.virtusa.hibernate.util.HibernateUtil;

public class HqlRunner {
	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
		Session session=factory.openSession();
		Session session1=factory.openSession();
		Transaction transaction=session.beginTransaction();
		
		/*Query query=session.createQuery("from Employee");
		
		
		List<Employee> list=query.list();
		list.forEach(System.out::println);*/
		
		Employee emp1=session.get(Employee.class, 1);
		System.out.println(emp1);
		session.close();
		Employee emp2=session1.get(Employee.class, 1);
		System.out.println(emp2);
/*Query query1=session.createQuery("from Employee");
		
		
		List<Employee> list1=query1.list();
		list1.forEach(System.out::println);
		*/
		
		session.close();
	}
}
