package org.virtusa.hibernate;


public class Person
{
    public  void play()
    {
        System.out.println( "person is playing" );
    }
}
