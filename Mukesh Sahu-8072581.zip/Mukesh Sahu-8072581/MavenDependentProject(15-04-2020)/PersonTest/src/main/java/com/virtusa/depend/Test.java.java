package com.virtusa.depend;
import org.virtusa.hibernate.Person;
 class Test 
{
    public static void main( String[] args )
    {
        Person person=new Person();
        person.play();

    }
}
