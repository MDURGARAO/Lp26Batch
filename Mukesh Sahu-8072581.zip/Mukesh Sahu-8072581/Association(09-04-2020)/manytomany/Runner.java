package com.virtusa.hibernate.manytomany;


import java.util.Arrays;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.hibernate.inheritance.Tester;
import com.virtusa.hibernate.util.HibernateUtil;


public class Runner {

	public static void main(String[] args) 
	{
		SessionFactory factory=HibernateUtil.getFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		/*Teacher shishra = null,raghu = null,shashi = null,nikhila = null,gautam = null;
		
		Student mukesh=new Student("mukesh","java,programming","3");
		Student rahul=new Student("rahul","sql,java","3");
		Student chandan=new Student("chandan","java,sql,html","3");
		Student abhinav=new Student("abhinav","java,jdbc","3");
		
		
		shishra=new Teacher("shishra","java","5 years",Arrays.asList(mukesh,rahul,abhinav,chandan));
		 raghu=new Teacher("raghu","programming","5 years",Arrays.asList(mukesh,rahul));
		 shashi=new Teacher("shashi","html","5 years",Arrays.asList(chandan));
		 nikhila=new Teacher("nikhila","sql","5 years",Arrays.asList(rahul));
		 gautam=new Teacher("gautam","jdbc","5 years",Arrays.asList(mukesh,rahul));
		 mukesh.setTeachers(Arrays.asList(shishra,raghu));
		 rahul.setTeachers(Arrays.asList(shishra,raghu,nikhila));
		 chandan.setTeachers(Arrays.asList(shishra,shashi));
		 abhinav.setTeachers(Arrays.asList(shishra,gautam));
		 
		 session.save(mukesh);
		 session.save(rahul);
		 session.save(chandan);
		 session.save(abhinav);
		 
		 session.save(shishra);
		 session.save(raghu);
		 session.save(shashi);
		 session.save(nikhila);
		 session.save(gautam);*/
	Student  student=session.get(Student.class, 1);
		System.out.println(student);
		student.setName("prateek");
		//session.update(student);
		session.delete(student);

		 transaction.commit();
		
		 session.close();
		
		
		
	}

}
