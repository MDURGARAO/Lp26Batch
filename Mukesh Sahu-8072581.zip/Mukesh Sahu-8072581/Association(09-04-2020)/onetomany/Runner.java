package com.virtusa.hibernate.onetomany;

import java.util.Arrays;
import java.util.List;

//import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
	
Session session=factory.openSession();
Transaction transaction=session.beginTransaction();
/*Student s1=new Student("deepak",9993200768L);
Student s2=new Student("vivek",9993200768L);
Student s3=new Student("pranjal",9993200768L);
List<Student> students=Arrays.asList(s1,s2,s3);
Class_Room class1=new Class_Room("blue", students);	
session.save(class1);*/
Student student=session.get(Student.class, 1);
System.out.println(student);
student.setStudentContact(8770746087l);
//session.update(student);
session.delete(student);

transaction.commit();
session.close();
		
	}

}
