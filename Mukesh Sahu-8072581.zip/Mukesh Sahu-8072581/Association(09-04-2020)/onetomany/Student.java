package com.virtusa.hibernate.onetomany;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int studentId;
private String studentName;
private long studentContact;
public int getStudentId() {
	return studentId;
}
public String getStudentName() {
	return studentName;
}
public long getStudentContact() {
	return studentContact;
}
public void setStudentId(int studentId) {
	this.studentId = studentId;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
public void setStudentContact(long studentContact) {
	this.studentContact = studentContact;
}
public Student() {
	super();
	// TODO Auto-generated constructor stub
}
public Student(String studentName, long studentContact) {
	this.studentName = studentName;
	this.studentContact = studentContact;
}
}
