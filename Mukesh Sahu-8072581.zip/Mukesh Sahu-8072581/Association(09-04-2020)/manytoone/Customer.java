package com.virtusa.hibernate.manytoone;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Customer {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int customerId;
private String customerName;
private long customerContact;
@ManyToOne(cascade=CascadeType.ALL)
private Shop shop;
public Shop getShop() {
	return shop;
}
public void setShop(Shop shop) {
	this.shop = shop;
}
public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
public int getCustomerId() {
	return customerId;
}
public String getCustomerName() {
	return customerName;
}
public long getCustomerContact() {
	return customerContact;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public void setCustomerContact(long customerContact) {
	this.customerContact = customerContact;
}
public Customer(String customerName, long customerContact) {
	this.customerName = customerName;
	this.customerContact = customerContact;
}

}
