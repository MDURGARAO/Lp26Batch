package com.virtusa.hibernate.manytoone;

import java.util.Arrays;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
	
Session session=factory.openSession();
Transaction transaction=session.beginTransaction();
/*Customer c1=new Customer("deepak",9993200768L);
Customer c2=new Customer("vivek",9993200768L);
Customer c3=new Customer("pranjal",9993200768L);
Shop shop=new Shop("Dmart","chennai");	
c1.setShop(shop);
c2.setShop(shop);
c3.setShop(shop);
session.save(c1);
session.save(c2);
session.save(c3);*/
Customer customer=session.get(Customer.class, 1);
System.out.println(customer);
customer.setCustomerContact(7354347878l);
//session.update(Customer);
session.delete(customer);


transaction.commit();
session.close();
		
	}

}
