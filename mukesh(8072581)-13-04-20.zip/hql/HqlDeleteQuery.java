package com.virtusa.hibernate.hql;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.virtusa.hibernate.util.HibernateUtil;

public class HqlDeleteQuery {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("delete from Employee where id= :empId");
		
		
		query.setParameter("empId", new Scanner(System.in).nextInt());
		
		query.executeUpdate();
	}

}
