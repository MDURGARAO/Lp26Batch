package com.virtusa.hibernate.hql;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.virtusa.hibernate.util.HibernateUtil;

public class HqlOrderByQuery {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("select id,name,dept from Employee "
				                        + "order by id desc");
		List<Object[]> list=query.list();
		
		for (Object[] objects : list) {
			for(int i=0;i<objects.length;i++)
			{
				System.out.print(objects[i]+" ");
			}
			System.out.println();
		}
	
	}

}
