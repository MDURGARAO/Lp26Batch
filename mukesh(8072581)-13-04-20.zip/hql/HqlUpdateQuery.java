package com.virtusa.hibernate.hql;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.virtusa.hibernate.util.HibernateUtil;

public class HqlUpdateQuery {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		
		Query query=session.createQuery("update Employee set name=:empName where id=?");
		
		
		query.setParameter(0, new Scanner(System.in).nextInt());
		
		query.executeUpdate();

	}

}
