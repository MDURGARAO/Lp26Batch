package com.virtusa.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.OneToOne.University1;
import com.hibernate.OneToOne.UniversityDetails;
import com.hibernate.oneToMany.University;

public class OneToOne_Main {
	
	public static void main(String[] args) {
		
		UniversityDetails uni = new UniversityDetails();
		uni.setUniversityDetailID(0100);
		uni.setUniversityAddress("Hyderabad");
		uni.setUniversityZipCode(500085);
		uni.setYearOfEstablishment(1965);
		
		
		University1 un = new University1();
		un.setUniversityName("JNTUH");
		un.setuDetails(uni);
		
		
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory session = configuration.buildSessionFactory();
		Session openSession = session.openSession();
		Transaction beginTransaction = openSession.beginTransaction();
		openSession.save(un);
		beginTransaction.commit();
		openSession.close();
		
	}

}
