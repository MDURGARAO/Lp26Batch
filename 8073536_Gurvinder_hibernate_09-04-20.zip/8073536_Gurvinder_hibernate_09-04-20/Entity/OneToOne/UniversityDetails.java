package com.hibernate.OneToOne;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class UniversityDetails {
	
	@Id 
	@Column(name = "UID_Pkey")
	private int universityDetailID;
	private int universityZipCode;
	private String universityAddress;
	private int yearOfEstablishment;
	
	@OneToOne(mappedBy = "uDetails", cascade = CascadeType.ALL)
	private University1 uni;
	
	public University1 getUni() {
		return uni;
	}
	public void setUni(University1 uni) {
		this.uni = uni;
	}
	public int getUniversityDetailID() {
		return universityDetailID;
	}
	public void setUniversityDetailID(int universityDetailID) {
		this.universityDetailID = universityDetailID;
	}
	public int getUniversityZipCode() {
		return universityZipCode;
	}
	public void setUniversityZipCode(int universityZipCode) {
		this.universityZipCode = universityZipCode;
	}
	public String getUniversityAddress() {
		return universityAddress;
	}
	public void setUniversityAddress(String universityAddress) {
		this.universityAddress = universityAddress;
	}
	public int getYearOfEstablishment() {
		return yearOfEstablishment;
	}
	public void setYearOfEstablishment(int yearOfEstablishment) {
		this.yearOfEstablishment = yearOfEstablishment;
	}
	

}
