package com.hibernate.OneToOne;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class University1 {
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "uDetails_Fkey")
	private UniversityDetails uDetails;

	public UniversityDetails getuDetails() {
		return uDetails;
	}
	public void setuDetails(UniversityDetails uDetails) {
		this.uDetails = uDetails;
	}
	@Id @GeneratedValue
	private int UniversityID;
	private String UniversityName;
	public int getUniversityID() {
		return UniversityID;
	}
	public void setUniversityID(int universityID) {
		UniversityID = universityID;
	}
	public String getUniversityName() {
		return UniversityName;
	}
	public void setUniversityName(String universityName) {
		UniversityName = universityName;
	}
}
