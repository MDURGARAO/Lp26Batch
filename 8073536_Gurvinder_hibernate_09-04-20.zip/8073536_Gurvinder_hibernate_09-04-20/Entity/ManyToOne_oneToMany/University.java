package com.hibernate.oneToMany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class University {
	
	@Id @GeneratedValue
	private int UniversityId;
	private String UniversityName;
	private String Address;
	
	@OneToMany(targetEntity=Student.class , mappedBy="university" , cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Student> student;
	public int getUniversityId() {
		return UniversityId;
	}
	public void setUniversityId(int universityId) {
		UniversityId = universityId;
	}
	public String getUniversityName() {
		return UniversityName;
	}
	public void setUniversityName(String universityName) {
		UniversityName = universityName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public List<Student> getStudent() {
		return student;
	}
	public void setStudent(List<Student> student) {
		this.student = student;
	}
	
}
