package com.virtusa.hibernate.practice;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import com.virtusa.hibernate.util.HibernateUtil;

public class Runner2 {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Criteria criteria=session.createCriteria(Teacher.class);
//		SimpleExpression expression=Restrictions.eq("name","mukesh" );
//		SimpleExpression expression1=Restrictions.ge("id",3 );
//		LogicalExpression expresion3=Restrictions.and(expression,expression1);
//		criteria.add(expresion3);
//		criteria.addOrder(Order.desc("id"));
//		List<Teacher> list =criteria.list();
//		list.forEach(System.out::println);
		
		ProjectionList projectionlist=Projections.projectionList();
		projectionlist.add(Projections.property("id")).add(Projections.property("name")).add(Projections.property("email"));
		criteria.setProjection(projectionlist);
		SimpleExpression expression1=Restrictions.gt("id",3 );
		criteria.add(expression1);
		criteria.addOrder(Order.desc("id"));
		
		List<Object[]> list=criteria.list();
		for(Object[] tlist:list) {
			for(int i=0;i< tlist.length;i++) {
				System.out.println(tlist[i]);
			}
		}
		
			
			
			transaction.commit();
			session.close();
	
}
}