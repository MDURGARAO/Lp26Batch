package com.virtusa.hibernate.practice;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {
	public static void main(String[] args) {
	SessionFactory factory=HibernateUtil.getFactory();
	Session session=factory.openSession();
	Transaction transaction=session.beginTransaction();
	/*Teacher teacher1=new Teacher("mukesh","sahumukesh553@gmail.com");	
Teacher teacher2=new Teacher("vivek","vivek123@ggmail.com");	
	Teacher teacher3=new Teacher("pranjal","pranjalbakshi12@gmail.com");	
	session.save(teacher1);
	session.save(teacher2);
	session.save(teacher3);*/

	//  Query query=session.createQuery(" select t from Teacher as t");
	//Query query=session.createQuery(" from Teacher where id=1");
	//Query query=session.createQuery(" select Min(id),Avg(id),Max(id) from Teacher");
	//Query query=session.createQuery(" update Teacher set email='chandu@gmail.com' where id=1");
	// Query query=session.createQuery("delete  from Teacher where id=3");
	 Query query=session.createQuery(" delete from Teacher where id=:tid");
	 query.setParameter("tid", new Scanner(System.in).nextInt());
	query.executeUpdate();
//List<Teacher> list=query.list();
//	System.out.println(list.size());
//	list.stream().forEach(System.out::println);
//List<Object[]> tlist=query.list();
//for(Object[] object:tlist) {
//	for(int i=0;i<object.length;i++) {
//		System.out.println(object[i]+" ");
//	}
//}

	transaction.commit();
	session.close();
			
		}

}
