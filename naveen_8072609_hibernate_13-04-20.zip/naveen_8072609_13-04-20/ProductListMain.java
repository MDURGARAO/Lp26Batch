package com.virtusa.hibernate.hql;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



@SuppressWarnings("deprecation")
public class ProductListMain {
	static Scanner scanner = new Scanner(System.in);
public static void main(String[] args) {
	Configuration configuration = new Configuration();
	configuration.configure("hibernate.cfg.xml");
	SessionFactory sessionFactory = configuration.buildSessionFactory();
	Session session = sessionFactory.openSession();
	Transaction transaction = session.beginTransaction();
	@SuppressWarnings("rawtypes")
//	Query query = session.createQuery("from ProductList");
//	Query query = session.createQuery("select min(p.price), max(p.price),avg(p.price) ,count(p.id) from ProductList p  ");
//	Query query = session.createQuery("select p from ProductList p where p.price>5000 and p.price<25000 ");
//	Query query = session.createQuery("select p.name ,p.price from ProductList p where p.price>= :price ");
//	Query query = session.createQuery("select p.name ,p.price from ProductList p order by p.price ASC");
//	Query query = session.createQuery("delete  from ProductList p where p.id = :id ");
	 
	Query query = session.createQuery("from ProductList p inner join p.id c");
	
	
	//	Query query = session.createQuery("select new ProductList( p.name ,p.price) from ProductList p order by p.price ASC");

//	List<ProductList> productList = session.createQuery("from ProductList").getResultList();

//	List<ProductList> productList = query.list();
//	query.setParameter("price",9500);
//	query.setParameter("id",scanner.nextLong());
//	query.executeUpdate();
//	List<Object[]> list = query.list();
	
//	productList.stream().forEach(System.out::println);
//	list.stream().forEach(System.out::println);
//	Iterator<ProductList> itr = productList.iterator();
//	Iterator<ProductList> itr = query.iterate();
	query.setFirstResult(0);
	query.setMaxResults(10);
//	List<Object[]> listResult = query.list();
//	 
//	for (Object[] aRow : listResult) {
//	    ProductList product = (ProductList) aRow[0];
//	    Category category = (Category) aRow[1];
//	    System.out.println(product.getName() + " - " + category.getName());
//	}

//	while(itr.hasNext())
//	{
//		ProductList lst = (ProductList)itr.next();
//		System.out.println(lst.getId() +" "+lst.getName()+ " "+lst.getPrice());
//	}
//	for(Object[] arr : list)
//	{
//		System.out.println(arr[0]+ " " +arr[1]);
//	}
	transaction.commit();
	session.close();
}
}
