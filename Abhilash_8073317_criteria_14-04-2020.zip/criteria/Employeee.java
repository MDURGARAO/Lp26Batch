package com.hibernate;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
@NamedQueries(
		{
			@NamedQuery(name = "getName", query = "select name from Employeee"),
			@NamedQuery(name = "getSalary", query = "select salary from Employeee")
			}
		)
@Entity
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Table(name = "Emp")
public class Employeee {
    
	@Id
	@Column(name = "empid")
	private int empid;
	@Column(name = "salary")
	private double salary;
	@Column(name = "name")
	
	private String name;

	
	public Employeee(double salary, String name) {
		super();
		this.salary = salary;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employeee [empid=" + empid + ", salary=" + salary + ", name=" + name + ", dept=" + dept + "]";
	}
	@Column(name = "dept")
	private int dept;
	
	
	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDept() {
		return dept;
	}

	public void setDept(int dept) {
		this.dept = dept;
	}

	public Employeee(int empid, double salary, String name, byte dept) {
		super();
		this.empid = empid;
		this.salary = salary;
		this.name = name;
		this.dept = dept;
	}
	public Employeee() {
		
	}

	
	

	

}
