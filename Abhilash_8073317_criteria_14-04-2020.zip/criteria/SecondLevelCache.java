package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SecondLevelCache {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration configuration=new Configuration();
		 configuration.configure("hibernate.cfg.xml");
		 SessionFactory sessionFactory=configuration.buildSessionFactory();
		 Session session1=sessionFactory.openSession();
		 Employeee employeee = session1.get(Employeee.class, 1);
		 System.out.println(employeee);
		 session1.close();
		 Session session2=sessionFactory.openSession();
		 Employeee employeee2 = session2.get(Employeee.class, 1);
		 System.out.println(employeee2);
		 session2.close();
		 
	}

}
