package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

public class CriteriaMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Configuration configuration=new Configuration();
		 configuration.configure("hibernate.cfg.xml");
		 SessionFactory sessionFactory=configuration.buildSessionFactory();
		 Session session=sessionFactory.openSession();
		 Transaction transaction=session.beginTransaction();
		 Criteria criteria=session.createCriteria(Employeee.class);
//		 SimpleExpression expression=Restrictions.le("salary", 200000.00);
//		 SimpleExpression expression1=Restrictions.eq("name", "cill");
//		 SimpleExpression expression2 = Restrictions.eq("dept", 8);
//		 Disjunction or = Restrictions.or(expression,expression1,expression2);
////		 LogicalExpression and = Restrictions.and(expression,expression1);
//		 criteria.add(or);
		 ProjectionList projectionList = Projections.projectionList();
		 projectionList.add(Projections.property("name"));
		 criteria.setProjection(projectionList);
		 criteria.addOrder(Order.desc("name")); 
		 List<String> list = criteria.list();
		 list.forEach(System.out::println);
         transaction.commit();
         session.close();
	}

}
