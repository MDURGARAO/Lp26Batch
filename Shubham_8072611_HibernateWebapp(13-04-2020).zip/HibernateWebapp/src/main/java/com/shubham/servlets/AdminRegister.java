package com.shubham.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shubham.DAO.AdminDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/ARegister")
public class AdminRegister extends HttpServlet {
	
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			AdminDAO admin = new AdminDAO();
			String username = request.getParameter("username");
			String email = request.getParameter("email");
			String password = request.getParameter("password");

			boolean success = admin.registerAdmin(username, email, password);
			if(success) {
				request.getRequestDispatcher("/Admin.jsp").forward(request, response);
			}else {
				request.setAttribute("message", "user name already exists");
				request.getRequestDispatcher("/Admin.jsp").forward(request, response);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
