package com.virtusa.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entity.Employee;

public class EmployeeMain {
	
public static void main(String[] args) {
	
	Employee emp1 = new Employee(101,"Gurvinder",1000,"Hyd");
	Configuration configuration = new Configuration();
	configuration.configure("hibernate.cfg.xml");
	SessionFactory session = configuration.buildSessionFactory();
	Session openSession = session.openSession();
	openSession.save(emp1);
	Transaction beginTransaction = openSession.beginTransaction();
	beginTransaction.commit();
	openSession.close();
	
}
}
