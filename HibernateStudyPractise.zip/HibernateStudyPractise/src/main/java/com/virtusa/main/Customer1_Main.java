package com.virtusa.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.entity2.Customer1;

public class Customer1_Main {
	
	public static void main(String args[]) {
		
		Customer1 cust1 = new Customer1();
		cust1.setCustId(01);
		cust1.setCustName("Gurvinder");
		cust1.setCustAddress("Hyderabad");
		cust1.setCustPhno(1234567890);
		cust1.setCreditScore(999);
		
		

	Configuration configuration = new Configuration();
	configuration.configure("hibernate.cfg.xml");
	SessionFactory session = configuration.buildSessionFactory();
	Session openSession = session.openSession();
	Transaction beginTransaction = openSession.beginTransaction();
	openSession.save(cust1);
	beginTransaction.commit();
	openSession.close();
}
	
}
