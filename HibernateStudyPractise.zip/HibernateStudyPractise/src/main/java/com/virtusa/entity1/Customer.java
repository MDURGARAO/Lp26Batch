package com.virtusa.entity1;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CustomerDetails")
public class Customer {
	@Id
	@Column(name="customerid")
	private int cust_id;
	
	@Column(name="customername")
	private String custName;
	
	@Column(name="payment")
	private String payment;
	
	@Column(name="phoneNo")
	private int phnNo; 
	
	private CustomerAddress address;
	
	
	public int getCust_id() {
		return cust_id;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	public int getPhnNo() {
		return phnNo;
	}
	public void setPhnNo(int phnNo) {
		this.phnNo = phnNo;
	}
	
	@Embedded
	public CustomerAddress getAddress() {
		return address;
	}
	
	public void setAddress(CustomerAddress address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [cust_id=" + cust_id + ", custName=" + custName + ", payment=" + payment + ", phnNo=" + phnNo
				+ ", address=" + address + "]";
	}
	

	
}

