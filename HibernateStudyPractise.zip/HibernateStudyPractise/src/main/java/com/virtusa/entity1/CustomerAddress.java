package com.virtusa.entity1;
import javax.persistence.Column;
import javax.persistence.Embeddable;
@Embeddable
public class CustomerAddress {

	@Column(name = "Houseno")
	int hno;
	
	@Column(name="City")
	String cityName;
	
	@Column(name="State")
	String stateName;
	
	public int getHno() {
		return hno;
	}
	public void setHno(int hno) {
		this.hno = hno;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	@Override
	public String toString() {
		return "CustomerAddress [hno=" + hno + ", cityName=" + cityName + ", stateName=" + stateName + "]";
	}
}
