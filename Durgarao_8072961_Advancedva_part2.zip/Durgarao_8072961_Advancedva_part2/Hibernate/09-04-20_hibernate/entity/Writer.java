package com.virtusa.hibernate.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="writer")
public class Writer {
	
	@Id
   @GeneratedValue
    @Column(name = "ID", unique = true, nullable = false)
    private Integer writerId;
 
    @Column(name = "EMAIL", unique = true, nullable = false, length = 100)
    private String email;
 
    @Column(name = "name", unique = false, nullable = false, length = 100)
    private String name;

 
    @OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="Writer_ID")
    private Set<Novel> novels;
    
    

	public Writer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getWriterId() {
		return writerId;
	}

	public void setWriterId(Integer writerId) {
		this.writerId = writerId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Novel> getNovels() {
		return novels;
	}

	public void setNovels(Set<Novel> novels) {
		this.novels = novels;
	}
    
    
 
    //Getters and setters


}
