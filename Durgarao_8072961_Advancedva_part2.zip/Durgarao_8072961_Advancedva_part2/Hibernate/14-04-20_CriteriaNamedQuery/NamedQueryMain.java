package com.virtusa.hibernate.client;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.entity.EmployeeNamedQuery;

public class NamedQueryMain {

	public static void main(String... mdr) {
		
		//The Hibernate framework provides the concept of named queries so 
		//that application programmer need not to scatter queries to all the java code. 
		
			Configuration config=new Configuration();
			config.configure("hibernate.cfg.xml");
			SessionFactory factory =  config.buildSessionFactory(); 
	
			Session session=factory.openSession();   
			
	           Query query =session.getNamedQuery("findEmployeeByName");    
	            query.setParameter("name", "emp3") ;  
	            
	            List<EmployeeNamedQuery> list=query.list();
	            
	            list.forEach(System.out::println);

	            session.close();
	}

}
