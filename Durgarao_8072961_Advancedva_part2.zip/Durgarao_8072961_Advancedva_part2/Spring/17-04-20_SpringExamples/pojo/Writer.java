package com.virtusa.spring.pojo;

import java.util.Set;


public class Writer {
	
	
    private Integer writerId;
 
   
    private String email;
 
  
    private String name;

 
   
   
    private Set<Novel> novels;
    
    
	public Integer getWriterId() {
		return writerId;
	}

	public void setWriterId(Integer writerId) {
		this.writerId = writerId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Novel> getNovels() {
		return novels;
	}

	public void setNovels(Set<Novel> novels) {
		this.novels = novels;
	}

	@Override
	public String toString() {
		return "Writer [writerId=" + writerId + ", email=" + email + ", name=" + name + ", novels=" + novels + "]";
	}
    
	

}
