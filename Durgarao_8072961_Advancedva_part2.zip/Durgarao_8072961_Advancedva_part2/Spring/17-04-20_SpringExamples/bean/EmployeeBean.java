package com.virtusa.spring.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.pojo.Employee;


public class EmployeeBean {

	public static void main(String... mdr) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("spring-core-config.xml");
		Employee employeeBean=context.getBean(Employee.class, "employeeBean");
		
			System.out.println(employeeBean.toString());

	}

}
