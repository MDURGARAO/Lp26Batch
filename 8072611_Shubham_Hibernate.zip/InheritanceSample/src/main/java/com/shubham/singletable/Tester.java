package com.shubham.singletable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Testers")
@DiscriminatorValue("Test_EMP")
public class Tester extends Employee {
	
	@Column(name="domainName")
	private String domainName;
	
	@Column(name="type")
	private String type;
	
	@Column(name="experience")
	private int years;

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getYears() {
		return years;
	}

	public void setYears(int years) {
		this.years = years;
	}

}
