package com.shubham.tableperclass;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main1 {
	public static void main(String[] args) {
		System.out.println("Hello");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		Session session = cfg.buildSessionFactory().openSession();
		Transaction txn = session.beginTransaction();
		
		Employee1 emp2 = new Employee1();
		emp2.setFirstName("Shubham");
		emp2.setLastName("Shandilya");
		
		Developer1 dev2 = new Developer1();
		dev2.setFirstName("Shubham");
		dev2.setLastName("Shandilya");
		dev2.setDomainName("Java");
		dev2.setType("Full Stack");
		dev2.setYears(3);
		
		Tester1 test2 = new Tester1();
		test2.setFirstName("Shubham");
		test2.setLastName("Shandilya");
		test2.setDomainName("Selenium");
		test2.setType("Backend");
		test2.setYears(5);
		
		session.save(emp2);
		session.save(dev2);
		session.save(test2);
		
		txn.commit();
		session.close(); 
	}
}