package com.virtusa.hibernate.onetoone;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.virtusa.hibernate.manytoone.Owner;
import com.virtusa.hibernate.manytoone.Vehicle;
import com.virtusa.hibernate.util.HibernateUtil;

public class Operation {

	 Teacher teacher=new Teacher();
		
		public static  void insert(Teacher teacher)
		{
			//Transaction transaction =Operation.getTransaction();
			SessionFactory sessionFactory=HibernateUtil.getFactory();
			Session session=sessionFactory.openSession();
			 session.beginTransaction();
			session.save(teacher);
			 session.getTransaction().commit();
			 
		}
		public void delete() {
			SessionFactory sessionFactory=HibernateUtil.getFactory();
			Session session=sessionFactory.openSession();
			 session.getTransaction().begin();
			 try {
				 teacher = (Teacher)session.get(Teacher.class, 1);
				 session.delete(teacher);
				 session.getTransaction().commit();
			 }
			 catch (Exception e) {
			System.out.println("enter valid id");
			}	
		}
		
		
	
		
}
