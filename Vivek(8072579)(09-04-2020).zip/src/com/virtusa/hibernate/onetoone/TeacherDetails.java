package com.virtusa.hibernate.onetoone;


	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.Table;


	@Entity
	@Table(name="TeacherDetails")

	public class TeacherDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
		private int tid;
		private String school;
		private String subject;
		
		public int getId() {
			return tid;
		}
		public String getName() {
			return school;
		}
		public String getSubject() {
			return subject;
		}
		public void setId(int id) {
			this.tid = id;
		}
		public void setName(String sname) {
			this.school = sname;
		}
		public void setSubject(String subject) {
			this.subject = subject;
		}
		public TeacherDetails(String sname, String subject) {
			this.school = sname;
			this.subject = subject;
		}
		public void teacher_details(){}


	}



