package com.virtusa.hibernate.onetoone;



	import java.util.Arrays;
	import java.util.List;
	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.Transaction;
	import org.hibernate.cfg.Configuration;

	import com.virtusa.hibernate.util.HibernateUtil;

	public class Runner {

		public static void main(String[] args) {
			
			SessionFactory factory=HibernateUtil.getFactory();
	Session session=factory.openSession();
	Transaction transaction=session.beginTransaction();
	TeacherDetails techer_detail1=new TeacherDetails("central model school","english");
	TeacherDetails techer_detail2=new TeacherDetails("bnv","math");
	TeacherDetails techer_detail3=new TeacherDetails("DMHSS","hindi");
	Teacher teacher1=new Teacher("mukesh","sahumukesh553@gmail.com");	
	Teacher teacher2=new Teacher("vivek","vivek123@ggmail.com");	
	Teacher teacher3=new Teacher("pranjal","pranjalbakshi12@gmail.com");	
	teacher1.setTeacher_details(techer_detail1);
	teacher2.setTeacher_details(techer_detail2);
	teacher3.setTeacher_details(techer_detail3);
	session.save(teacher1);
	session.save(teacher2);
	session.save(teacher3);

	transaction.commit();
	session.close();
			
		}

	}


