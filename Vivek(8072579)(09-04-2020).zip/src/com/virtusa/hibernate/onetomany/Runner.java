package com.virtusa.hibernate.onetomany;


import java.util.Arrays;
import java.util.List;

//import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {

	public static void main(String[] args) {
		Operation operation=new Operation();
	

Items i1=new Items("shampoo",45);
Items i2=new Items("fruits",10);
List<Items> items=Arrays.asList(i1,i2);
Cart c1=new Cart("bigbasket", items);

operation.update(1);

		
	}



}
