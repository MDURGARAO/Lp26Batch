package com.virtusa.hibernate.onetomany;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.virtusa.hibernate.manytoone.Owner;
import com.virtusa.hibernate.manytoone.Vehicle;
import com.virtusa.hibernate.util.HibernateUtil;

public class Operation {
	 Cart cart=new Cart();
		
		public static  void insert(Cart cart)
		{
			//Transaction transaction =Operation.getTransaction();
			SessionFactory sessionFactory=HibernateUtil.getFactory();
			Session session=sessionFactory.openSession();
			 session.beginTransaction();
			 session.save(cart);
			 session.getTransaction().commit();
			 
		}
		public void delete() {
			SessionFactory sessionFactory=HibernateUtil.getFactory();
			Session session=sessionFactory.openSession();
			 session.getTransaction().begin();
			 try {
				 cart = (Cart)session.get(Cart.class, 2);
				 session.delete(cart);
				 session.getTransaction().commit();
			 }
			 catch (Exception e) {
			System.out.println("enter valid id");
			}	
		}
		
		public void update(int id) {
			SessionFactory sessionFactory=HibernateUtil.getFactory();
			Session session=sessionFactory.openSession();
			 session.beginTransaction();
			 try {
				 cart = (Cart)session.get(Cart.class, id);
				 cart.setCartname("flipkart");
				List<Items> item=cart.getItems();
				item.get(0).setItemsName("maggi");
				cart.setItems(item);
				 session.persist(cart);
				 session.getTransaction().commit();
				 session.close();
			 }
			 catch (Exception e) {
				 System.err.println("enter 111valid id");
			 }
			}
		public void view() {
			SessionFactory sessionFactory=HibernateUtil.getFactory();
			Session session=sessionFactory.openSession();
			 session.beginTransaction();
			 Query qery=session.createQuery("from Cart");
			 List<Cart> fetchData=qery.list();
			 Iterator<Cart> iterator=fetchData.iterator();
			 while(iterator.hasNext())
			 {
				 cart=(Cart)iterator.next();
				 System.out.println(cart);
			 }
			 session.getTransaction().commit();
		} 

		
		

}
