package com.virtusa.hibernate.onetomany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
public class Cart {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int cartId;
private String cartname;
public Cart(String cartname, List<Items> items) {
	this.cartname = cartname;
	this.items = items;
}
public int getCartId() {
	return cartId;
}
public String getCartname() {
	return cartname;
}

public void setCartId(int cartId) {
	this.cartId = cartId;
}
public void setCartname(String cartname) {
	this.cartname = cartname;
}
public void setItems(List<Items> items) {
	this.items = items;
}
public List<Items> getItems() {
	return items;
}
@OneToMany(cascade=CascadeType.ALL)
private List<Items> items;
public Cart() {
	super();
	// TODO Auto-generated constructor stub
}

}



