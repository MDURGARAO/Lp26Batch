package com.virtusa.hibernate.onetomany;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Items {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int itemId;
	private String itemsName;
	private int quant;
	public int getItemId() {
		return itemId;
	}
	public String getItemsName() {
		return itemsName;
	}
	public int getQuant() {
		return quant;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public void setItemsName(String itemsName) {
		this.itemsName = itemsName;
	}
	public void setQuant(int quant) {
		this.quant = quant;
	}
	public Items(String itemsName, int quant) {
		this.itemsName = itemsName;
		this.quant = quant;
	}
	public Items() {
		// TODO Auto-generated constructor stub
	}
	

}
