package com.virtusa.hibernate.manytoone;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Owner {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int ownerId;
	private String ownerName;
	public Owner(String ownerName, String ownerAddress) {
		this.ownerName = ownerName;
		this.ownerAddress = ownerAddress;
	}

	private String ownerAddress;
	
	public int getOwnerId() {
		return ownerId;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public String getOwnerAddress() {
		return ownerAddress;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public void setOwnerAddress(String ownerAddress) {
		this.ownerAddress = ownerAddress;
	}

	public Owner() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
