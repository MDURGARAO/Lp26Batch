package com.virtusa.hibernate.manytoone;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Vehicle {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int vehicleId;
	public Vehicle(String vehicleName, long vehiclePrice, Owner owner) {
		this.vehicleName = vehicleName;
		this.vehiclePrice = vehiclePrice;
		this.owner = owner;
	}
	
	public Vehicle() {
		// TODO Auto-generated constructor stub
	}
	
	@ManyToOne(cascade=CascadeType.ALL)
	private Owner owner;
	public Owner getOwner() {
		return owner;
	}
	public void setOwner(Owner owner) {
		this.owner = owner;
	}
	
	private String vehicleName;

	public int getVehicleId() {
		return vehicleId;
	}
	public String getVehicleName() {
		return vehicleName;
	}
	public long getVehiclePrice() {
		return vehiclePrice;
	}
	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	public void setVehiclePrice(long vehiclePrice) {
		this.vehiclePrice = vehiclePrice;
	}
	private long vehiclePrice;
	
	@Override
	public String toString() {
		return "Vehicle [vehicleId=" + vehicleId + ", vehicleName=" + vehicleName + ", vehiclePrice=" + vehiclePrice
				+ ", owner=" + owner + "]";
	}

}
