package com.virtusa.hibernate.manytoone;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.virtusa.hebernate.manytomany.Courses;
import com.virtusa.hebernate.manytomany.Student;
import com.virtusa.hibernate.util.HibernateUtil;

public class Operation {
	 Vehicle vehicle=new Vehicle();
	
	public static  void insert(ArrayList<Vehicle> vehicle)
	{
		//Transaction transaction =Operation.getTransaction();
		SessionFactory sessionFactory=HibernateUtil.getFactory();
		Session session=sessionFactory.openSession();
		 session.beginTransaction();
		 Iterator<Vehicle> iterator=vehicle.iterator();
		 while(iterator.hasNext())
		 {
			 Vehicle next=iterator.next();
			 session.persist(next);
		 }
		 session.getTransaction().commit();
		 
	}
	public void delete() {
		SessionFactory sessionFactory=HibernateUtil.getFactory();
		Session session=sessionFactory.openSession();
		 session.getTransaction().begin();
		 try {
			 vehicle = (Vehicle)session.get(Vehicle.class, 2);
			 session.delete(vehicle);
			 session.getTransaction().commit();
		 }
		 catch (Exception e) {
		System.out.println("enter valid id");
		}	
	}
	
	public void update(int id) {
		SessionFactory sessionFactory=HibernateUtil.getFactory();
		Session session=sessionFactory.openSession();
		 session.beginTransaction();
		 try {
			 vehicle = (Vehicle)session.get(Vehicle.class, id);
			 vehicle.setVehicleName("scoda");
			Owner owner=vehicle.getOwner();
			owner.setOwnerAddress("kolkata");
			owner.setOwnerName("sayantani");
			vehicle.setOwner(owner);
			 session.persist(vehicle);
			 session.getTransaction().commit();
		 }
		 catch (Exception e) {
			 System.err.println("enter valid id");
		 }
		}
	public void view() {
		SessionFactory sessionFactory=HibernateUtil.getFactory();
		Session session=sessionFactory.openSession();
		 session.beginTransaction();
		 List<Vehicle> fetchData=session.createQuery("from Vehicle").list();
		 
		 System.out.println(fetchData.size());
		 
		 Iterator<Vehicle> iterator=fetchData.iterator();
		 while(iterator.hasNext())
		 {
			 System.out.println("aa gya");
			 vehicle=(Vehicle)iterator.next();
			 System.out.println(vehicle);
		 }
		 session.getTransaction().commit();
	} 

	
	
}
