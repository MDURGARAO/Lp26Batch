package com.virtusa.hibernate.manytoone;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {

	public static void main(String[] args) {
		Operation operation=new Operation();
		/*Owner owner=new Owner("VIVEK","chennai");
		Vehicle v1=new Vehicle("AUDI",90000000L,owner);
		Vehicle v2=new Vehicle("NANO",400000L,owner);
		Vehicle v3=new Vehicle("SWIFT",700000L,owner);

		v1.setOwner(owner);
		v2.setOwner(owner);
		v3.setOwner(owner);


		ArrayList<Vehicle> vehicle=new ArrayList<Vehicle>();
		vehicle.add(v1);
		vehicle.add(v2);
		vehicle.add(v3);*/
		operation.view();



	}

}

