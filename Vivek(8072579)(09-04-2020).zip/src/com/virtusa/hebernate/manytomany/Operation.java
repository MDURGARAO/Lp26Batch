package com.virtusa.hebernate.manytomany;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.virtusa.hibernate.util.HibernateUtil;

public class Operation {
	
	 
Student student=new Student();
public static  void insert(ArrayList<Student> student)
{
	//Transaction transaction =Operation.getTransaction();
	SessionFactory sessionFactory=HibernateUtil.getFactory();
	Session session=sessionFactory.openSession();
	 session.beginTransaction();
	 Iterator<Student> iterator=student.iterator();
	 while(iterator.hasNext())
	 {
		 Student next=iterator.next();
		 session.persist(next);
	 }
	 session.getTransaction().commit();
	 
}
public void view() {
	SessionFactory sessionFactory=HibernateUtil.getFactory();
	Session session=sessionFactory.openSession();
	 session.beginTransaction();
	 Query qery=session.createQuery("from Student");
	 List<Student> fetchData=qery.list();
	 Iterator<Student> iterator=fetchData.iterator();
	 while(iterator.hasNext())
	 {
		 student=(Student)iterator.next();
		 System.out.println(student);
	 }
	 session.getTransaction().commit();
} 

public void update(int id) {
	SessionFactory sessionFactory=HibernateUtil.getFactory();
	Session session=sessionFactory.openSession();
	 session.beginTransaction();
	 try {
		 student = (Student)session.get(Student.class, id);
		 student.setName("bhandari");
		 List<Courses> courses=student.getCourses();
		 Courses c1=courses.get(0);
		 c1.setDuration(60);
		 c1.setFees(6000);
		 Courses c2=courses.get(1);
		 c1.setDuration(10);
		 c1.setFees(7000);
		 courses.clear();
		 courses.add(c1);
		 courses.add(c2);
		 student.setCourses(courses);
		 session.persist(student);
		 session.getTransaction().commit();
	 }
	 catch (Exception e) {
		 System.err.println("enter valid id");
	 }
	
		// TODO: handle exception
	}
public void delete() {
	SessionFactory sessionFactory=HibernateUtil.getFactory();
	Session session=sessionFactory.openSession();
	 session.getTransaction().begin();
	 try {
		 student = (Student)session.get(Student.class, 2);
		 session.delete(student);
		 session.getTransaction().commit();
	 }
	 catch (Exception e) {
	System.out.println("enter valid id");
	}
	
}

}



