package com.virtusa.hebernate.manytomany;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


	@Entity
	@Table(name="student")
	public class Student implements Serializable{
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int id;
		@Column(name="student_name")
		private String name;
		public Student(String name, String subject, List<Courses> courses) {
			this.name = name;
			this.subject = subject;
			this.courses = courses;
		}
		public void Student() {}
		public int getId() {
			return id;
		}
		public String getName() {
			return name;
		}
		public String getSubject() {
			return subject;
		}
		public List<Courses> getCourses() {
			return courses;
		}
		public void setId(int id) {
			this.id = id;
		}
		public void setName(String name) {
			this.name = name;
		}
		public void setSubject(String subject) {
			this.subject = subject;
		}
		public void setCourses(List<Courses> courses) {
			this.courses = courses;
		}
		private String subject;
		public Student() {
			super();
			// TODO Auto-generated constructor stub
		}
		@ManyToMany
		 List<Courses> courses;
}
