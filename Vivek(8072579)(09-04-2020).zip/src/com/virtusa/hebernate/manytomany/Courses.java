package com.virtusa.hebernate.manytomany;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


	@Entity
	@Table(name="courses")
	public class Courses implements Serializable{
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		private int id;
		private int duration;
		public Courses() {}
		public Courses(int duration, String name, int fees, List<Student> student) {
			this.duration = duration;
			this.name = name;
			this.fees = fees;
			this.student = student;
		}
		public int getId() {
			return id;
		}
		public int getDuration() {
			return duration;
		}
		public String getName() {
			return name;
		}
		public int getFees() {
			return fees;
		}
		public List<Student> getStudent() {
			return student;
		}
		public void setId(int id) {
			this.id = id;
		}
		public void setDuration(int duration) {
			this.duration = duration;
		}
		public void setName(String name) {
			this.name = name;
		}
		public void setFees(int fees) {
			this.fees = fees;
		}
		public void setStudent(List<Student> student) {
			this.student = student;
		}
		private String name;
		private int fees;
@ManyToMany(cascade=CascadeType.ALL) 
List<Student> student;

}
