package com.virtusa.hebernate.manytomany;

import java.util.ArrayList;
import java.util.Arrays;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {
	public static void main(String[] args) 
	{
		Courses c1 = null,c2 = null,c3 = null;
		
		Student s1 =new Student("vivek","java,programming",Arrays.asList(c1,c2));
		Student s2=new Student("roma","sql",Arrays.asList(c1,c3));
		Student s3=new Student("roshan","html",Arrays.asList(c3,c2));
		Student s4=new Student("sampurna","jdbc",Arrays.asList(c1,c2,c3));
		
		
		c1=new Courses(45,"java",9000,Arrays.asList(s1,s2));
		c2=new Courses(20,"programming",10000,Arrays.asList(s2,s3));
		c3=new Courses(15,"html",5000,Arrays.asList(s4,s3,s1));
	
//		 mukesh.setTeachers(Arrays.asList(shishra,raghu));
//		 rahul.setTeachers(Arrays.asList(shishra,raghu,nikhila));               
//		 chandan.setTeachers(Arrays.asList(shishra,shashi));
//		 abhinav.setTeachers(Arrays.asList(shishra,gautam));
		 
		ArrayList<Student> student=new ArrayList<Student>();
		student.add(s1);
		student.add(s2);
		student.add(s3);
		student.add(s4);
		Operation.insert(student);		
	}

}
