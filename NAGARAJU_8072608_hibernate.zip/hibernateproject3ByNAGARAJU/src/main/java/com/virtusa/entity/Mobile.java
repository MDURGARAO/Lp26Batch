/**
 * 
 */
package com.virtusa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name="mobile")
@SecondaryTable(name = "mobilespecificatios")
public class Mobile {
	
	@Id
	@Column(name="ID")
	private String id;
	@Column(name="MobileName")
	private String modelName;
	@Column(name="IFSCCODE")
	private String ifscNumber;
	@Column(name="MobileRam",table="mobilespecificatios")
	private String mobileRam;
	@Column(name="MobileRom",table="mobilespecificatios")
	private String mobileRom;
	/**
	 * 
	 */
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the modelName
	 */
	public String getModelName() {
		return modelName;
	}
	/**
	 * @param modelName the modelName to set
	 */
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	/**
	 * @return the ifscNumber
	 */
	public String getIfscNumber() {
		return ifscNumber;
	}
	/**
	 * @param ifscNumber the ifscNumber to set
	 */
	public void setIfscNumber(String ifscNumber) {
		this.ifscNumber = ifscNumber;
	}
	/**
	 * @return the mobileRam
	 */
	public String getMobileRam() {
		return mobileRam;
	}
	/**
	 * @param mobileRam the mobileRam to set
	 */
	public void setMobileRam(String mobileRam) {
		this.mobileRam = mobileRam;
	}
	/**
	 * @return the mobileRom
	 */
	public String getMobileRom() {
		return mobileRom;
	}
	/**
	 * @param mobileRom the mobileRom to set
	 */
	public void setMobileRom(String mobileRom) {
		this.mobileRom = mobileRom;
	}
	
	
}
