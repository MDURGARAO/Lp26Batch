/**
 * 
 */
package com.virtusa.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entity.Mobile;

/**
 * @author Damodar Reddy3:00:55 PMApr 9, 2020
 * MobileMain.java
 */
public class MobileMain {
	
	public static void main(String[] args) {
		Mobile mobile = new Mobile();
		mobile.setId("1X12");
		mobile.setIfscNumber("124578951x66");
		mobile.setModelName("redmi Note 10");
		mobile.setMobileRam("8 gb");
		mobile.setMobileRom("126 gb");
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(mobile);
		transaction.commit();
		session.close();
	}

}
