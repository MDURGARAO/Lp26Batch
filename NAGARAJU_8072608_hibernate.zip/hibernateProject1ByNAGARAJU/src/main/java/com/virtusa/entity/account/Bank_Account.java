/**
 * 
 */
package com.virtusa.entity.account;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
@Entity
@Table(name = "Account")  
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class Bank_Account {
	@Id
	private String Bank_Id;
	private String bank_Name;
	private String ifsc_Code;
	private String bank_Location;
	/**
	 * @return the bank_Id
	 */
	public String getBank_Id() {
		return Bank_Id;
	}
	/**
	 * @param bank_Id the bank_Id to set
	 */
	public void setBank_Id(String bank_Id) {
		Bank_Id = bank_Id;
	}
	/**
	 * @return the bank_Name
	 */
	public String getBank_Name() {
		return bank_Name;
	}
	/**
	 * @param bank_Name the bank_Name to set
	 */
	public void setBank_Name(String bank_Name) {
		this.bank_Name = bank_Name;
	}
	/**
	 * @return the ifsc_Code
	 */
	public String getIfsc_Code() {
		return ifsc_Code;
	}
	/**
	 * @param ifsc_Code the ifsc_Code to set
	 */
	public void setIfsc_Code(String ifsc_Code) {
		this.ifsc_Code = ifsc_Code;
	}
	/**
	 * @return the bank_Location
	 */
	public String getBank_Location() {
		return bank_Location;
	}
	/**
	 * @param bank_Location the bank_Location to set
	 */
	public void setBank_Location(String bank_Location) {
		this.bank_Location = bank_Location;
	}
	public Bank_Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Bank_Account [Bank_Id=" + Bank_Id + ", bank_Name=" + bank_Name + ", ifsc_Code=" + ifsc_Code
				+ ", bank_Location=" + bank_Location + "]";
	}

	
	
}
