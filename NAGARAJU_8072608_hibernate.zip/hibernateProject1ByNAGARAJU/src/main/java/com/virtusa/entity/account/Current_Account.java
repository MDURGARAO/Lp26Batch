/**
 * 
 */
package com.virtusa.entity.account;

import javax.persistence.Entity;

/**
 * @author Damodar Reddy9:14:47 AMApr 9, 2020
 * Current_Account.java
 */
@Entity
public class Current_Account extends Bank_Account{

	private int min_Transactions;
	private int min_deposit;
	/**
	 * @return the min_Transactions
	 */
	public int getMin_Transactions() {
		return min_Transactions;
	}
	/**
	 * @param min_Transactions the min_Transactions to set
	 */
	public void setMin_Transactions(int min_Transactions) {
		this.min_Transactions = min_Transactions;
	}
	/**
	 * @return the min_deposit
	 */
	public int getMin_deposit() {
		return min_deposit;
	}
	/**
	 * @param min_deposit the min_deposit to set
	 */
	public void setMin_deposit(int min_deposit) {
		this.min_deposit = min_deposit;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Current_Account [min_Transactions=" + min_Transactions + ", min_deposit=" + min_deposit + "]";
	}
	/**
	 * 
	 */
	public Current_Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
