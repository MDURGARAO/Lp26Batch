package com.virtusa.entity.Main;

public class VechileMain {
	public static void main(String[] args) {
		
		}

}
