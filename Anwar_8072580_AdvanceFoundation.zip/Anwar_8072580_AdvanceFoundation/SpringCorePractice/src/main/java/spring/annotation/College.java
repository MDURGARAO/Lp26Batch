package spring.annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("collegeBean")
public class College {
    @Autowired
	private Teacher teacher;
    @Value("geca") 
    private String collegeName;
	
	public Teacher getTeacher() {
	return teacher;
}

//public void setTeacher(Teacher teacher) {
//	this.teacher = teacher;
//}

	public void test()
	{   teacher.teach();
	    System.out.println(collegeName);
		System.out.println("Test");
	}
}
