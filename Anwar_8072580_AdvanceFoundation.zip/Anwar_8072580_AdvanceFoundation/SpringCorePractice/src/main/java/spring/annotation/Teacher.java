package spring.annotation;

public interface Teacher {

	
	public void teach() ;
		
	
}
