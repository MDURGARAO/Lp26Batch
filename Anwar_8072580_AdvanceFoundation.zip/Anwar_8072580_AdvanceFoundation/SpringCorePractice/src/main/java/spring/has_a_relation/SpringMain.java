package spring.has_a_relation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import spring.has_a_relation.StudentBean;
 
public class SpringMain {
 
	public static void main(String[] str) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring_hasarelation.xml");
		StudentBean student = (StudentBean) context.getBean("student");
 
		System.out.println("Student Details:- " + student);
	}
}
