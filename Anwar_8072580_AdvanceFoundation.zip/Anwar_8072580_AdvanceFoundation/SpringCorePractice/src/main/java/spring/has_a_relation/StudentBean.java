package spring.has_a_relation;

public class StudentBean {

	private int studentId;
	private String firstName;
	private String lastName;
	private AddressBean address;
 
	public int getStudentId() {
		return studentId;
	}
 
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
 
	public String getFirstName() {
		return firstName;
	}
 
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
 
	public String getLastName() {
		return lastName;
	}
 
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
 
	public AddressBean getAddress() {
		return address;
	}
 
	public void setAddress(AddressBean address) {
		this.address = address;
	}
 
	@Override
	public String toString() {
 
		StringBuilder student = new StringBuilder();
		student.append("\nFirst Name:- ").append(this.getFirstName());
		student.append("\nLast Name:- ").append(this.getLastName());
		student.append("\nAddress:- ").append(this.getAddress());
		return student.toString();
	}

}
