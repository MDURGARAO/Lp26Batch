package spring.array;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;


public class MainSpringArray {

		
		public static void main(String[] args) 
		{
			ApplicationContext context = new ClassPathXmlApplicationContext("spring_array.xml");
			CompanyBean company = context.getBean(CompanyBean.class);

      System.out.println(company);				
		}
	}

