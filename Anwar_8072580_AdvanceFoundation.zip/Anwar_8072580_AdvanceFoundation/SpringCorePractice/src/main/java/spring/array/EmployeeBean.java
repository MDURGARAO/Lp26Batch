package spring.array;

public class EmployeeBean {

	public String name;
	public int telNo;
	DepartmentBean dept;
	AddressBean address;
	
	
	public AddressBean getAddress() {
		return address;
	}

	public void setAddress(AddressBean address) {
		this.address = address;
	}

	public DepartmentBean getDept() {
		return dept;
	}

	public void setDept(DepartmentBean dept) {
		this.dept = dept;
	}

	public String getName() 
	{
		return name;
	}
	
	public void setName(String name) 
	{
		this.name = name;
	}
	
	
	
		@Override
	public String toString() {
		return "EmployeeBean [name=" + name + ", telNo=" + telNo + ", dept=" + dept + ", address=" + address + "]";
	}

		public int getTelNo() 
	{
		return telNo;
	}
	
	public void setTelNo(int telNo) 
	{
		this.telNo = telNo;
	
}
}
