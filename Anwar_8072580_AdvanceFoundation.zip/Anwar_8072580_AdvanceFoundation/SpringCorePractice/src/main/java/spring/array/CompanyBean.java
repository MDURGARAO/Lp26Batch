package spring.array;

import java.util.Arrays;

public class CompanyBean {
	
	 private String companyName;
	 EmployeeBean emp;
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public EmployeeBean getEmp() {
		return emp;
	}
	public void setEmp(EmployeeBean emp) {
		this.emp = emp;
	}
	@Override
	public String toString() {
		return "CompanyBean [companyName=" + companyName + ", emp=" + emp + "]";
	}
	
}
