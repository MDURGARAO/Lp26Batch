package spring.javaconfig;

public interface Teacher {

	
	public void teach() ;
		
	
}
