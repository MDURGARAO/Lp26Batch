package spring.javaconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CollegeConfig {

	@Bean
	public College college()
	{
		return new College();
	}
	
	
	
	@Bean
	public MathTeacher getmath()
	{
		return new MathTeacher();
	}
	
	
}
