package spring.validation;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.Locale;
import java.util.Set;

public class ClientBean {
  @Autowired
  private Order order;

  @Autowired
  Validator validator;

  void processOrder () {
      if (validateOrder()) {
          System.out.println("processing " + order);
      }
  }
  
  private boolean validateOrder () {
     // Locale.setDefault(Locale.US);
      Set<ConstraintViolation<Order>> c = validator.validate(order);
      if (c.size() > 0) {
          System.out.println("Order validation errors:");
          c.stream().map(v -> v.getMessage())
           .forEach(System.out::println);
          return false;
      }
      return true;
  }
}
