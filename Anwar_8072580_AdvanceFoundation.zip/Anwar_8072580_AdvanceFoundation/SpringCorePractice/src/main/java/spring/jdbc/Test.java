package spring.jdbc;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;  
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;  
public class Test {  
  
public static void main(String[] args) { 
	
	
//	Resource r=new ClassPathResource("applicationContext.xml");  
//    BeanFactory factory=new XmlBeanFactory(r);  
//      
//    EmployeeDao dao=(EmployeeDao)factory.getBean("edao");  
//    dao.save(new Employee(23,"sonoo",50000)); 
//	
	
    ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");  
      
    EmployeeDao dao=(EmployeeDao)ctx.getBean("edao");
    dao.save(new Employee(23,"sonoo",50000));  
//    List<Employee> list=dao.getAllEmployeesRowMapper();  
//    
//    for(Employee e:list)  
//        System.out.println(e);  
//    List<Employee> list=dao.getAllEmployees();  
//    
//    for(Employee e:list)  
//        System.out.println(e); 
  // Boolean b=dao.saveEmployeeByPreparedStatement(new Employee(104,"Amit",35000));  
//    int status=dao.saveEmployee(new Employee(103,"Aonu",350003));  
   // System.out.println(b);  
          
//    int status=dao.updateEmployee(new Employee(102,"Sonoo",15000)); 
//    System.out.println(status); 
//      
          
//    Employee e=new Employee(); 
//    e.setId(102); 
//    int status=dao.deleteEmployee(e); 
//    System.out.println(status); 
      
}  
  
}  
