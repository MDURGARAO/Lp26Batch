package com.anwar.maven;

/**
 * Hello world!
 *
 */
public class Calculator
{
    public static void multiplication()
{
      int a=2;
int b=8;
int c=a*b;
System.out.println();
}



    }
