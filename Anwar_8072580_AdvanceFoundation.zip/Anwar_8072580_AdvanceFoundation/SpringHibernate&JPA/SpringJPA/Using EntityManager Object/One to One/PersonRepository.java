package com.virtusa.spring.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;


import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.virtusa.spring.model.Person;

@Component
@Repository
public class PersonRepository {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public void savePerson(Person person) {
		entityManager.persist(person);
		
	}

	@Transactional
	public Person fetchPerson(int personId) {
		return entityManager.find(Person.class, personId);
		
	}

}
