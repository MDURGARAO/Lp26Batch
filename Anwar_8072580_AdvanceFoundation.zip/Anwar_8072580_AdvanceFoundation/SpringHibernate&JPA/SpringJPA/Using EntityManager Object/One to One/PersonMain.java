package com.virtusa.spring.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.model.Person;
import com.virtusa.spring.repository.PersonRepository;

public class PersonMain {

	public static void main(String args[]) {
		
		Scanner scanner = new Scanner(System.in);

		ApplicationContext context = new ClassPathXmlApplicationContext("person.cfg.xml");

		PersonRepository personRepository = (PersonRepository) context.getBean("personRepository");
		
		Person person1 = (Person) context.getBean("person1");
		
		Person person2 = (Person) context.getBean("person2");

		personRepository.savePerson(person1);
		
		System.out.println("Enter Person ID");
		System.out.println(personRepository.fetchPerson(scanner.nextInt()).toString());

	}

}
