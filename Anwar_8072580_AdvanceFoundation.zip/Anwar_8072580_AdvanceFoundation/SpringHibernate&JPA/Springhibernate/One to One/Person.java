package com.virtusa.spring.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "persons")
public class Person {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "personId")
	private int personId;
	
	@Column(name = "personName")
	private String personName;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "phoneNo")
	private long phoneNo;
	
	@OneToOne(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private Passport passport;

	public Person() {
		super();
	}

	public Person(int personId, String personName, String address, long phoneNo) {
		super();
		this.personId = personId;
		this.personName = personName;
		this.address = address;
		this.phoneNo = phoneNo;
	}

	public int getPersonId() {
		return personId;
	}

	public void setPersonId(int personId) {
		this.personId = personId;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	

	public Passport getPassport() {
		return passport;
	}

	public void setPassport(Passport passport) {
		this.passport = passport;
	}

	@Override
	public String toString() {
		return "Person [personId=" + personId + ", personName=" + personName + ", address=" + address + ", phoneNo="
				+ phoneNo + ", passport=" + passport + "]";
	}

}
