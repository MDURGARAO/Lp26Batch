package com.virtusa.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Passport {
	@Id
	@Column(name = "passportNo")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int passportNo;
	@Column(name = "issuedLocation")
	private String issuedLocation;
	
	public Passport() {
		super();
	}

	public Passport(int passportNo, String issuedLocation) {
		super();
		this.passportNo = passportNo;
		this.issuedLocation = issuedLocation;
	}

	public int getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(int passportNo) {
		this.passportNo = passportNo;
	}

	public String getIssuedLocation() {
		return issuedLocation;
	}

	public void setIssuedLocation(String issuedLocation) {
		this.issuedLocation = issuedLocation;
	}

	@Override
	public String toString() {
		return "Passport [passportNo=" + passportNo + ", issuedLocation=" + issuedLocation + "]";
	}

}
