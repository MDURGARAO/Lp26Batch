package com.virtusa.spring.repository;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.spring.model.Person;

@Repository
public class PersonRepository {

	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void savePerson(Person person) {
		Session session = sessionFactory.getCurrentSession();
		session.save(person);
	}

	@Transactional
	public void updatePerson(Person person) {
		Session session = sessionFactory.getCurrentSession();
		session.update(person);
	}

	@Transactional
	public void deletePerson(Person person) {
		Session session = sessionFactory.getCurrentSession();
		session.update(person);
	}

	@Transactional
	public Person fetchPerson(int personId) {
		Session session = sessionFactory.getCurrentSession();
		return (Person) session.get(Person.class,personId);
	}

}
