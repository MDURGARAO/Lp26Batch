package com.virtusa.spring.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "developers")
public class Developer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "developerId")
	private int developerId;
	@Column(name = "developerName")
	private String developerName;

	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<Project> projectsList;

	public Developer() {
		super();
	}

	public Developer(int developerId, String developerName, Set<Project> projectsList) {
		super();
		this.developerId = developerId;
		this.developerName = developerName;
		this.projectsList = projectsList;
	}

	public int getDeveloperId() {
		return developerId;
	}

	public void setDeveloperId(int developerId) {
		this.developerId = developerId;
	}

	public String getDeveloperName() {
		return developerName;
	}

	public void setDeveloperName(String developerName) {
		this.developerName = developerName;
	}

	public Set<Project> getProjectsList() {
		return projectsList;
	}

	public void setProjectsList(Set<Project> projectsList) {
		this.projectsList = projectsList;
	}

	@Override
	public String toString() {
		return "Developer [developerId=" + developerId + ", developerName=" + developerName + ", projectsList="
				+ projectsList + "]";
	}

}
