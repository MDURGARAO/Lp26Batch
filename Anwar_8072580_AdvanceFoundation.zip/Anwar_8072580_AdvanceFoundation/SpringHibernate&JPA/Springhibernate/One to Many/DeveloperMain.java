package com.virtusa.spring.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.model.Developer;
import com.virtusa.spring.repository.DeveloperRepository;

public class DeveloperMain {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		ApplicationContext context = new ClassPathXmlApplicationContext("developer.cfg.xml");
		
		DeveloperRepository developerRepository =  context.getBean(DeveloperRepository.class,"developerRepository");
		
		Developer developer1 = (Developer) context.getBean("developer1");
		
		Developer developer2 = (Developer) context.getBean("developer2");
		
		developerRepository.saveDeveloper(developer1);
		
		System.out.println("Enter Developer ID");
		System.out.println(developerRepository.fetchDeveloper(scanner.nextInt()).toString());
		
		developerRepository.updateDeveloper(developer2);
		
		System.out.println("Enter Developer ID");
		System.out.println(developerRepository.fetchDeveloper(scanner.nextInt()).toString());
		
		developerRepository.deleteDeveloper(developer2);
		
	}

}
