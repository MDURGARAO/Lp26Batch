package com.virtusa.spring.repository;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.spring.model.Developer;

@Repository
public class DeveloperRepository {

	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void saveDeveloper(Developer developer) {
		Session session = sessionFactory.getCurrentSession();
		session.save(developer);
	}

	@Transactional
	public void updateDeveloper(Developer developer) {
		Session session = sessionFactory.getCurrentSession();
		session.update(developer);
	}

	@Transactional
	public void deleteDeveloper(Developer developer) {
		Session session = sessionFactory.getCurrentSession();
		session.delete(developer);
	}
	
	@Transactional
	public Developer fetchDeveloper(int developerId) {
		Session session = sessionFactory.getCurrentSession();
		return (Developer) session.get(Developer.class,developerId);
	}

}
