package com.virtusa.spring.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.model.Customer;
import com.virtusa.spring.repository.CustomerRepository;


public class CustomerMain {

	public static void main(String args[]) {
		
		Scanner scanner = new Scanner(System.in);

		ApplicationContext context = new ClassPathXmlApplicationContext("customer.cfg.xml");

		CustomerRepository customerRepository = context.getBean(CustomerRepository.class, "customerRepository");

		Customer customer1 = (Customer) context.getBean("customer1");

		Customer customer2 = (Customer) context.getBean("customer2");
		
		Customer customer3 = (Customer) context.getBean("customer3");

		customerRepository.saveCustomer(customer1);
		customerRepository.saveCustomer(customer2);
		
		System.out.println("Enter Customer ID");
		System.out.println(customerRepository.fetchCustomer(scanner.nextInt()).toString());
		

		customerRepository.updateCustomer(customer3);
		
		System.out.println("Enter Customer ID");
		System.out.println(customerRepository.fetchCustomer(scanner.nextInt()).toString());

		//customerRepository.deleteCustomer(customer3);
	}

}
