/**
 * 
 */
package com.user.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.user.entity.User;


@Repository
public class UserDao {
	HibernateTemplate template;  
	public void setTemplate(HibernateTemplate template) {  
		this.template = template;  
	}  
	//method to save employee
	@Transactional
	public void saveUser(User e){  
		 template.saveOrUpdate(e);
		

		
		
		
	} 
	@Transactional
	public User selectUser(int Id){  
		User list=(User) template.get(User.class, Id);
		return list;
		
		
	}  
	
	@Transactional
	public List<User> gettUser(){  
		List<User> list= template.loadAll(User.class);
		return list;
		
		
	}  
	@Transactional
	public User getUser(int Id){  
		User user=template.get(User.class, Id);
		return user;
	
}

	@Transactional
	public void updateuser(User user){  
		template.update(user);
	
}

	
	@Transactional
	public void deleteUser(int Id){  
		User user=template.get(User.class, Id);
		template.delete(user);
	
}
}
