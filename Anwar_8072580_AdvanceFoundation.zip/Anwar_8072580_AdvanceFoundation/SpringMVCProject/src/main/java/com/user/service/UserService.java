package com.user.service;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.user.dao.UserDao;
import com.user.entity.User;

public class UserService {
    @Autowired
	private UserDao userDao;
	
	public void insertUser(User user)
	{
		userDao.saveUser(user);
	}
	
	public  List<User> getusers()
	{
		List<User> users=userDao.gettUser();
		return users;
	}
	
	public User getusersById(int Id)
	{
		User user=userDao.getUser(Id);
		return user;
	}
	public void update(User user)
	{
		userDao.updateuser(user);
	}
	
	public void delete(int Id)
	{
		userDao.deleteUser(Id);
	}
}
