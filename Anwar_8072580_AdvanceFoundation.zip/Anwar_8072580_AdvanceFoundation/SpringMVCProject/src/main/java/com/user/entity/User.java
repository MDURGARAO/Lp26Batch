/**
 * 
 */
package com.user.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.validation.constraints.NotEmpty;
//import javax.validation.constraints.NotEmpty;
//import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.orm.hibernate4.HibernateTransactionManager;


@Entity
public class User {
	@Override
	public String toString() {
		return "User [userFName=" + userFName + ", userLName=" + userLName + ", userMNo=" + userMNo + "]";
	}
	@Id
@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String userFName;
	private String userLName;
	private String userMNo;
	public String getUserFName() {
		return userFName;
	}
	public void setUserFName(String userFName) {
		this.userFName = userFName;
	}
	public String getUserLName() {
		return userLName;
	}
	public void setUserLName(String userLName) {
		this.userLName = userLName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserMNo() {
		return userMNo;
	}
	public void setUserMNo(String userMNo) {
		this.userMNo = userMNo;
	}
}