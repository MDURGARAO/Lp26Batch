package com.user.exception;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@ControllerAdvice
public class ExceptionController {
	
	
	private static Logger logger=Logger.getLogger(ExceptionController.class);
		
    @ExceptionHandler(Exception.class)
	public String handlexception(HttpServletRequest req,Exception exp)
	{   logger.error(req.getRequestURL()+" "+exp);
		return "error";
	}
	
}
