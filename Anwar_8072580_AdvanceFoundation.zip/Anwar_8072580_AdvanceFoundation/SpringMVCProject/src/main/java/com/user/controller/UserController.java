package com.user.controller;
import java.io.Serializable;
import java.util.List;
import com.user.exception.*;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


import com.user.dao.UserDao;
import com.user.entity.User;
import com.user.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	UserService userservice;
			public UserService getUserservice() {
		return userservice;
	}


	public void setUserservice(UserService userservice) {
		this.userservice = userservice;
	}


			public UserController() {
		System.out.println("In Constructor");
		}


		@RequestMapping(value="/Hello")
		public String helloAdmin()
		{
			return "hello";
		}
		@RequestMapping(value ="/login")
		public String createuser( @ModelAttribute("user") User user,Model modal)
		{  
			
			return "createuser";
		}
		
		@RequestMapping(value ="/welcome")
		public String saveuser(Model modal, @ModelAttribute("user") User user)
		{  

		userservice.insertUser(user); 
		
		    return "redirect:/viewuser";
		}
		@RequestMapping(value ="/viewuser")
		public String viewuser(Model modal, @ModelAttribute("user") User user)
		{  
                 List<User> users= userservice.getusers();    
				 modal.addAttribute("users", users);

		    return "viewusers";
		}

		@RequestMapping(value="/deleteuser/{id}",method = RequestMethod.GET)    
	    public String delete(@PathVariable int id){    
			userservice.delete(id);    
	        return "redirect:/viewuser";    
	    }     
		 @RequestMapping(value="/edituser/{id}")    
		    public String edit(@PathVariable int id, Model m,@ModelAttribute("user") User user){    
		        User user1=userservice.getusersById(id);
		        

		       m.addAttribute("user",user1);
		        
		        return "empeditform";    
		    }    
		    /* It updates model object. */    
		    @RequestMapping(value="/editsave",method = RequestMethod.POST)    
		    public String editsave(@ModelAttribute("user") User user) {    
		    	
		    	userservice.update(user);    
		        return "redirect:/viewuser";    
		    } 
//		    @ExceptionHandler(Exception.class)
//			public String handlexception()
//			{
//				return "error";
//			}
//
	}


