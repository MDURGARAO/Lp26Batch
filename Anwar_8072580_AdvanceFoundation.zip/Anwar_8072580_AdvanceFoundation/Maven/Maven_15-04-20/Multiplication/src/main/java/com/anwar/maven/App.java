package com.anwar.maven;


public class App 
{   


    public static void main( String[] args )
    {
        Calculator.multiplication();
    }
}
