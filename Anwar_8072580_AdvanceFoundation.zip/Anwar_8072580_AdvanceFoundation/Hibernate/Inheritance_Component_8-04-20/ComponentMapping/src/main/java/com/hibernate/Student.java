package com.hibernate;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Student")

public class Student {
		public Student() {
			
		}
		@Id
		@Column(name="id")
		int id ;
		@Column(name="Name")
		String StdName;
		@Column(name="Marks")
		double Marks;
		@Column(name="address")
		Address address;
       @Embedded
		public Address getAddress() {
			return address;
		}
		public void setAddress(Address address) {
			this.address = address;
		}
		@Override
		public String toString() {
			return "Student [id=" + id + ", StdName=" + StdName + ", Marks=" + Marks + ", address=" + address + "]";
		}
				public void setId(int id) {
			this.id = id;
		}
		public int getId() {
					return id;
				}
				public String getStdName() {
					return StdName;
				}
				public double getMarks() {
					return Marks;
				}
		public void setStdName(String stdName) {
			StdName = stdName;
		}
		public void setMarks(double Marks) {
			this.Marks = Marks;
		}
		
		public Student(int id, String empName, double Marks, Address address) {
			super();
			this.id = id;
			StdName = empName;
			this.Marks = Marks;
			this.address = address;
		}
		

	
	
	
	
}



