package com.hibernate.compoundkey;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Accounts {
    
	CompundKey compoundkey;
	private int accountBalance;
	@Id
	public CompundKey getCompoundkey() {
		return compoundkey;
	}
	public void setCompoundkey(CompundKey compoundkey) {
		this.compoundkey = compoundkey;
	}
	public int getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}
	
}
