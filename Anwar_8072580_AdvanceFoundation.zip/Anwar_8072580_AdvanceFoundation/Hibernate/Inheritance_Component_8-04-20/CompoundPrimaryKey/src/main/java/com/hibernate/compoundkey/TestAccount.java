package com.hibernate.compoundkey;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestAccount {
	
	public static void main(String args[])
	{
		CompundKey key1=new CompundKey();
		key1.setUserId(101);
		key1.setAccountId(5001);
		Accounts savings=new Accounts();
		savings.setCompoundkey(key1);
		savings.setAccountBalance(30000);
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		session.save(savings);
		t.commit();
		session.close();
				
	}

}
