package com.hibernate.compoundkey;

import java.io.Serializable;

import javax.persistence.Embeddable;
@Embeddable
public class CompundKey implements Serializable {

	private int userId;
	private int accountId;
		public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	
}
