package com.inheritancemapping;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class Task extends Module {
	
	public Task() {
		super();
		// TODO Auto-generated constructor stub
	}
     @Column(name="taskName")
	private String tastName;

	public String getTastName() {
		return tastName;
	}

	public void setTastName(String tastName) {
		this.tastName = tastName;
	}
	

}
