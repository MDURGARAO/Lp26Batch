package com.inheritancemapping;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class Module extends Project{
	@Column(name="mname")
	private String moduleName;

	public String getModuleName() {
		return moduleName;
	}

	public Module() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	

}
