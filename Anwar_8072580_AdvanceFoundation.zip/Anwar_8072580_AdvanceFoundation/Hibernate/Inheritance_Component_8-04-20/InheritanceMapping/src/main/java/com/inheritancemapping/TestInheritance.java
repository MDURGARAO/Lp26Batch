package com.inheritancemapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestInheritance {
	public static void main(String args[])
	{
		Project project =new Project();
		project.setProjectId(1);
		project.setProjectName("Hibernate");

		Module module=new Module();
		module.setProjectId(2);
		module.setProjectName("Spring");
		module.setModuleName("Aop");


		Task task =new Task();
		task.setProjectId(3);
		task.setProjectName("Java");
		task.setModuleName("Collection");
		task.setTastName("LinkedList");

		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.saveOrUpdate(project);
		session.saveOrUpdate(module);
		session.saveOrUpdate(task);
		Transaction t=session.beginTransaction();


		t.commit();
		session.close();


	}
}
