package com.onetoonemapping;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="PersonDetail")
public class PersonDetail {
    @Id
	private int persondetailId;
	private String zipCode;
	
		
	
		@Override
	public String toString() {
		return "PersonDetail [persondetailId=" + persondetailId + ", zipCode=" + zipCode + ", job=" + job + ", income="
				+ income + ", person=" + person + "]";
	}
		private String job;
	private double income;
	@OneToOne
	private Person person;
		
	   	public int getPersondetailId() {
		return persondetailId;
	}
	
	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public PersonDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setPersondetailId(int persondetailId) {
		this.persondetailId = persondetailId;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public double getIncome() {
		return income;
	}
	public void setIncome(double income) {
		this.income = income;
	}
	
}
