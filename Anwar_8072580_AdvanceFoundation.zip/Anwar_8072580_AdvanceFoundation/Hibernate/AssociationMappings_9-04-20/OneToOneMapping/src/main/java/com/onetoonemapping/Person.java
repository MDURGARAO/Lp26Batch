package com.onetoonemapping;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Person {
	
	@Id
	private int personId;
	private String personNmae;
	@OneToOne
	private PersonDetail persondetail;
	
		public PersonDetail getPersondetail() {
		return persondetail;
	}
	
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Person [personId=" + personId + ", personNmae=" + personNmae + ", persondetail=" + persondetail + "]";
	}
	public void setPersondetail(PersonDetail persondetail) {
		this.persondetail = persondetail;
	}
	public int getPersonId() {
		return personId;
	}
	public void setPersonId(int personId) {
		this.personId = personId;
	}
	public String getPersonNmae() {
		return personNmae;
	}
	public void setPersonNmae(String personNmae) {
		this.personNmae = personNmae;
	}
	

}
