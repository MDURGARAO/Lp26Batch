/**
 * 
 */
package com.virtusa.ManyToMany.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity  
@Table(name="ProjectTable")
public class Project {
	@Id  
	private int projectId;
	
	String projectName;

		public Project() {
		super();
		// TODO Auto-generated constructor stub
	}

		public int getProjectId() {
		return projectId;
	}

		public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	
	public String getProjectName() {
		return projectName;
	}

	
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

}
