package com.onetomanymapping;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestStudent {

	public static void main(String []args)
	{
		College cg=new College();
		cg.setCollegeName("geca");
		
		
		Student s1=new Student();
		s1.setStudentName("aonu");
		s1.setStudentId(101);
		
		Student s2=new Student();
		s2.setStudentName("dubba");
		s2.setStudentId(102);
		
		
		List<Student> al = new ArrayList<Student>();
		al.add(s1);
		al.add(s2);
		cg.setStudents(al);
		cg.setCollegeId(10);
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		session.save(cg);
	session.save(s1);
	session.save(s2);

		
		t.commit();
		session.close();

		
		
	}
}
