package com.onetomanymapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.PropertyProjection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;
import org.hibernate.transform.Transformers;

public class TestStudent {

	public static void main(String []args)
	{

		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		
		// delete query-----------------------------
		/*Query query = session.createQuery("Delete from Student  where studentId = :id");
		query.setInteger("id", 101);
		query.executeUpdate();
		t.commit();
		session.close();*/
		
		//update query----------------------
		/*Query query = session.createQuery("Update Student set studentName='Aonu' where studentName='aonu' ");
		query.executeUpdate();
		t.commit();
		session.close(); */
		
		
		//select query---------------------------------------
		/*Query query=session.createQuery(" from Student");
		query.setFirstResult(1);
		query.setMaxResults(2);
		List<Student> list=query.list();
		list.forEach(System.out::println);
		t.commit();
		session.close();*/
		
		// using Criteria-----------------
		
		// select * from Student
		/*Criteria criteria=session.createCriteria(Student.class);
		List<Student> list=criteria.list();
		list.forEach(System.out::println);
		t.commit();
		session.close();*/
		
		//select * from Student where studentId=101
		/*Criteria criteria=session.createCriteria(Student.class);
		SimpleExpression ex=Restrictions.ge("studentId", 101);
		criteria.add(ex);
		List<Student> list=criteria.list();
		list.forEach(System.out::println);
		t.commit();
		session.close();*/
		
		// select * from student where id=101 and name=aonu----------
		/*Criteria criteria=session.createCriteria(Student.class);
		SimpleExpression ex=Restrictions.ge("studentId", 101);
		SimpleExpression ex1=Restrictions.eq("studentName", "Aonu");
		LogicalExpression ex2=Restrictions.and(ex, ex1);
		criteria.add(ex2);
		criteria.addOrder(Order.desc("studentId"));
		List<Student> list=criteria.list();
		list.forEach(System.out::println);
		t.commit();
		session.close();*/
		
		
		Criteria criteria=session.createCriteria(Student.class);
		PropertyProjection pp=Projections.property("studentName");
		criteria.setProjection(pp);
		List<String> list=criteria.list();
		list.forEach(System.out::println);
		t.commit();
		session.close();
		
		
		
				
		
	}
}
