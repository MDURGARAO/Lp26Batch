package com.shubham.SimpleMapping;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;

@Entity
@Table(name="Car1")
public class Cars {

	@Id
	@GeneratedValue
	@Column(name="carId")
	private long id;
	
	@Column(name="purchaseDate",columnDefinition="date")
	private Date purchaseDate;
	
	@Column(name="modelName")
	private String modelName;
	
	@OneToOne(mappedBy="car")
	@Cascade(value=org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	private Features features;

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public Features getFeatures() {
		return features;
	}

	public void setFeatures(Features features) {
		this.features = features;
	}

	@Override
	public String toString(){
		return id+", "+modelName+", "+purchaseDate+", "+features.getmType()+", "+features.geteType()+", "+features.getgType();
	}
}
