package com.shubham.type1;

import javax.persistence.Embeddable;

@Embeddable
public class Feature {
  private String type;
  private String enginetype;
  private String geartype;
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getEnginetype() {
	return enginetype;
}
public void setEnginetype(String enginetype) {
	this.enginetype = enginetype;
}
public String getGeartype() {
	return geartype;
}
public void setGeartype(String geartype) {
	this.geartype = geartype;
}
  
}