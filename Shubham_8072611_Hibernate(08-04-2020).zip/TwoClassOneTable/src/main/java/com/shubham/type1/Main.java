package com.shubham.type1;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
public class Main {
	public static void main(String[] args) {
		System.out.println("Hello");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		Session session = cfg.buildSessionFactory().openSession();
		Transaction txn = session.beginTransaction();

		Feature feature = new Feature();
		feature.setType("SUV");
		feature.setEnginetype("Petrol");
		feature.setGeartype("Manual");
	
		Car car = new Car();
		car.setBrandName("Renault");
		car.setModelName("Duster");
		car.setFeature(feature);
		
		session.save(car);
		txn.commit();
		session.close(); 
	}
}