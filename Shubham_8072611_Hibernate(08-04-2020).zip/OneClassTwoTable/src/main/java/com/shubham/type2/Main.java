package com.shubham.type2;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
public class Main {
	public static void main(String[] args) {
		System.out.println("Hello");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		Session session = cfg.buildSessionFactory().openSession();
		Transaction txn = session.beginTransaction();

		Movie movie = new Movie();
		movie.setName("Inception");
		movie.setGenre("Thriller Sci-fi");
		movie.setActorName("Leonardo DiCaprio");
		movie.setReleaseYear(2010);

		session.save(movie);
		txn.commit();
		session.close(); 
	}
}