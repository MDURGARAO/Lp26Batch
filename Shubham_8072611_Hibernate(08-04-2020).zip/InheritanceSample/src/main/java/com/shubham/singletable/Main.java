package com.shubham.singletable;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
	public static void main(String[] args) {
		System.out.println("Hello");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		Session session = cfg.buildSessionFactory().openSession();
		Transaction txn = session.beginTransaction();
		
		Employee emp1 = new Employee();
		emp1.setFirstName("Shubham");
		emp1.setLastName("Shandilya");
		
		Developer dev1 = new Developer();
		dev1.setFirstName("Shubham");
		dev1.setLastName("Shandilya");
		dev1.setDomainName("Java");
		dev1.setType("Full Stack");
		dev1.setYears(3);
		
		Tester test1 = new Tester();
		test1.setFirstName("Shubham");
		test1.setLastName("Shandilya");
		test1.setDomainName("Selenium");
		test1.setType("Backend");
		test1.setYears(5);
		
		session.save(emp1);
		session.save(dev1);
		session.save(test1);
		
		txn.commit();
		session.close(); 
	}
}
