/**
 * 
 */
package com.virtusa.mainHQL;





import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.virtusa.entity.Mobile;



public class MobileMainHQL {
	
	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
//		Query query = (Query) session.createQuery("from Mobile");
//		List<Mobile> list = query.list();
//		list.stream().forEach(System.out::println);
		
//		Query query = (Query) session.createQuery("select m.id,m.modelName from Mobile m");
//		List<Object[]> list = query.list();
//		for(Object[] obj : list)
//		{
//			System.out.println(obj[0]+" "+obj[1]);
//		}
//		Query query = (Query) session.createQuery("from Mobile");
//		query.setFirstResult(3);
//		query.setMaxResults(4);
//		List<Object[]> list = query.list();
//		list.forEach(System.out::println);
		
		Query query = (Query) session.createQuery("update Mobile set modelName=? where id=?");
		query.setParameter(0, new Scanner(System.in).next());
		query.setParameter(1, new Scanner(System.in).nextInt());
		int result = query.executeUpdate();
		System.out.println(result);
		session.close();
	}

}
