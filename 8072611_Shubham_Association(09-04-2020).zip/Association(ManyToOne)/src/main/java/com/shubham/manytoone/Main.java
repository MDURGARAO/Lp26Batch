package com.shubham.manytoone;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class Main {
	public static void main(String[] args) {
		
		System.out.println("Hello");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		Session session = cfg.buildSessionFactory().openSession();
		Transaction txn = session.beginTransaction();
	
		Address permAddress = new Address();
		permAddress.setType("Permanent");
		permAddress.setAddress1("Barahiya");
		permAddress.setCity("Lakhisarai");
		permAddress.setState("Bihar");
		permAddress.setZipcode(811302);
		
		Address address = new Address();
		address.setType("Temporary");
		address.setAddress1("Ramapuram");
		address.setCity("Chennai");
		address.setState("Tamilnadu");
		address.setZipcode(600125);
		
		Person person1 = new Person();
		person1.setFirstName("Shubham");
		person1.setLastName("Shandilya");
		person1.setAddress(address);
		
		Person person2 = new Person();
		person2.setFirstName("Aman");
		person2.setLastName("Kumar");
		person2.setAddress(address);
		
		Person person3 = new Person();
		person3.setFirstName("Manav");
		person3.setLastName("Srivastava");
		person3.setAddress(address);
		
		List<Person> person = new ArrayList<Person>();
		person.add(person1);
		person.add(person2);
		person.add(person3);
		
		address.setPerson(person);
		
		session.save(address);
		session.save(person1);
		session.save(person2);
		session.save(person3);
		txn.commit();
		session.close();
		
		
		/***********Delete data*********/
		session = cfg.buildSessionFactory().openSession();
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();
            
            String queryString = "from Person where pId = :temp";
            Query query = session.createQuery(queryString);
            query.setLong("temp", 7);
            Person per = (Person) query.uniqueResult();
            session.delete(per);
            System.out.println("Records deleted!");
            transaction.commit();
        } catch (HibernateException e) {
            transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
		
		/***********Update data********/
        session = cfg.buildSessionFactory().openSession();
        transaction = null;
        try {
            transaction = session.beginTransaction();
            
            String queryString = "from Person where pId = :temp";
            Query query = session.createQuery(queryString);
            query.setLong("temp", 10);
            Person p = (Person) query.uniqueResult();
            p.setLastName("Shubham");
            session.update(person);
            System.out.println("Records updated!");
			  transaction.commit();
        } catch (HibernateException e) {
            transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
		
        /***********View Data**************/
		try {
			session = cfg.buildSessionFactory().openSession();
			txn = session.beginTransaction();
			
            List person4 = session.createQuery("from Person").list();
 
            for (Iterator iterator = person4.iterator(); iterator.hasNext();) {
                Person person5 = (Person) iterator.next();
                System.out.println(person5.getFirstName() + "  "
                        + person5.getLastName() + "  " + person5.getAddress().getType()
                        + "  " + person5.getAddress().getAddress1()+ "  " + person5.getAddress().getCity()
                        + "  " + person5.getAddress().getState()+ "  " + person5.getAddress().getZipcode());
            }
            txn.commit();
        } catch (HibernateException e) {
            txn.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
	}
}
