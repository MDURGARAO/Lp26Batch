package com.shubham.manytoone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
 
@Entity
@Table(name = "Person_ManyToOne")
public class Person {
 
    @Id
    @GeneratedValue
    @Column(name = "pId")
    private Integer personId;
 
    @Column(name = "firstName")
    private String firstName;
 
    @Column(name = "lastName")
    private String lastName;
 

    @ManyToOne(cascade = CascadeType.ALL)
    Address address;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
    
}
