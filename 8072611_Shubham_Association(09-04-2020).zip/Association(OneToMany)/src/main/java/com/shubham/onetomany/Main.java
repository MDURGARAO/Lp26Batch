package com.shubham.onetomany;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
	public static void main(String[] args) {
		
		/***********Insert data***********/
		System.out.println("Hello");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		Session session = cfg.buildSessionFactory().openSession();
		Transaction txn = session.beginTransaction();
	
		Address permAddress = new Address();
		permAddress.setType("Permanent");
		permAddress.setAddress1("Barahiya");
		permAddress.setCity("Lakhisarai");
		permAddress.setState("Bihar");
		permAddress.setZipcode(811302);
		
		Address tempAddress = new Address();
		tempAddress.setType("Temporary");
		tempAddress.setAddress1("Ramapuram");
		tempAddress.setCity("Chennai");
		tempAddress.setState("Tamilnadu");
		tempAddress.setZipcode(600125);
		
		Person person1 = new Person();
		person1.setFirstName("Shubham");
		person1.setLastName("Shandilya");
		
		List<Address> person1Address = new ArrayList<Address>();
		person1Address.add(permAddress);
		person1Address.add(tempAddress);
		
		person1.setAddress(person1Address);
		permAddress.setPerson(person1);
		tempAddress.setPerson(person1);
		
		session.save(permAddress);
		session.save(tempAddress);
		session.save(person1);
		txn.commit();
		session.close();
		
		/***********Delete data*********/
		session = cfg.buildSessionFactory().openSession();
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();
            
            String queryString = "from Person where pId = :temp";
            Query query = session.createQuery(queryString);
            query.setLong("temp", 4);
            Person person = (Person) query.uniqueResult();
            session.delete(person);
            System.out.println("Records deleted!");
            transaction.commit();
        } catch (HibernateException e) {
            transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
		
		/***********Update data********/
        session = cfg.buildSessionFactory().openSession();
        transaction = null;
        try {
            transaction = session.beginTransaction();
            
            String queryString = "from Person where pId = :temp";
            Query query = session.createQuery(queryString);
            query.setLong("temp", 5);
            Person person = (Person) query.uniqueResult();
            person.setLastName("Shubham");
            session.update(person);
            System.out.println("Records updated!");
			  transaction.commit();
        } catch (HibernateException e) {
            transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
		
        /***********View Data**************/
		try {
			session = cfg.buildSessionFactory().openSession();
			txn = session.beginTransaction();
			
            List person = session.createQuery("from Person").list();
 
            for (Iterator iterator = person.iterator(); iterator.hasNext();) {
                Person person2 = (Person) iterator.next();
                System.out.println(person2.getFirstName() + "  "
                        + person2.getLastName() + "  " + person2.getAddress().get(0).getType()
                        + "  " + person2.getAddress().get(0).getAddress1()+ "  " + person2.getAddress().get(0).getCity()
                        + "  " + person2.getAddress().get(0).getState()+ "  " + person2.getAddress().get(0).getZipcode());
            }
            txn.commit();
        } catch (HibernateException e) {
            txn.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
	}
}
