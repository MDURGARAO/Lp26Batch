package com.virtusa.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;
@Entity
@Table(name="teacher")
@SecondaryTable(name="subjectcategory")
public class Teacher {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    @Column(updatable = false, nullable = false)
	private int id;
	private String firstName;
	private String lastName;
	
	@Column(table="subjectcategory")
	private String computer;
	
	@Column(table="subjectcategory")
	private String electrical;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getComputer() {
		return computer;
	}

	public void setComputer(String computer) {
		this.computer = computer;
	}

	public String getElectrical() {
		return electrical;
	}

	public void setElectrical(String electrical) {
		this.electrical = electrical;
	}

	public Teacher(int id, String firstName, String lastName, String computer, String electrical) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.computer = computer;
		this.electrical = electrical;
	}

	public Teacher() {
		super();
	}

	@Override
	public String toString() {
		return "Teacher [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", computer=" + computer
				+ ", electrical=" + electrical + "]";
	}
}
