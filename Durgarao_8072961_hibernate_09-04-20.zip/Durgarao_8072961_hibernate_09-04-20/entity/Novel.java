package com.virtusa.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="novel")
public class Novel {
	
	@Id
    @GeneratedValue
    @Column(name = "ID", unique = true, nullable = false)
    private Integer novelId;
 
    @Column(name = "novelName", unique = true, nullable = false, length = 100)
    private String novelName;
    
    @Column(name = "novelCost", unique = true, nullable = false, length = 100)
    private double novelCost;
    
    @ManyToOne
    private Writer writer;
    
    
    

	public Novel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getNovelId() {
		return novelId;
	}

	public void setNovelId(Integer novelId) {
		this.novelId = novelId;
	}

	public String getNovelName() {
		return novelName;
	}

	public void setNovelName(String novelName) {
		this.novelName = novelName;
	}

	public double getNovelCost() {
		return novelCost;
	}

	public void setNovelCost(double novelCost) {
		this.novelCost = novelCost;
	}

	public Writer getWriter() {
		return writer;
	}

	public void setWriter(Writer writer) {
		this.writer = writer;
	}
    
    
 

}
