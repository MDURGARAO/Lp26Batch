import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.sdnext.hibernate.tutorial.dto.FourWheeler;
import com.sdnext.hibernate.tutorial.dto.TwoWheeler;
import com.sdnext.hibernate.tutorial.dto.Vehicle;

public class MainApplication {

 
 public static void main(String[] args) 
 {
  SessionFactory sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
  Session session = sessionFactory.openSession();
  session.beginTransaction();
  
  Vehicle vehicle = new Vehicle();
  vehicle.setVehicleName("Car");
  
  TwoWheeler twoWheeler = new TwoWheeler();
  twoWheeler.setVehicleName("Bike");
  twoWheeler.setSteeringTwoWheeler("Bike Steering Handle");
  
  FourWheeler fourWheeler = new FourWheeler();
  fourWheeler.setVehicleName("Alto");
  fourWheeler.setSteeringFourWheeler("Alto Steering Wheel");
  
  session.save(vehicle);
  session.save(twoWheeler);
  session.save(fourWheeler);
  
  session.getTransaction().commit();
  session.close();
 }
}