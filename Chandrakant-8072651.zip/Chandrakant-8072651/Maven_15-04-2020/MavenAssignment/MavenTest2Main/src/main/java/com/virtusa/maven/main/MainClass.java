package com.virtusa.maven.main;
import com.virtusa.maven.FirstProgram;
class MainClass
{
	public static void main(String[] args)
	{
	   String name = FirstProgram.printString();
	   System.out.println(name);
	}
}