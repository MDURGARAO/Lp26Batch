package com.virtusa.hibernate.main;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {
	
	public static void main(String[] args) {
		//EmployeeOperation operation = new EmployeeOperation(); 
	    
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	
		Session session = sessionFactory.openSession();
	    session.beginTransaction();
		
		
		
		
		session.save(tester);
		
		session.getTransaction().commit();
		
		
		HibernateUtil.shutdown();
	}
}
