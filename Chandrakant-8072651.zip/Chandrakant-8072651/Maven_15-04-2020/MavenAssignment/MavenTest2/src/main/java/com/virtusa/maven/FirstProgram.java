package com.virtusa.maven;
public class FirstProgram
{
	public static String printString()
	{
		String firstName = "Chandrakant";
		String lastName  = "Bharambe";
                return firstName+" "+lastName;
	}
}