package com.virtusa.hibernate.manytoone;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class College {
	
	@Id  
    @GeneratedValue(strategy=GenerationType.AUTO)  
	private int collegeId;
	private String name;
	private String location;

	public College() {
		super();
	}

	public int getCollegeId() {
		return collegeId;
	}

	public void setCollegeId(int collegeId) {
		this.collegeId = collegeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "College [collegeId=" + collegeId + ", name=" + name + ", location=" + location + "]";
	}
	
}
