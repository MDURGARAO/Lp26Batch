package com.virtusa.hibernate.manytomany;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import java.util.List;

import javax.persistence.*;

@Entity    
public class Person {
	
	@Id  
    @GeneratedValue(strategy=GenerationType.AUTO)  
	private int voterId;
	private String name;
	private String job;
	
	@ManyToMany(targetEntity = Mobile.class, cascade = CascadeType.ALL)  
	@JoinTable(name = "personMobilejoin",   
	            joinColumns = { @JoinColumn  (name = "voterId") },   
	            inverseJoinColumns = { @JoinColumn(name = "MobileId") })  
	private List<Mobile> mobile;

	public int getVoterId() {
		return voterId;
	}

	public void setVoterId(int voterId) {
		this.voterId = voterId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public List<Mobile> getMobile() {
		return mobile;
	}

	public void setMobile(List<Mobile> mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Person [voterId=" + voterId + ", name=" + name + ", job=" + job + ", mobile=" + mobile + "]";
	}
	
}
