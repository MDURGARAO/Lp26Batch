package com.virtusa.hibernate.main;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.PropertyProjection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import com.virtusa.hibernate.entity.Teacher;
import com.virtusa.hibernate.onetomany.Company;
import com.virtusa.hibernate.onetomany.Products;
import com.virtusa.hibernate.onetoone.ValidityCertificate;
import com.virtusa.hibernate.util.HibernateUtil;

public class CriteriaRunner {
	public static void main(String[] args) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		/*
		 * Criteria criteria = session.createCriteria(ValidityCertificate.class);
		 *  List CertificateList = criteria.list();
		 * CertificateList.stream().forEach(System.out::println);
		 */
//		Criteria criteria = session.createCriteria(Products.class);
//		SimpleExpression eq = Restrictions.eq("productName", "ac");
//		criteria.add(eq);
//		List CertificateList = criteria.list();
//	    CertificateList.stream().forEach(System.out::println);
		
//		Criteria criteria = session.createCriteria(Products.class);
//		SimpleExpression ge = Restrictions.ge("productPrice", 10000.0);
//		criteria.add(ge);
//	    List CertificateList = criteria.list();
//	    CertificateList.stream().forEach(System.out::println);
		
//		Criteria criteria = session.createCriteria(Products.class);
//		SimpleExpression eq = Restrictions.eq("productName", "ac");
//		criteria.add(eq);
//		SimpleExpression ge = Restrictions.ge("productPrice", 10000.0);
//		criteria.add(ge);
//		 List CertificateList = criteria.list();
//		 CertificateList.stream().forEach(System.out::println);\
		
//		Criteria criteria = session.createCriteria(Products.class);
//		SimpleExpression eq = Restrictions.eq("productName", "ac");
//		criteria.add(eq);
//		SimpleExpression ge = Restrictions.ge("productPrice", 10000.0);
//		criteria.add(ge);
//		criteria.addOrder(Order.desc("productId"));
//	     List CertificateList = criteria.list();
//		 CertificateList.stream().forEach(System.out::println);
		
//		Criteria criteria = session.createCriteria(Products.class);
//		SimpleExpression eq = Restrictions.eq("productName", "ac");
//		SimpleExpression ge = Restrictions.ge("productPrice", 10000.0);
//		LogicalExpression or = Restrictions.or(eq, ge);
//		criteria.add(or);
//		criteria.addOrder(Order.desc("productId"));
//	     List CertificateList = criteria.list();
//		 CertificateList.stream().forEach(System.out::println);
		
//		 Criteria criteria = session.createCriteria(Products.class);
//		 PropertyProjection property = Projections.property("productName");
//		 criteria.setProjection(property);
//		 List CertificateList = criteria.list();
//     	 CertificateList.stream().forEach(System.out::println);
		
		 Criteria criteria = session.createCriteria(Teacher.class);
		 ProjectionList list = Projections.projectionList();
		 list.add(Projections.property("subject")).
		 	  add(Projections.property("name"));
		 criteria.setProjection(list);
		 List<String> CertificateList = criteria.list();
         CertificateList.forEach(System.out::println);
		
		 session.getTransaction().commit();
		 HibernateUtil.shutdown();
	}
}
