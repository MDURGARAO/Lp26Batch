package com.virtusa.hibernate.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.procedure.ProcedureOutputs;

import com.virtusa.hibernate.util.HibernateUtil;

public class StoredProcedureRunner {

	public static void main(String[] args) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		 ProcedureCall createStoredProcedure= session.createStoredProcedureCall("storedprocedure");
		  System.out.println(createStoredProcedure.getOutputs());
		  HibernateUtil.shutdown();
		 
	}

}
