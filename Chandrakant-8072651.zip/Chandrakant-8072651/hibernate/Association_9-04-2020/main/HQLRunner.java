package com.virtusa.hibernate.main;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.virtusa.hibernate.onetomany.Company;
import com.virtusa.hibernate.util.HibernateUtil;

public class HQLRunner {
		public static void main(String[] args) {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			session.beginTransaction();
			//selecting specific column using entity object
			// Query query = session.createQuery("select new Company(name,location) from Company where name='snapdeal' order by location desc");
			/*List<Company> list = query.list();
			 for(Company cid : list)
			 {
				System.out.println(cid.getName()+" "+cid.getLocation());
			 }*/
			
			//update query as statement in jdbc
			//Query query = session.createQuery("update Company set location='indore' , name='koovs' where companyId=1");
			//query.executeUpdate();
			
	
			
	     /* update query as preparedstatement in jdbc 	
		 * Query query = session.createQuery("update Company set location=:loc , name=:n where companyId=:cid"); 
		 * query.setParameter("loc", "chennai"); 
		 * query.setParameter("n", "ebay");
		 * query.setParameter("cid", 32768); 
		 * query.executeUpdate();*/
		
		//delete query as statement in jdbc	
	    //Query query = session.createQuery("delete from ValidityCertificate where validityId=7");
	    //query.executeUpdate();
			
//		//update query as preparedstatement
//			Query query = session.createQuery("delete from ValidityCertificate where validityId=:vid");
//			query.setParameter("vid", 8);
//			query.executeUpdate();
		
//			Query query = session.createQuery("Insert into Company(companyId,name,location)"+"select companyId,name,location from old_Company");
//			int result = query.executeUpdate();
			
//			Query query = session.createQuery("select sum(productPrice) from Products");
//			List<Integer> sum = query.list();
//			System.out.println(sum.get(0));
			
//			Query query = session.createQuery("select max(productPrice) from Products");
//			List<Integer> sum = query.list();
//			System.out.println(sum.get(0));
			
			
			 session.getTransaction().commit();
			 HibernateUtil.shutdown();
		}
}
