package com.virtusa.hibernate.main;

import java.util.ArrayList;

import com.virtusa.hibernate.manytoone.College;
import com.virtusa.hibernate.manytoone.Student;
import com.virtusa.hibernate.operation.ManyToOne_Operation;

public class ManyToOneRunner {

	public static void main(String[] args) {
		
		ManyToOne_Operation operation = new ManyToOne_Operation();
		College college = new College();
		Student student1 = new Student();
		Student student2 = new Student();
		
		college.setLocation("Raigad");
		college.setName("DBATU");
		
		student1.setAge(19);
		student1.setCollege(college);
		student1.setName("martin");
		
		student2.setAge(20);
		student2.setCollege(college);
		student2.setName("Jones");
		
		ArrayList<Student> studentList = new ArrayList<Student>();
		studentList.add(student1);
		studentList.add(student2);
		
		//operation.insertDataIntoTable(studentList);
		operation.deleteDataFormTable();
		//operation.updateDataOfTable(2);
		//operation.viewDataOfTable();
	}

}
