package com.virtusa.hibernate.main;

import java.util.HashSet;
import java.util.Set;

import com.virtusa.hibernate.onetomany.Company;
import com.virtusa.hibernate.onetomany.Products;
import com.virtusa.hibernate.operation.OneToMany_Operation;

public class OneToManyRunner {
	
	public static void main(String[] args) {
		
		OneToMany_Operation operation = new OneToMany_Operation();
		Company company = new Company();
		Products product1 = new Products();
		Products product2 = new Products();
		Set<Products> set = new HashSet();
		
		
		set.add(product1);
		set.add(product2);
		
		product1.setProductName("tv");
		product1.setProductPrice(5000);
		product2.setProductName("Laptop Charger");
		product2.setProductPrice(500);
		
		company.setLocation("delhi");
		company.setName("amazon"); 
		company.setProducts(set);
	
		//operation.updateDataOfTable(1);
    //operation.insertDataIntoTable(company);
		//operation.deleteDataFormTable(1);
		//operation.viewDataOfTable();
	}
}
