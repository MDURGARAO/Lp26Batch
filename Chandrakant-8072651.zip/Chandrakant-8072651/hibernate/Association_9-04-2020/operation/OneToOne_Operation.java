package com.virtusa.hibernate.operation;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.virtusa.hibernate.onetoone.Person1;
import com.virtusa.hibernate.onetoone.ValidityCertificate;
import com.virtusa.hibernate.util.HibernateUtil;


public class OneToOne_Operation {
	
	ValidityCertificate  certificate = new ValidityCertificate();
	SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
	
	public void insertDataIntoTable(ValidityCertificate certificate) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(certificate);
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}
	
	public void updateDataOfTable(int validityId) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		try {
			certificate = (ValidityCertificate) session.get(ValidityCertificate.class, validityId);
			certificate.setIssuedOfficeLoaction("Amaravti");
			Date d = new Date(2020,03,31);
		    String d1 = sdf.format(d);
			certificate.setIssueDate(d1);
			Person1 person = certificate.getPerson1();
			person.setName("andrew");
			person.setMobNumber(9284150740l);
			certificate.setPerson1(person);
			session.persist(certificate);
			session.getTransaction().commit();
		} catch (Exception e) {
			System.err.println("!!!!Please Enter valid Id");
			HibernateUtil.shutdown();
		}
		finally {
			HibernateUtil.shutdown();
		}
	}
	
	public void deleteDataFormTable(int validityId) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		try {
			certificate = (ValidityCertificate) session.get(ValidityCertificate.class, validityId);;
			session.delete(certificate);		
			session.getTransaction().commit();
		} catch (Exception e) {
			System.err.println("!!!!Please Enter valid Id");
			HibernateUtil.shutdown();
		}
		finally {
			HibernateUtil.shutdown();
		}
	}
	
	public void viewDataOfTable() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from ValidityCertificate");
		List<ValidityCertificate> fetchData = query.list();
		Iterator<ValidityCertificate> iterator = fetchData.iterator();
		while(iterator.hasNext())
		     {
			    certificate = (ValidityCertificate)iterator.next();
	            System.out.println(certificate);
	    }		
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}
}
