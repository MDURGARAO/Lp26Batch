package com.virtusa.hibernate.operation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.virtusa.hibernate.manytomany.Mobile;
import com.virtusa.hibernate.manytomany.Person;
import com.virtusa.hibernate.manytoone.College;
import com.virtusa.hibernate.manytoone.Student;
import com.virtusa.hibernate.util.HibernateUtil;

public class ManyToMany_Operation {
	Person person = new Person();

	public void insertDataIntoTable(ArrayList<Person> personList) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Iterator<Person> iterator = personList.iterator();
		while(iterator.hasNext())
		{
			Person next = iterator.next();
			session.persist(next);
		}	
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}

	public void viewDataOfTable() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Person");
		List<Person> fetchData = query.list();
		Iterator<Person> iterator = fetchData.iterator();
		while(iterator.hasNext())
		{
			person = (Person)iterator.next();
			System.out.println(person);
		}		
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}
	public void updateDataOfTable(int voterId) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		try {
			person = (Person) session.get(Person.class, voterId);
			person.setName("mukesh");
			person.setJob("Python Developer");
			List<Mobile> mobile = person.getMobile();
			Mobile mobile1 = mobile.get(0);
			mobile1.setCompanyName("redmi");
			mobile1.setColor("white");
			mobile1.setModelName("r4");
			Mobile mobile2 = mobile.get(1);
			mobile2.setColor("green");
			mobile2.setCompanyName("lava");
			mobile2.setModelName("l5");
			mobile.clear();
			mobile.add(mobile1);
			mobile.add(mobile2);
			person.setMobile(mobile);
			session.persist(person);
			session.getTransaction().commit();
		} catch (Exception e) {
			System.err.println("!!!!Please Enter valid Id");
			HibernateUtil.shutdown();
		}
		finally {
			HibernateUtil.shutdown();
		}
	}
	public void deleteDataFormTable() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		//EntityManagerFactory emf = Persistence.createEntityManagerFactory("Mobile");
		//EntityManager em = emf.createEntityManager();
		//em.getTransaction().begin();
		session.getTransaction().begin();
		try {
				/*Person person = em.find(Person.class, 3);
				em.remove(person);
				em.getTransaction().commit();
				em.close();*/
			person = (Person) session.get(Person.class, 3);	
			session.delete(person);
			person = (Person) session.get(Person.class, 4);	
			session.delete(person);
			session.getTransaction().commit();
		} catch (Exception e) {
			System.err.println("!!!!Please Enter valid Id");
			HibernateUtil.shutdown();
		}
		finally {
			HibernateUtil.shutdown();
		}	
	}
}
