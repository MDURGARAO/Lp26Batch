package com.virtusa.hibernate.operation;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.virtusa.hibernate.onetomany.Company;
import com.virtusa.hibernate.onetomany.Products;
import com.virtusa.hibernate.onetoone.Person1;
import com.virtusa.hibernate.onetoone.ValidityCertificate;
import com.virtusa.hibernate.util.HibernateUtil;

public class OneToMany_Operation {
	
	Company company = new Company();
	
	public void insertDataIntoTable(Company company) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(company);
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}
	
	public void deleteDataFormTable(int companyId) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		try {
			company = (Company) session.get(Company.class, companyId);;
			session.delete(company);		
			session.getTransaction().commit();
		} catch (Exception e) {
			System.err.println("!!!!Please Enter valid Id");
			HibernateUtil.shutdown();
		}
		finally {
			HibernateUtil.shutdown();
		}	
	}
	public void updateDataOfTable(int companyId) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		try {
			company = (Company) session.get(Company.class, companyId);
			company.setLocation("Amaravti");
		    company.setName("ebay");
			Collection<Products> products = company.getProducts();
			Iterator<Products> iterator = products.iterator();
			while(iterator.hasNext())
			{
				Products next = iterator.next();
				next.setProductName("ac");
				next.setProductPrice(10000);
			}
			company.setProducts(products);
			session.persist(company);
			session.getTransaction().commit();
		} catch (Exception e) {
			System.err.println("!!!!Please Enter valid Id");
			HibernateUtil.shutdown();
		}
		finally {
			HibernateUtil.shutdown();
		}
	}

	public void viewDataOfTable() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query createQuery = session.createQuery("select max(productPrice) from Products ");
		List<Integer> list = createQuery.list();
		System.out.println(list.get(0));
		Query query = session.createQuery("from Company");
		List<Company> fetchData = query.list();
		Iterator<Company> iterator = fetchData.iterator();
		while(iterator.hasNext())
		     {
			    company = (Company)iterator.next();
	            System.out.println(company);
	    }		
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}

}
