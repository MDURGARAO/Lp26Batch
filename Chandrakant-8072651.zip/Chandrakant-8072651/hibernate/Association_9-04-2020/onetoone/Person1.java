package com.virtusa.hibernate.onetoone;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="citizen")
public class Person1 {
	
	@Id  
    @GeneratedValue(strategy=GenerationType.AUTO)  
	private int pId;
	private String name;
	private double mobNumber;
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getMobNumber() {
		return mobNumber;
	}
	public void setMobNumber(double mobNumber) {
		this.mobNumber = mobNumber;
	}
	
	@Override
	public String toString() {
		return "Person1 [pId=" + pId + ", name=" + name + ", mobNumber=" + mobNumber + "]";
	}
	
}
