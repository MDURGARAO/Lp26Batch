DELIMITER//
CREATE PROCEDURE storedprocedure ()
BEGIN
  SELECT 'its working';
END;