package com.virtusa.hibernate.twoclassonetable;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
	public Address(String hno, String streeName, int pincode) {
		
		this.hno = hno;
		this.streeName = streeName;
		this.pincode = pincode;
	}
	
	public Address() {
		super();
	}

	private String hno;
	private String streeName;
	private int pincode;
	public String getHno() {
		return hno;
	}
	public void setHno(String hno) {
		this.hno = hno;
	}
	public String getStreeName() {
		return streeName;
	}
	public void setStreeName(String streeName) {
		this.streeName = streeName;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
}
