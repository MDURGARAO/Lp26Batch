package com.virtusa.hibernate.inheritance;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@PrimaryKeyJoinColumn(name="ID")
public class Developer extends Employee{
	
	private int department;
	private String technology;
	private String projectName;
	

	
	public Developer(int empId, String empName, double empSal, String empDesignation, int department, String technology,
			String projectName) {
		super(empId, empName, empSal, empDesignation);
		this.department = department;
		this.technology = technology;
		this.projectName = projectName;
	}
	public int getDepartment() {
		return department;
	}
	public void setDepartment(int department) {
		this.department = department;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
}
