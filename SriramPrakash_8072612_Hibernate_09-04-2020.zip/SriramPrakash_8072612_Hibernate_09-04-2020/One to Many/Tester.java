package com.virtusa.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Tester")
public class Tester {
	@Id
	@Column(name = "ID")
	private int id;
	@Column(name = "Name")
	private String name;
	
	@OneToMany(cascade = CascadeType.ALL)
	private Set<Project> project;

	public Tester() {
		super();
	}

	public Tester(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Project> getProject() {
		return project;
	}

	public void setProject(Set<Project> project) {
		this.project = project;
	}

	@Override
	public String toString() {
		return "Tester [id=" + id + ", name=" + name + "]";
	}

}
