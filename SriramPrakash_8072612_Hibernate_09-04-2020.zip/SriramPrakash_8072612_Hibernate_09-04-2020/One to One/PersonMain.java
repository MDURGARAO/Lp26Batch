package com.virtusa.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entities.Passport;
import com.virtusa.entities.Person;

public class PersonMain {
	
	public static void main(String args[]) {
		
		Passport passport = new Passport(12546,"Chennai");
		
		Person person = new Person(101,"Prakash","Chennai",987654321);
		person.setPassport(passport);
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		//session.save(person);
		Person person1 =  session.get(Person.class,101);
		System.out.println(person1.toString());
		
		transaction.commit();
		session.close();
	}
	
	

}
