package com.virtusa.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "College")
public class College {
	@Id
	@Column(name = "CollegeCode")
	private int collegeCode;
	@Column(name = "CollegeName")
	private String collegeName;
	
	public College() {
		super();
	}
	public College(int collegeCode, String collegeName) {
		super();
		this.collegeCode = collegeCode;
		this.collegeName = collegeName;
	}
	public int getCollegeCode() {
		return collegeCode;
	}
	public void setCollegeCode(int collegeCode) {
		this.collegeCode = collegeCode;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	@Override
	public String toString() {
		return "College [collegeCode=" + collegeCode + ", collegeName=" + collegeName + "]";
	}

}
