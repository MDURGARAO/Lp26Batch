package com.twoclass.onetable.twoaddress;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Table;
@Embeddable
public class Address {

	 @Column(name="PRESENT_STREET_NAME")
		private String street;
	    @Column(name="PRESENT_CITY_NAME")
		private String city;
	    @Column(name="PRESENT_STATE_NAME")
		private String state;
	    @Column(name="PRESENT_PIN_CODE")
		private String pinCode;
		public String getStreet() {
			return street;
		}
		public void setStreet(String street) {
			this.street = street;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public String getPinCode() {
			return pinCode;
		}
		public void setPinCode(String pinCode) {
			this.pinCode = pinCode;
		}
	    
}
