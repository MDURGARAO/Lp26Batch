package com.onetoone.mapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class PersonTest {

	public static void main(String[] args) {
		
		PersonDetail personDetail=new PersonDetail();
		//personDetail.setPersonDetailId(222);
		personDetail.setZipCode(1234);
		personDetail.setJob("Farmer");
		personDetail.setIncome(100000);
		
		Person person=new Person();
		//person.setPersonId(111);
		person.setPersonName("Sangkara");
		person.setPersonDetail(personDetail);
		
		
		Configuration configuration=new Configuration();
		configuration.configure("onetoone.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(person);
		
		transaction.commit();
		session.close();
	}
}
