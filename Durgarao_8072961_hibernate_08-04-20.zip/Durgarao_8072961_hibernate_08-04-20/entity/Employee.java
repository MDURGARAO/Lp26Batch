package com.virtusa.hibernate.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name="employee")
public class Employee {
	@Id
	@JoinColumn(name="eId")
	private int employeeId;
	private String empName[];
	private String empDesignation;
	private double salary;
	private char age;
	private String address;
	
	private Date date;
	public Employee(int employeeId, String[] empName, String empDesignation, double salary, char age, String address,
			boolean isSelected, Date date) {
		super();
		this.employeeId = employeeId;
		this.empName = empName;
		this.empDesignation = empDesignation;
		this.salary = salary;
		this.age = age;
		this.address = address;
		this.isSelected = isSelected;
		this.date = date;
	}
	private boolean isSelected;
	
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}


	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	
	public String[] getEmpName() {
		return empName;
	}
	public void setEmpName(String[] empName) {
		this.empName = empName;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public boolean isSelected() {
		return isSelected;
	}

	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}
	
	public char getAge() {
		return age;
	}
	public void setAge(char age) {
		this.age = age;
	}

}
