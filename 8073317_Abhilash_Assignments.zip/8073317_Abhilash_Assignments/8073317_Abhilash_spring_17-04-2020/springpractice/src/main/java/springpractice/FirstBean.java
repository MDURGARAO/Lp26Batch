package springpractice;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class FirstBean {
     private String message;
     private Date date;
     private Address address;
     private int integer;
     private int array[];
     private List<String> cars;
     private TreeSet<Integer> set;


	public FirstBean(String message, Date date, Address address) {
		super();
		this.message = message;
		this.date = date;
		this.address = address;
		
	}

	public FirstBean() {
		super();
		System.out.println("eagrly loaded");
	}

	public TreeSet<Integer> getSet() {
		return set;
	}

	public void setSet(TreeSet<Integer> set) {
		this.set = set;
	}

	public int[] getArray() {
		return array;
	}

	public void setArray(int[] array) {
		this.array = array;
	}

	public int getInteger() {
		return integer;
	}

	public List getCars() {
		return cars;
	}

	public void setCars(List cars) {
		this.cars = cars;
	}

	public void setInteger(int integer) {
		this.integer = integer;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "FirstBean [message=" + message + ", date=" + date + ", address=" + address + "]";
	}

	
     
}
