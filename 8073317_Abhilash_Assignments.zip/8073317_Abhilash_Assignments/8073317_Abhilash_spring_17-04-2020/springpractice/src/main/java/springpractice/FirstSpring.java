package springpractice;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class FirstSpring {

	public static void main(String[] args) {
          String xmls[] = {"bean.xml","second.xml"};
	      ApplicationContext context=new ClassPathXmlApplicationContext(xmls);
	      FirstBean bean = (FirstBean)context.getBean("second");
	      System.out.println(bean.toString());
	      System.out.println(bean.getInteger());
	      int[] array = bean.getArray();
	      for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}
	      bean.getCars().forEach(System.out::println);
	      bean.getSet().forEach(System.out::println);
	      
	      Employee bean2 = (Employee) context.getBean("dev");
	      System.out.println(bean2);
	      FirstBean obj1 = (FirstBean)context.getBean("bean");
	      FirstBean obj2 =(FirstBean) context.getBean("bean");
	      System.out.println(obj1==obj2);
	}

}
