package springpractice;

public class Employee {
   private String name;
   private int empid;
   private String company;
   
public String getCompany() {
	return company;
}
public void setCompany(String company) {
	this.company = company;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
@Override
public String toString() {
	return "Employee [name=" + name + ", empid=" + empid + ", company=" + company + "]";
}

   
}
