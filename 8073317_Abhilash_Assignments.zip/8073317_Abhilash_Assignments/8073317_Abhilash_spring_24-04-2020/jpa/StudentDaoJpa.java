package com.spring.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.springframework.transaction.annotation.Transactional;

public class StudentDaoJpa {
	
	  private EntityManagerFactory template;  
	  
	    
	    public EntityManagerFactory getTemplate() {
		return template;
	}
	public void setTemplate(EntityManagerFactory template) {
		this.template = template;
	}
	    @Transactional
		public void saveStudent(Student1 student) {
			EntityManager entityManager = template.createEntityManager();
			EntityTransaction transaction = entityManager.getTransaction();
			//transaction.begin();
			entityManager.persist(student);
			//transaction.commit();
		
		}

}
