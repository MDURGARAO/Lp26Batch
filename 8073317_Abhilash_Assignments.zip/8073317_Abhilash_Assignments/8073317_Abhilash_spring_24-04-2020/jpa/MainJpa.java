package com.spring.jpa;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainJpa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("jpa.xml");
		StudentDaoJpa dao = context.getBean(StudentDaoJpa.class);
		Student1 student = context.getBean(Student1.class);
		student.setId(24);
		student.setMarks(50);
		student.setName("arjun");
		dao.saveStudent(student);
		

	}

}
