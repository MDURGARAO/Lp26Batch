package springpractice;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MSWordMain {

	public static void main(String[] args) {
        ApplicationContext context  = new ClassPathXmlApplicationContext("second.xml");
      MSWord  word=(MSWord)context.getBean("msWord");
      word.spellChecking();
      word.autoSaving();
      
	}

}
