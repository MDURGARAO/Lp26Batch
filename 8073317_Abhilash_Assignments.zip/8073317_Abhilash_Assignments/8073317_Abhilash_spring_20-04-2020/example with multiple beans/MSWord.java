package springpractice;

public class MSWord {

	public MSWord() {
		System.out.println("inside MSWord constructor");
	}
	
	SpellCheck spellCheck;
	AutoSave autoSave;
	public SpellCheck getSpellCheck() {
		return spellCheck;
	}
	public void setSpellCheck(SpellCheck spellCheck) {
		this.spellCheck = spellCheck;
	}
	public AutoSave getAutoSave() {
		return autoSave;
	}
	public void setAutoSave(AutoSave autoSave) {
		this.autoSave = autoSave;
	}
	
	public void spellChecking() {
		spellCheck.spellCheck();
	}
    
	public void autoSaving() {
		autoSave.autoSave();
	}
}
