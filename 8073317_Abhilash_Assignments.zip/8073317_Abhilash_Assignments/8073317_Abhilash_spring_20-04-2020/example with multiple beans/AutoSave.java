package springpractice;

public class AutoSave {

	public AutoSave() {
		System.out.println("inside AutoSave constructor");
	}
	
	public void autoSave() {
		System.out.println("auto saving!!!");
	}

}
