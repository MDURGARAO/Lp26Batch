package springpractice;

public class SpellCheck {
	
	public SpellCheck() {
		System.out.println("inside constructor of SpellCheck");
	}
	
	public void spellCheck() {
		
		System.out.println("checking Spelling!!");
	}

}
