package springpractice;

import org.springframework.stereotype.Component;

@Component
public class MediaTek implements MobileProcessor {

	@Override
	
	public void process() {
		// TODO Auto-generated method stub
		System.out.println("MediaTek processor");
	}
	

}
