package springpractice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
@Component
public class Motorola {
	
	@Autowired
	@Qualifier("mediaTek")
	private MobileProcessor processor;
	
	public MobileProcessor getProcessor() {
		return processor;
	}

	public void setProcessor(MobileProcessor processor) {
		this.processor = processor;
	}

	public void specification() {
		System.out.println("4GB ram, 64GB ROM, 16MP camera");
		processor.process();
	}

}
