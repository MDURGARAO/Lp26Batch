package springpractice;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class Snapdragon implements MobileProcessor {

	@Override
	public void process() {
		// TODO Auto-generated method stub
		System.out.println("Snapdragon processor");
	}

}
