package springpractice;

public interface MobileProcessor {
	
	void process();

}
