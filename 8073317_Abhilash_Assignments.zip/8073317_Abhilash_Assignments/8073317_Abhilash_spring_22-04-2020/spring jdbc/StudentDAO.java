package com.spring.jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;

public class StudentDAO {
	
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int saveStudent(Student s) {
		 String query="insert into stud values("+s.getId()+",'"+s.getName()+"',"+s.getMarks()+")";  
				    return jdbcTemplate.update(query);
	}
	
	public int updateStudent(Student s) {
		
		String query="update stud set name='"+s.getName()+"',marks="+s.getMarks()+" where id="+s.getId();  
			    return jdbcTemplate.update(query);  
	}
	
	public int deleteStudent(Student s){  
	    String query="delete from stud where id="+s.getId();  
	    return jdbcTemplate.update(query);  
	}  
	
	public Boolean saveEmployeeByPreparedStatement(final Student s){  
	    String query="insert into stud values(?,?,?)";  
	    return jdbcTemplate.execute(query,new PreparedStatementCallback<Boolean>(){  

		@Override
		public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
			 ps.setInt(1,s.getId());  
		        ps.setString(2,s.getName());  
		        ps.setInt(3,s.getMarks());  
		              
		        return ps.execute();  
		}  
	    });  
	}  
	public List<Student> getAllStudents(){  
		 return jdbcTemplate.query("select * from stud",new ResultSetExtractor<List<Student>>(){  
		    @Override  
		     public List<Student> extractData(ResultSet rs) throws SQLException,  
		            DataAccessException {  
		      
		        List<Student> list=new ArrayList<Student>();  
		        while(rs.next()){  
		        	Student e=new Student();  
		        e.setId(rs.getInt(1));  
		        e.setName(rs.getString(2));  
		        e.setMarks(rs.getInt(3));  
		        list.add(e);  
		        }  
		        return list;  
		        }  
		    }); 
	}

}
