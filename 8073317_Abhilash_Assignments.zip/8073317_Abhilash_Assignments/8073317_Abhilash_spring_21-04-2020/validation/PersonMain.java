package com.validation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.ObjectError;

public class PersonMain {

	public static void main(String[] args) {

		ApplicationContext context  = new ClassPathXmlApplicationContext("validation.xml");
		Person person = context.getBean(Person.class,"person");
		PersonValidator pvalid = context.getBean(PersonValidator.class,"valodator");
		Map<String, String> map= new HashMap<String, String>();
		MapBindingResult err = new MapBindingResult(map, Person.class.getName());
		System.out.println(person.getAge());
		pvalid.validate(person, err);
		
		List<ObjectError> allErrors = err.getAllErrors();
		
		for(ObjectError e: allErrors) {
			System.out.println(e.getDefaultMessage());
		}
		
	}

}
