package com.validation;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

public class PersonValidator implements Validator{

	@Override
	public boolean supports(Class clazz) {
		 return Person.class.equals(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		 ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "name.empty","name cant be empty");
	        Person p = (Person) obj;
	        if (p.getAge() < 0) {
	            errors.rejectValue("age", "negativevalue","negative Value");
	        } else if (p.getAge() > 110) {
	            errors.rejectValue("age", "too.darn.old", " too old");
	        }
		
	}

}
