package com.spring.hibernate;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Propagation;

public class StudentDao {

	private HibernateTemplate template;

	public HibernateTemplate getTemplate() {
		return template;
	}

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	//method to save employee  
	@Transactional
	public void saveStudent(Student e){  
		SessionFactory sessionFactory = template.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
	    template.save(e);  
	    session.getTransaction().commit();
	}  
	//method to update employee 
	@Transactional
	public void updateStudent(Student e){  
	    template.update(e);  
	}  
	//method to delete employee  
	@Transactional
	public void deleteStudent(Student e){  
	    template.delete(e);  
	}  
	//method to return one employee of given id  
	public Student getById(int id){  
		Student e=(Student)template.get(Student.class,id);  
	    return e;  
	}  
	//method to return all employees 
	@Transactional
	public List<Student> getAllStudent(){  
	    List<Student> list=new ArrayList<Student>();  
	    list=template.loadAll(Student.class);  
	    return list;  
	}  
}
