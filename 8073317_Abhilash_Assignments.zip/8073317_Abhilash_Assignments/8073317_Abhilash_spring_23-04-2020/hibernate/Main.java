package com.spring.hibernate;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("hibernate.xml");
		StudentDao dao = context.getBean(StudentDao.class,"stud");
		//dao.saveStudent(new Student(8, "tarun", 50));
//		dao.updateStudent(new Student(8, "tarun", 60));
		List<Student> student = dao.getAllStudent();
		student.forEach(System.out::println);
//		Course course=(Course)context.getBean("course");
//		Laptop laptop = new Laptop(1213, "xyz");
//		Passport passport = new Passport(12322, new Date(), "mumbai");
//		Student student = new Student(12, "Alita", 98, Arrays.asList(laptop));
//		student.setCourse(Arrays.asList(course));
//		course.setStudent(Arrays.asList(student));
//		student.setPassport(passport);
//		passport.setStud(student);
//		laptop.setStud(student);
//        dao.saveStudent(student);
	}

}
