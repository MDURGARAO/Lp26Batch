package com.spring.hibernate;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name = "stu")
public class Student {
	@Id
	private int id;
	private String name;
	private int marks;
	@OneToMany(cascade = {javax.persistence.CascadeType.ALL})
	@Cascade(CascadeType.ALL)
	private List<Laptop> laptop = new ArrayList<Laptop>();
	@OneToOne(cascade = {javax.persistence.CascadeType.ALL})
	@Cascade(CascadeType.ALL)
	private Passport passport;
	@ManyToMany(fetch = FetchType.EAGER,cascade = {javax.persistence.CascadeType.ALL})
	@Cascade(CascadeType.ALL)
	private List<Course> course;
	
	
	public List<Course> getCourse() {
		return course;
	}
	public void setCourse(List<Course> course) {
		this.course = course;
	}
	public Passport getPassport() {
		return passport;
	}
	public void setPassport(Passport passport) {
		this.passport = passport;
	}
	public List<Laptop> getLaptop() {
		return laptop;
	}
	public void setLaptop(ArrayList<Laptop> laptop) {
		this.laptop = laptop;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	
	
	public Student(int id, String name, int marks, List<Laptop> laptop) {
		super();
		this.id = id;
		this.name = name;
		this.marks = marks;
		this.laptop = laptop;
	}
	public Student() {
		super();
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", marks=" + marks + ", laptop=" + laptop + ", passport="
				+ passport + ", course=" + course + "]";
	}
	
	
	

}
