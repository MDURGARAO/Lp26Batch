package com.virtusa.hibernate.entity;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.PropertyProjection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

public class EmployeeHCQL {

	public static void main(String[] args) {

		Configuration configuration = new Configuration().configure();
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
//		Criteria criteria = session.createCriteria(Employee.class);
//		List<Employee> emplist = criteria.list();
//		emplist.forEach(System.out::println); 
//		Criteria criteria = session.createCriteria(Employee.class);
//		SimpleExpression ge = Restrictions.ge("sal", 20000.00);
//		criteria.add(ge);
//		Criteria criteria = session.createCriteria(Employee.class);
//		SimpleExpression ge = Restrictions.ge("sal", 20000.00);
//		SimpleExpression eq = Restrictions.eq("name", "kapil");
//		LogicalExpression and = Restrictions.and(ge, eq);
//		criteria.add(and);
//		
//		Criteria criteria = session.createCriteria(Employee.class);
		Criteria criteria = session.createCriteria(Employee.class);
		PropertyProjection property = Projections.property("name");
		//criteria.addOrder(Order.asc("sal"));
		criteria.setProjection(property);
		List list = criteria.list();
		list.stream().forEach(System.out::println);
		session.close();
	}
}
