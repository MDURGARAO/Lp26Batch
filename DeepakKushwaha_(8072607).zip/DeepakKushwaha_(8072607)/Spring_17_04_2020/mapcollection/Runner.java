package com.virtusa.mapcollection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Runner {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("springconfig.xml");
		College college = (College) context.getBean("college");
		college.dispalyInfo();
	}

}
