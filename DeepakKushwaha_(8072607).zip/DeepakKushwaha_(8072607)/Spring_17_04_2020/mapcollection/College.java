package com.virtusa.mapcollection;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class College {

	private int id;
	private String name;
	private Map<Integer,String> student;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Map<Integer, String> getStudent() {
		return student;
	}
	public void setStudent(Map<Integer, String> student) {
		this.student = student;
	}

	@Override
	public String toString() {
		return "College [id=" + id + ", name=" + name + ", student=" + student + "]";
	}

	public void dispalyInfo() {
		System.out.println(id+" "+ name);
		System.out.println();
		Set<Entry<Integer, String>> set=student.entrySet();  
		Iterator<Entry<Integer, String>> itr=set.iterator();  
		while(itr.hasNext()){  
			Entry<Integer, String> entry=itr.next();  
			System.out.println("Student Id:"+entry.getKey()+"Student Name:"+entry.getValue());
		}


	}
}
