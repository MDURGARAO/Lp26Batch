package com.virtusa.collection;

import java.util.Iterator;
import java.util.List;

public class Company {
	private int cId;
	private String cName;
	private List<Employee> employee;


	public Company() {
		super();
		System.out.println("company...");
	}

	public Company(int cId, String cName, List<Employee> employee) {
		super();
		this.cId = cId;
		this.cName = cName;
		this.employee = employee;
	}

	public int getcId() {
		return cId;
	}

	public void setcId(int cId) {
		this.cId = cId;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public List<Employee> getEmployee() {
		return employee;
	}

	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}

	@Override
	public String toString() {
		return "Company [cId=" + cId + ", cName=" + cName + ", employee=" + employee + "]";
	}

	public void show() {
		System.out.println(cId+" "+cName);
		Iterator<Employee> iterator = employee.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
}
