package com.virtusa.collection;

public class Employee {

	private int empId;
	private String empName;
	private long mobile;
	private Address address;
	public Employee(int empId, String empName, long mobile, Address address) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.mobile = mobile;
		this.address = address;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", mobile=" + mobile + ", address=" + address
				+ "]";
	}
	
	
}
