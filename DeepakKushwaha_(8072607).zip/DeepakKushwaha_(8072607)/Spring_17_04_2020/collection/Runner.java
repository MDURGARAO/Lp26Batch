package com.virtusa.collection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Runner {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("springconfig.xml");
		Company company = (Company) context.getBean("company");
		Company company1 = (Company) context.getBean("company");
		System.out.println(company==company1);
		company.show();
		company1.show();
	}
}

