package com.virtusa.springcore;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Runner {
 
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springconfig.xml");
		//Resource resource = new ClassPathResource("springconfig.xml");
		//BeanFactory factory = new XmlBeanFactory(resource);
		//Student student = (Student) factory.getBean("studentbean");
		Student student = (Student) applicationContext.getBean("studentbean");
		student.displayInfo(student); 
	}
}
