package com.virtusa.autowiring;

public class Ola {
	private int bookingId;
	private Car car;
	private Driver driver;
	private Payment payment;
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public Car getCar() {
		return car;
	}
	public void setCar(Car car) {
		this.car = car;
	}
	public Driver getDriver() {
		return driver;
	}
	public void setDriver(Driver driver) {
		this.driver = driver;
	}
	public Payment getPayment() {
		return payment;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	@Override
	public String toString() {
		return "Ola [bookingId=" + bookingId + ", car=" + car + ", driver=" + driver + ", payment=" + payment + "]";
	}

	public void displayInfo() {
		System.out.println(bookingId);
		System.out.println(car+"\n"+driver+"\n"+payment);
	}
}
