package com.virtusa.constructorinjection;

import java.util.List;

public class Employee {

	private int id;
	private String name;
	private List<Address> address;
	
//	public Employee() {
//		super();
//	}
	
	public Employee(int id) {
		super();
		this.id = id;
	}

	public Employee(String name) {
		super();
		this.name = name;
	}

	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	

	public Employee(int id, String name, List<Address> address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}

	public void show(Employee employee) {
		System.out.println(employee);
	}
	
	public void show() {
		System.out.println(id+" "+name);
		System.out.println(address);
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}
	
	
}
