package com.virtusa.hibernate;
import com.virtusa.mavenproject.Calculator;
 class Application{
	public static void main(String[] args){
		int a = Calculator.add(3,4);
		System.out.println(a);
	}
 }