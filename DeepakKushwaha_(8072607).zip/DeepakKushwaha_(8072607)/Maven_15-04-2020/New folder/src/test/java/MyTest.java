import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class MyTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("abcd");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("xyz");
	}

	@Test
	public void test() {
		assertEquals("hey", "hey");
	}

}
