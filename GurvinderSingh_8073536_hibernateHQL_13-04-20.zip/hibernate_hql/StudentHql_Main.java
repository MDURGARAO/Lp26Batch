package com.virtusa.main;

import java.util.List;
import java.util.Random;

//import javax.persistence.Query;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.transform.Transformers;

import com.hql.practise.Student;

public class StudentHql_Main {

	public static void main(String[] args) {
		
	Configuration configuration = new Configuration();
	configuration.configure("hibernate.cfg.xml");
	SessionFactory sessionFactory = configuration.buildSessionFactory();
	Session session = sessionFactory.openSession();
	
	//Create 
//	for(int i=1; i<=10; i++) {
//		Student stu = new Student();
//		stu.setStudentId(i);
//		stu.setStudentName("Student" + i);
//		stu.setMarksObtained(ran.nextInt(100));
//		openSession.save(stu);
//	}
	
	//To fetch all the data
//	Query query = session.createQuery("from Student");
//	List<Student> student = query.list();
//	for(Student stu : student) {
//		System.out.println(stu);
//	}
	
	//To get unique value or one value
//	Query query = session.createQuery("from Student where studentId = 7");
//	Student student = (Student)query.uniqueResult();
//	System.out.println(student);
//	
	//To get multiple rows
	
//	Query query = session.createQuery("select s.studentId, s.studentName from Student as s where s.marksObtained > 50" );
//	List<Object[]> student =  query.list();
//	
//	for(Object[] array : student) {
//		System.out.println(array[0] +" "+ array[1]);
//	}
	
	
	//ResultTransform
//	Query query = session.createQuery("select s.studentId, s.studentName, s.marksObtained from Student as s");
//	query.setResultTransformer(Transformers.aliasToBean(Student.class));
//	List<Student> stud = query.list();
//	for(Student stu : stud) {
////	System.out.println(stu.getStudentId() +" "+ stu.getStudentName());
//	System.out.println(stu);
//}
	
	
	
	//Using Constructor
	Query query = session.createQuery("select new Student(studentId, studentName, marksObtained) from Student");
	List<Student> list = query.list();
	
	for(Student stu : list) {
//		System.out.println(stu.getStudentId() +" "+ stu.getStudentName());
		System.out.println(stu);
	}
	
}
	}