package com.virtusa.hibernate.operation;

import java.io.Serializable;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.hibernate.inheritance.Employee;
import com.virtusa.hibernate.util.HibernateUtil;

public class EmployeeOperation {
	
	
	public int insertEmployee(Employee emp) {
		SessionFactory factory=HibernateUtil.getFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Serializable returnPk=session.save(emp);
		Integer id=(Integer) returnPk;
		transaction.commit();
		return id;
		
	}
	public Employee fetchEmployee(int pk)
	{SessionFactory factory=HibernateUtil.getFactory();
	Session session=factory.openSession();
	Transaction transaction=session.beginTransaction();
		
		Employee emp=session.get(Employee.class, pk);
		return emp;
	}
	public void deleteEmployee(int pk)
	{
		SessionFactory factory=HibernateUtil.getFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Employee employee=session.get(Employee.class, pk);
		session.delete(employee);
		transaction.commit();
		
	}
	public void updateEmployee(Employee employee,int pk)
	{
		SessionFactory factory=HibernateUtil.getFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Employee  empData=session.get(Employee.class,pk);
		String employeeName=employee.getEmployeeName();
		double employeeSalary=employee.getEmployeeSalary();
		empData.setEmployeeName(employeeName);
		empData.setEmployeeSalary(employeeSalary);
		session.update(empData);
		transaction.commit();
		
	}

}
