package com.virtusa.hibernate.embedded;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Employee implements Serializable
{
@Id
//below two lines are used for automated generation of pk
@GeneratedValue(generator="xr")
@GenericGenerator(name="xr",strategy="increment")
private int id;
@Column(name="emp_name")
private String name;

@Column(name="department")
private String dept;
 @Embedded//@OneTOne
private Address address;
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", dept=" + dept + ", address=" + address + "]";
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDept() {
	return dept;
}
public void setDept(String dept) {
	this.dept = dept;
}
public Employee(String name, String dept) {
	super();
	//this.id = id;
	this.name = name;
	this.dept = dept;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}



}
