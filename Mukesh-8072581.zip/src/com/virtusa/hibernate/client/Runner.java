package com.virtusa.hibernate.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.composite.Course;
import com.virtusa.hibernate.embedded.Address;
import com.virtusa.hibernate.embedded.Employee;
import com.virtusa.hibernate.oneclassmultitable.Author;
import com.virtusa.hibernate.operation.EmployeeOperation;
import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
		
		
Session session=factory.openSession();
Transaction transaction=session.beginTransaction();

//Course course=new Course(1, "program", 100, "mukesh");
//session.save(course);
//transaction.commit();
////////EmployeeOperation empOp=new EmployeeOperation();
//course auth=new course("vivek",52,69,"gupta");
//session.save(auth);
//transaction.commit();
//////empOp.insertEmployee(emp);
//////	//Employee emp1=new Employee("vivek gupta",30000);
//////	//empOp.updateEmployee(emp1,3);
////////	
////		Employee emp=new Employee("mukesh sahu","Software");
////
////		Address address=new Address("chennai","tamilnadu","560076","giri nagar");
////		emp.setAddress(address);
////		session.save(emp);
////		transaction.commit();
//Author a = new Author();
//a.setFirstName("Thorben");
//a.setLastName("Janssen");
//a.setCategory("computer");
//a.setContact("9993200768");
//session.persist(a);
// 
//session.getTransaction().commit();
//session.close();
		
	}

}
