package com.virtusa.hibernate.inheritance;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;
@Entity
@PrimaryKeyJoinColumn(name="ID")  
public class Tester extends Employee{
	private String profile;
	private Date dateOfJoin;
	public Tester(String profile, Date dateOfJoin) {
		super();
		this.profile = profile;
		this.dateOfJoin = dateOfJoin;
	}
	public Tester()
	{
		
	}
}
