package com.virtusa.hibernate.inheritance;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;
@Entity
@PrimaryKeyJoinColumn(name="ID")  
public class Developer extends Employee {
	
	public Developer(String project, int experience) {
		super();
		this.project = project;
		this.experience = experience;
	}

	private String project;
	private int experience;
	
	public Developer()
	{
		
	}
}
