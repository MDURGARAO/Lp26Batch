package com.virtusa.hibernate.composite;

import java.io.Serializable;

public class Course implements Serializable {
	
	private static final long serialVersionUI=1L;
	private int cid;
	private String name;
	private double price;

	private String author_name;
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCid() {
		return cid;
	}
	public String getName() {
		return name;
	}
	public double getPrice() {
		return price;
	}
	
	public String getAuthor_name() {
		return author_name;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	public void setAuthor_name(String author_name) {
		this.author_name = author_name;
	}public Course(int cid, String name, double price,  String author_name) {
		super();
		this.cid = cid;
		this.name = name;
		this.price = price;
		this.author_name = author_name;
	}
	public static long getSerialversionui() {
		return serialVersionUI;
	}
	
	
	

}
