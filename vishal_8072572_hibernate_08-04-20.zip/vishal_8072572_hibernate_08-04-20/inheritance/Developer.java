package com.inheritance;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Developer {
    @Id
	private int developerId;
	private String developerName;
	private String designation;
	public Developer(int developerId, String developerName, String designation) {
		super();
		this.developerId = developerId;
		this.developerName = developerName;
		this.designation = designation;
	}
	public int getDeveloperId() {
		return developerId;
	}
	public void setDeveloperId(int developerId) {
		this.developerId = developerId;
	}
	public String getDeveloperName() {
		return developerName;
	}
	public void setDeveloperName(String developerName) {
		this.developerName = developerName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	@Override
	public String toString() {
		return "Developer [developerId=" + developerId + ", developerName=" + developerName + ", designation="
				+ designation + "]";
	}
	
}
