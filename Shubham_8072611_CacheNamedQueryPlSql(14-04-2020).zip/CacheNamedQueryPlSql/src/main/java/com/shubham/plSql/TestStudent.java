package com.shubham.plSql;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.PropertyProjection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;
import org.hibernate.transform.Transformers;

public class TestStudent {

	public static void main(String []args)
	{

		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		
		
		StoredProcedureQuery sq= session.createStoredProcedureQuery("count_N");
		sq.registerStoredProcedureParameter("s_Name", String.class, ParameterMode.IN);
		sq.registerStoredProcedureParameter("s_Count", Integer.class, ParameterMode.OUT);
		sq.setParameter("s_Name", "Aonu");
		sq.execute();
		 Integer out=(Integer) sq.getOutputParameterValue("s_Count");
		System.out.println(out);
		t.commit();
		session.close();
		
	}
}
