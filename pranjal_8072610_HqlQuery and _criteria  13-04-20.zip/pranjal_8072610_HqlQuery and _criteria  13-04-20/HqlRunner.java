package com.virtusa.hibernate.main;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.virtusa.hibernate.onetoone.Person;
import com.virtusa.hibernate.util.HibernateUtil;

public class HqlRunner {
	public static void main(String[] args) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		//selecting specific column using entity object
		// Query query = session.createQuery("select new Person(personId,name) from Person where name='pranjal'");
		 //order by location desc
//		 List<Person> list = query.list();
//		 for (Person per : list) {
//			System.out.println(per.getPersonId()+" "+per.getName());
//		}
		
		//insert query 
//		Query query = session.createQuery("Insert into Company(companyId,name,location)"+"select companyId,name,location from old_Company");
//		int result = query.executeUpdate();
		
		//update query 		
//		Query query = session.createQuery("update Person set name='mukesh' where personId=7");
//		query.executeUpdate();
		
		
		// update query as Dynamic 	
//		Query query = session.createQuery("update Person set name=? where personId=:perId");
//		query.setParameter(0,"Deepak");
//		query.setParameter("perId",7);
//		query.executeUpdate();
		
		//delete query as statement in jdbc	
//		Query query = session.createQuery("delete from Person where personId=7");
//		query.executeUpdate();
		
		
		//update query as preparedstatement
//		Query query = session.createQuery("delete from Person where PersonId=:pid");
//		query.setParameter("pid", 10);
//		query.executeUpdate();
	
		//Aggregate function 
//		Query query = session.createQuery("select sum(number) from Person");
//		List<Integer> sum = query.list();
//		System.out.println(sum.get(0));
		
		Query query = session.createQuery("select max(number) from Person");
		List<Integer> sum = query.list();
		System.out.println(sum);
		
		session.getTransaction().commit();
		session.close();
			
			
	}
}
