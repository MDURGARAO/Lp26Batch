package com.virtusa.spring.client;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.ObjectError;

import com.virtusa.spring.validate.UserBean;
import com.virtusa.spring.validate.UserValidator;

public class ValidateMain {
@SuppressWarnings("resource")
public static void main(String[] args) {
	ApplicationContext context = new ClassPathXmlApplicationContext("spring-config-core2.xml");
	UserBean userBean = (UserBean)context.getBean(UserBean.class);
	UserValidator userValidator = (UserValidator)context.getBean(UserValidator.class);
	Map<String,String> map = new HashMap<>();
	MapBindingResult errors = new MapBindingResult(map, UserBean.class.getName());
	userValidator.validate(userBean, errors);
	List<ObjectError> list = errors.getAllErrors();
	for(ObjectError obj: list)
		System.out.println(obj.getDefaultMessage());

}
}
