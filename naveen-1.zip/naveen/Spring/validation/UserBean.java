package com.virtusa.spring.validate;

import org.springframework.validation.Validator;

public class UserBean {
	private String email;
	private String password;
	public  void logIn(String email,String password)
	{
		System.out.println("logged in with "+email);
		System.out.println("logged in with "+password);

	}
	
	
	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "User [email=" + email + ", password=" + password + "]";
	}
	public UserBean(String email, String password) {
		this.email = email;
		this.password = password;
	}
	public UserBean() {
	}


		
}
