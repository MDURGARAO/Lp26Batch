package com.virtusa.spring.Annotations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;


@Configuration
@Import(EmployeeConfig.class)
public class PersonConfiguration {

	@Bean
	public PersonBean personBean()
	{
		PersonBean person = new PersonBean();
		person.setFirstName("ramesh");
		person.setLastName("chaitanya");
		person.setMiddleName("DK");
		return person;
	}

	
}
