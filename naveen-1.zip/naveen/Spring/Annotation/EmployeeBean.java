package com.virtusa.spring.Annotations;

public class EmployeeBean implements Person {

	private int id;
	private String department;
	private String email;
	
	@Override
	public void getDetails() {
		System.out.print(this.getId()+" ");
		System.out.println(this.getEmail()+ " ");
		System.out.println(this.getDepartment());
	}

	public EmployeeBean() {
	}

	public EmployeeBean(int id, String department, String email) {
		this.id = id;
		this.department = department;
		this.email = email;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", department=" + department + ", email=" + email + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
