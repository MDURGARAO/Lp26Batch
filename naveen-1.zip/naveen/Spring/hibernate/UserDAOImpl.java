package com.virtusa.spring.hibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.transaction.annotation.Transactional;

public class UserDAOImpl implements UserDAO{

	private SessionFactory sessionFactory;


	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}


	@Override
	public List<User> listUsers() {
		Session session = this.sessionFactory.openSession();
		List<User> userList =  session.createQuery("from User").list();
		return userList;
	}

	@Override
	public void addUser(User user) {
		Session session = this.sessionFactory.openSession();
		Transaction transaction  = session.beginTransaction();
		session.save(user);
		transaction.commit();
		session.close();

	}

	@Override
	public void deleteUser(int id) {
		Session session = this.sessionFactory.openSession();
		Transaction transaction  = session.beginTransaction();
		User user = (User)session.load(User.class, id);
		session.delete(user);
		transaction.commit();
		session.close();S


	}

}

