package com.virtusa.spring.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.hibernate.User;
import com.virtusa.spring.hibernate.UserDAO;
import com.virtusa.spring.hibernate.UserDAOImpl;


public class SpringHibernateMain {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-hibernate-config.xml");
		UserDAO userDAO = (UserDAO) context.getBean(UserDAOImpl.class);
		User user = (User) context.getBean(User.class);
		userDAO.addUser(user);
		userDAO.deleteUser(1);
//		List<User> userList = userDAO.listUsers();
//		for(User u : userList)
//		{
//			System.out.println(u.getId()+" "+u.getUsername()+" "+u.getEmail()+" "+u.getPassword());
//		}



	}
}
