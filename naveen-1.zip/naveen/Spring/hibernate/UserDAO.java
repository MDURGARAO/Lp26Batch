package com.virtusa.spring.hibernate;

import java.util.List;

public interface UserDAO {
	 void addUser(User user);
	 List<User> listUsers();
	 void deleteUser(int id);
}
