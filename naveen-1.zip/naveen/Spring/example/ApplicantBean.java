package com.virtusa.spring.core;

import java.util.List;
import java.util.logging.Logger;

import com.virtusa.spring.casestudy.PersonBean;

public class ApplicantBean extends PersonBean {
	private String message;
	private int noOfMessages;
	private String[] strMessages;
	private List<Integer> numberList;


	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ApplicantBean(String message, int noOfMessages, String[] strMessages, List<Integer> numberList) {
		Logger.getLogger("Hi applicant argument bean");
		this.message = message;
		this.noOfMessages = noOfMessages;
		this.strMessages = strMessages;
		this.numberList = numberList;
		
	}

	@Override
	public String toString() {
		return "WelcomeBean [message=" + message + "]";
	}

	public ApplicantBean() {
		Logger.getLogger("hi applicant bean");
	}


	public int getNoOfMessages() {
		return noOfMessages;
	}

	public void setNoOfMessages(int noOfMessages) {
		this.noOfMessages = noOfMessages;
	}

	public String[] getStrMessages() {
		return strMessages;
	}

	public void setStrMessages(String[] strMessages) {
		this.strMessages = strMessages;
	}

	public List<Integer> getNumberList() {
		return numberList;
	}

	public void setNumberList(List<Integer> numberList) {
		this.numberList = numberList;
	}


}
