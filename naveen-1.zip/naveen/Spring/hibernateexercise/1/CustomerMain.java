package com.virtusa.spring.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.onetoone.Customer;
import com.virtusa.spring.onetoone.CustomerRepository;

public class CustomerMain {
@SuppressWarnings("resource")
public static void main(String args[]) {
		
		Scanner scanner = new Scanner(System.in);

		ApplicationContext context = new ClassPathXmlApplicationContext("spring-hibernate-config-onetoone.xml");

		CustomerRepository customerRepository =  context.getBean(CustomerRepository.class);
		
		Customer customer =  context.getBean(Customer.class);
		

		customerRepository.saveCustomer(customer);
		
//		System.out.println("Enter customer ID");
//		System.out.println(customerRepository.getCustomer(scanner.nextInt()).toString());
//		
//	
//		customerRepository.deleteCustomer(customer);

	}

}
