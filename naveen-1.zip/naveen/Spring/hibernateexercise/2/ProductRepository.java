package com.virtusa.spring.onetomany;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class ProductRepository {
	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void saveProduct(Product product) {
		Session session = sessionFactory.getCurrentSession();
		session.save(product);

	}
	
	@Transactional
	public void updateProduct(Product product) {
		Session session = sessionFactory.getCurrentSession();
		session.update(product);
	}

	@Transactional
	public void deleteProduct(Product product) {
		Session session = sessionFactory.getCurrentSession();
		session.delete(product);
	}
	
	@Transactional
	public Product getProduct(int id) {
		Session session = sessionFactory.getCurrentSession();
		return (Product) session.get(Product.class,id);
	}


}
