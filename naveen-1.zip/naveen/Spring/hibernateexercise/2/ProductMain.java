package com.virtusa.spring.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.onetomany.Product;
import com.virtusa.spring.onetomany.ProductRepository;

public class ProductMain {
@SuppressWarnings("resource")
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	
	ApplicationContext context = new ClassPathXmlApplicationContext("spring-hibernate-config-onetomany.xml");
	
	ProductRepository productRepository =  context.getBean(ProductRepository.class);
	
	Product product1 = (Product) context.getBean("product1");
	
	Product product2 = (Product) context.getBean("product2");
	
	productRepository.saveProduct(product1);
	
	System.out.println("Enter product id");
	System.out.println(productRepository.getProduct(scanner.nextInt()).toString());
	
	productRepository.updateProduct(product1);
	
	System.out.println("Enter product id");
	System.out.println(productRepository.getProduct(scanner.nextInt()).toString());
	
	productRepository.deleteProduct(product2);
	

}
}
