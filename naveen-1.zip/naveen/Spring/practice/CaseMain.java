package com.virtusa.spring.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.casestudy.UserBean;

public class CaseMain {
@SuppressWarnings("resource")
public static void main(String[] args) {
	ApplicationContext context = new ClassPathXmlApplicationContext("spring-core-config2.xml");
	//UserBean userBean = (UserBean)context.getBean(UserBean.class);
	UserBean userBean = context.getBean(UserBean.class);
	System.out.println(userBean.getEmail());
	System.out.println(userBean.getPassword());
	System.out.println(userBean.getOrder());
}
}
