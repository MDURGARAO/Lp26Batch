package com.virtusa.spring;

import java.util.Arrays;
import java.util.List;

import com.virtusa.spring.Person;

public class Applicant extends Person {
	private int noOfMessages;
	private String[] strMessages;
	private List<Integer> numberList;


	public Applicant() {
	}
	
	

	public Applicant(int noOfMessages, String[] strMessages, List<Integer> numberList) {
		this.noOfMessages = noOfMessages;
		this.strMessages = strMessages;
		this.numberList = numberList;
	}
	@Override
	public String toString() {
		return "Applicant [noOfMessages=" + noOfMessages + ", strMessages=" + Arrays.toString(strMessages)
				+ ", numberList=" + numberList + "]";
	}

	public int getNoOfMessages() {
		return noOfMessages;
	}

	public void setNoOfMessages(int noOfMessages) {
		this.noOfMessages = noOfMessages;
	}

	public String[] getStrMessages() {
		return strMessages;
	}

	public void setStrMessages(String[] strMessages) {
		this.strMessages = strMessages;
	}

	public List<Integer> getNumberList() {
		return numberList;
	}

	public void setNumberList(List<Integer> numberList) {
		this.numberList = numberList;
	}


}
