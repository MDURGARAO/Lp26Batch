package com.virtusa.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class PersonConfiguration {

	
	@Bean
	public Person person()
	{
		
		Address address = new Address("5-4-123","banglore","India",600025);
				return new Person("ramesh","chaitanya","DK",address);
	}
	

	
	
}
