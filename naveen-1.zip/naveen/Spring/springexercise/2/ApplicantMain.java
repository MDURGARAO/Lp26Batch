package com.virtusa.spring.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.virtusa.spring.Applicant;

public class ApplicantMain {
@SuppressWarnings("resource")
public static void main(String[] args) {
	ApplicationContext context = new ClassPathXmlApplicationContext("spring-core-config2.xml");
	Applicant applicant = (Applicant)context.getBean(Applicant.class);
	System.out.println(applicant);
	System.out.println(applicant.getNoOfMessages());
	System.out.println(applicant.getNumberList());
	System.out.println(applicant.getStrMessages());
	System.out.println(applicant.getFirstName());
	System.out.println(applicant.getLastName());
	System.out.println(applicant.getMiddleName());
	System.out.println(applicant.getAddress());
}
}
