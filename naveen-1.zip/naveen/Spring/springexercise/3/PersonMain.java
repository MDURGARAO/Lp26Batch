package com.virtusa.spring.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.virtusa.spring.Person;
import com.virtusa.spring.PersonConfig;


public class PersonMain {
public static void main(String[] args) {
	ApplicationContext context = new AnnotationConfigApplicationContext(PersonConfig.class);
	Person person = (Person)context.getBean(Person.class);
	System.out.println(person.getFirstName());
	System.out.println(person.getLastName());
	System.out.println(person.getMiddleName());
	System.out.println(person.getAddress());
}
}
