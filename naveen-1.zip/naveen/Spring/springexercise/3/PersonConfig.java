package com.virtusa.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class PersonConfig {

	
	@Bean
	public Person person()
	{
		Person person = new Person();
		person.setFirstName("ramesh");
		person.setLastName("chaitanya");
		person.setMiddleName("DK");
		Address address = new Address();
		address.setCity("Hyd");
		address.setCountry("india");
		address.setPincode(517658);
		address.setDoorNo("1-3-456");
		person.setAddress(address);
		return person;
	}
	

	
	
}
