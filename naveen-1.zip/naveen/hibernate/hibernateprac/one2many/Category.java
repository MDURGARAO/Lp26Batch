package com.virtusa.hibernate.one2many;

import java.util.Set;

import javax.persistence.*;
@Entity
public class Category {
	@Id
	@Column(name = "CATEGORY_ID")
	@GeneratedValue
	private long id;
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	private String name;
	@OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
	private Set<Product> products;

	public Category() {
	}

	public Category(long id ,String name) 
	{
		this.setName(name);
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
