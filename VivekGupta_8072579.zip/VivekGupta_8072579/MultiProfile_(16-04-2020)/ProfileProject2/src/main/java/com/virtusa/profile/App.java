package com.virtusa.profile;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
public class App
{
public static void main(String[] args) {

        App app = new App();
        Properties prop = app.loadPropertiesFile("config.properties");
      for (Map.Entry<Object,Object> entry : prop.entrySet())  
            System.out.println("Key = " + entry.getKey() + 
                             ", Value = " + entry.getValue()); 

    }

    public Properties loadPropertiesFile(String filePath) {

        Properties prop = new Properties();

        try (InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream(filePath)) {
            prop.load(resourceAsStream);
        } catch (IOException e) {
            System.err.println("Unable to load properties file : " + filePath);
        }

        return prop;

    }
}