package com.virtusa.vivek;
import com.virtusa.vivek.Calculator;
public class User
{
public static void main(String[] args){
Calculator calculator=new Calculator();
System.out.println(calculator.sum(3,6));
System.out.println(calculator.multiply(3,6));
}
}