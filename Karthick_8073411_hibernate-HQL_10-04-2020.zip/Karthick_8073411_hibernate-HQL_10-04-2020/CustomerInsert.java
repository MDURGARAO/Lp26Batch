package com.virtusa.hibernate;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.Entity.Customer;

public class CustomerInsert {
	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory = configuration.buildSessionFactory();
		Session session = buildSessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery("Insert into Customer(cusId, bill, name, isNewCus, address) select i.cusId, "
				+ "i.bill, i.name, i.isNewCus, i.address  from Customer2 i where i.cusId= 1006");
		query.executeUpdate();
		transaction.commit();
		session.close();
	}
}
