package com.virtusa.hibernate;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.virtusa.Entity.Customer;

public class CustomerMain4 {
	public static void main(String[] args) {
//		Customer cus = new Customer(1003, 3000, "Rahul", false, new Address(307, "Anjaneyar Street","Chennai"));
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory = configuration.buildSessionFactory();
		Session session = buildSessionFactory.openSession();
//		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery("from Customer where name = :nm and cusId = :id and address.doorNo = :dn");
		query.setInteger("id", new Scanner(System.in).nextInt());
		query.setString("nm", new Scanner(System.in).next());
		query.setInteger("dn", new Scanner(System.in).nextInt());
		List<Customer> list = query.list();
		list.forEach(System.out::println);
//		transaction.commit();
		session.close();
	}
}
