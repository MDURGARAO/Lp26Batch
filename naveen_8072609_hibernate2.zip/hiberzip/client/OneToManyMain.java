package com.virtusa.hibernate.client;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.onetomany.Category;
import com.virtusa.hibernate.onetomany.Product;

public class OneToManyMain {
public static void main(String[] args) {
	Product product1 = new Product();
	Product product2 = new Product();
	Product product3 = new Product();
	product1.setName("hp laptop");
	product1.setPrice(45000);
	product2.setName("sony headphones");
	product2.setPrice(2500);
	product3.setName("sony playstaion");
	product3.setPrice(27000);
	Set<Product> products = new HashSet<>();
	products.add(product3);
	products.add(product2);
	products.add(product1);
	Category category = new Category();
	category.setName("electronics");
	category.setProducts(products);
	
	Configuration configuration = new Configuration();
	configuration.configure("hibernate.cfg.xml");
	SessionFactory sessionFactory = configuration.buildSessionFactory();
	Session session = sessionFactory.openSession();
	Transaction transaction = session.beginTransaction();
	session.save(category);
	
	transaction.commit();
	session.close();
}
}
