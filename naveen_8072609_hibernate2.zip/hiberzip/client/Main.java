package com.virtusa.hibernate.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.entity.Address;
import com.virtusa.hibernate.entity.User;

public class Main {
public static void main(String[] args) {
	Address address = new Address();
	User user= new User();
	user.setFirstName("venky");
	user.setLastName("samudrala");
	address.setCity("tpty");
	address.setCountry("india");
	address.setPincode(500027);
	address.setState("AP");
	user.setAddress(address);
	
	Configuration configuration = new Configuration();
	configuration.configure("hibernate.cfg.xml");
	SessionFactory sessionFactory = configuration.buildSessionFactory();
	Session session = sessionFactory.openSession();
	Transaction transaction = session.beginTransaction();
	session.save(user);
	
	transaction.commit();
	session.close();
	
}
}
