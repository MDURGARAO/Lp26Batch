package com.virtusa.hibernate.client;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.manytomany.Employee;
import com.virtusa.hibernate.manytomany.Project;


public class MainyToManyMain {
	public static void main(String[] args) {
		Employee employee1 = new Employee();
		Employee employee2 = new Employee();
		Employee employee3 = new Employee();
		Employee employee4 = new Employee();
		Employee employee5 = new Employee();
		Project project = new Project();
		project.setName("telecom");
		
		Project project1 = new Project();
		project1.setName("citi bank");
		

		employee1.setName("chandran");
		employee1.setEmailId("chandu@gmail.com");
		employee2.setName("Leela Prasad");
		employee2.setEmailId("leela2gmail.com");
		employee3.setEmailId("Marutheeswar@gmail.com");
		employee3.setName("Marutheeswar");
		employee1.setName("venky");
		employee1.setEmailId("venky@gmail.com");
		employee1.setName("balaji");
		employee1.setEmailId("balaji@gmail.com");
		Set<Employee> employees = new HashSet<Employee>();
		employees.add(employee3);
		employees.add(employee2);
		employees.add(employee1);
		Set<Employee> employees1 = new HashSet<Employee>();
		employees1.add(employee4);
		employees1.add(employee5);
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(project1);
		session.save(project);
		
		
		transaction.commit();
		session.close();
	}

}
