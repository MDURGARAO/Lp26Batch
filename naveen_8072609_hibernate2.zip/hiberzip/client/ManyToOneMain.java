package com.virtusa.hibernate.client;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.manytoone.Professor;
import com.virtusa.hibernate.manytoone.University;


public class ManyToOneMain {
	
	public static void main(String[] args) {
		Professor professor1 = new Professor();
		Professor professor2 = new Professor();
		Professor professor3 = new Professor();
		University university = new University();
		university.setCountry("India");
		university.setName("ANDHRA UNIVERSITY");
		
		University university1 = new University();
		university1.setCountry("India");
		university1.setName("AMBEDHKAR UNIVERSITY");
		

		professor1.setFirstName("chandran");
		professor1.setLastName("ravi");
		professor1.setDepartment("Commerce");
		professor2.setFirstName("Leela Prasad");
		professor2.setLastName("yachamaneni");
		professor2.setDepartment("Economics");
		professor3.setFirstName("Marutheeswar");
		professor3.setLastName("Galla");
		professor3.setDepartment("Engineering");
		professor1.setUniversity(university);
		professor2.setUniversity(university1);
		professor3.setUniversity(university1);
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(professor1);
		session.save(professor2);
		session.save(professor3);

		transaction.commit();
		session.close();
	}

}
