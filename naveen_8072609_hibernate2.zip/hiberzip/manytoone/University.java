package com.virtusa.hibernate.manytoone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class University {
	@Id
    @GeneratedValue
    @Column(name = "unversity_id")
    private long id;
 
    private String name;
 
    private String country;
 
    public University() {
 
    }

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
