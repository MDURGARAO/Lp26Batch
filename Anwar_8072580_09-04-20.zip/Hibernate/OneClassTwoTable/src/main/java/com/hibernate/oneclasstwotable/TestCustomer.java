package com.hibernate.oneclasstwotable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestCustomer {

	public static void main(String[] args) {
		Customer Aonu=new Customer();
		Aonu.setCustomerId(11);
		Aonu.setCustomerName("Dubba");
		Aonu.setCustomerAddress("Chennai");
		Aonu.setCreditScore(7500);
		Aonu.setRewardPoints(1001);
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		session.save(Aonu);
		t.commit();
		session.close();
	}

}
