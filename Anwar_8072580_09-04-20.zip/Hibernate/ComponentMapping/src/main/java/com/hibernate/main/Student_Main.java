package com.hibernate.main;





import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.Address;
import com.hibernate.Student;

public class Student_Main {
	
    	public static void main(String[] args) {
    		
    		
    		Address ad= new Address();
    	    ad.setHouseno(786);
    	    ad.setStreet("Shiv Colony");
    	    ad.setCity("Ajmer");

		Student std = new Student();
		std.setId(11);
		std.setStdName("Anwar");
		std.setMarks(70);
		std.setAddress(ad);
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		session.save(std);
		t.commit();
		session.close();
		

	}

}
