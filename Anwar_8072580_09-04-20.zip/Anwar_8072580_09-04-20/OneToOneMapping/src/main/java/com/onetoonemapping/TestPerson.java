package com.onetoonemapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestPerson {

	public static void main(String[] args) {
		
		
		PersonDetail persondetail=new PersonDetail();
		persondetail.setPersondetailId(11);
		persondetail.setZipCode("305204");
		persondetail.setJob("engineer");
		persondetail.setIncome(20000.14);
		
		Person alex=new Person();
		alex.setPersonId(10);
		alex.setPersonNmae("Aonu");
		alex.setPersondetail(persondetail);
	
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		session.save(alex);
		session.save(persondetail);
//		Person pd=(Person)session.get(Person.class, 0);
//		System.out.println(pd);
		t.commit();
		session.close();
		
		
				
		
		
		
	}

}
