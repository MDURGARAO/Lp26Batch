package com.virtusa.hibernate.many2many.mapping;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Empoyee")
public class Employee {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="EmpId")
	private int employeeId;
	@Column(name="EmpName")
	private String name;
	@Column(name="Department")
	private String department;
	@Column(name="EmpSalary")
	private int salary;
	@Column(name="joiningDate")
	private Date joiningDate;
	
	@ManyToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinTable(name = "EMP_ASSIGNMENTS",
	        joinColumns = { @JoinColumn(name = "EmpId") },
	        inverseJoinColumns = { @JoinColumn(name = "projectId") })
	private List<Project> empAssignmentList;

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", department=" + department + ", salary="
				+ salary + ", joiningDate=" + joiningDate + ", empAssignmentList=" + empAssignmentList + "]";
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(String name, String department, int salary, Date joiningDate) {
		super();
		//this.employeeId = employeeId;
		this.name = name;
		this.department = department;
		this.salary = salary;
		this.joiningDate = joiningDate;
		//this.empAssignmentList = empAssignmentList;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}

	public List<Project> getEmpAssignmentList() {
		return empAssignmentList;
	}

	public void setEmpAssignmentList(List<Project> empAssignmentList) {
		this.empAssignmentList = empAssignmentList;
	}

	
}
