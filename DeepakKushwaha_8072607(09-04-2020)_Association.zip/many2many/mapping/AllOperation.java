package com.virtusa.hibernate.many2many.mapping;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AllOperation {
	Employee employee = new Employee();
	public void insertData(Employee employee) {
		Configuration configure = new Configuration().configure();
		SessionFactory factory = configure.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(employee);
		System.out.println("Success");
		transaction.commit();
		session.close();
		factory.close();
	}

	public void deleteData(int key) {
		Configuration configure = new Configuration().configure();
		SessionFactory factory = configure.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			employee = (Employee) session.get(Employee.class, key);
			session.delete(employee);
			transaction.commit();
		}catch(Exception e) {
			System.out.println("Invalid Id");
		}finally {
			session.close();
		}
	}
	
	public void updateData(int employeeId) {
		Configuration configure = new Configuration().configure();
		SessionFactory factory = configure.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			employee = (Employee) session.get(Employee.class, employeeId);
			employee.setDepartment("Management");
			employee.setName("Tarun");
			Collection<Project> project = employee.getEmpAssignmentList();
			Iterator<Project> iterator = project.iterator();
			while(iterator.hasNext()) {
				Project next = iterator.next();
				next.setOwner("TCS");
				next.setName("Librarymanagement");
			}
			employee.setSalary(23000);
			session.persist(employee);
			transaction.commit();
		}catch(Exception e) {
			System.out.println("Enter valid Id");
		}
		finally {
			session.close();
		}
	}
	
	public List<Employee> showData() {
		Configuration configure = new Configuration().configure();
		SessionFactory factory = configure.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery("from Employee");
		List<Employee> employeeData = query.list();
		return employeeData;

	}
}
