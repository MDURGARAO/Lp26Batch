package com.virtusa.hibernate.many2many.mapping;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Project")
public class Project {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="projectId")
	private int projectId;
	@Column(name="ProjectName")
	private String name;
	@Column(name="ProjectOwner")
	private String owner;
    @ManyToMany(mappedBy = "empAssignmentList")
    private List<Employee> employees;
    
	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", name=" + name + ", owner=" + owner
				+ "]";
	}

	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Project(String name, String owner) {
		super();
		//this.projectId = projectId;
		this.name = name;
		this.owner = owner;
		//this.employees = employees;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
}
