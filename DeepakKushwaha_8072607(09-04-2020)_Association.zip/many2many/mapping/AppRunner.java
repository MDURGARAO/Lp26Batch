package com.virtusa.hibernate.many2many.mapping;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.one2many.mapping.Student;

public class AppRunner {

	public static void main(String[] args) {
		AllOperation operation = new AllOperation();
		
//		Configuration config = new Configuration().configure();
//		SessionFactory factory = config.buildSessionFactory();
//		Session session = factory.openSession();
//		Transaction transaction = session.beginTransaction();
//		
//		Project project1 = new Project();
//		project1.setName("Lms");
//		project1.setOwner("virtusa");
//		
//		Project project2 = new Project();
//		project2.setName("lpmanagement");
//		project2.setOwner("virtusa");
//		
//		List<Project> subs = new ArrayList<Project>();
//        subs.add(project1);
//        subs.add(project2);
//        
//        Employee employee1 = new Employee();
//        employee1.setName("Deepak");
//        employee1.setSalary(20000);
//        employee1.setDepartment("IT");
//        employee1.setJoiningDate(new Date(29/01/2020));
//        
//        Employee employee2 = new Employee();
//        employee2.setName("Arun");
//        employee2.setSalary(20000);
//        employee2.setDepartment("IT");
//        employee2.setJoiningDate(new Date(29/01/2020));
//
//        List<Employee> employee = new ArrayList<Employee>();
//        employee.add(employee1);
//        employee.add(employee2);
//		
//        employee1.setEmpAssignmentList(subs);
//        employee2.setEmpAssignmentList(subs);
        
//        operation.insertData(employee1);
//        operation.insertData(employee2);
		List<Employee> employeeList = operation.showData();
		System.out.println("stu size: "+employeeList.size());
        System.out.println("---------------------------");
        
        for (int i = 0; i < employeeList.size()-1; i++) {
			System.out.println(employeeList.get(i));
		}

        
//        session.save(employee1);
//        session.save(employee2);
//        transaction.commit();
//        session.close();
//         
	}

}
