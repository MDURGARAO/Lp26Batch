package com.virtusa.hibernate.many2one.mapping;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AllOperation {
	Vehicle vehicle = new Vehicle();
	public void insertData(ArrayList<Vehicle> vehicleList) {
		Configuration configure = new Configuration().configure();
		SessionFactory factory = configure.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		for (Vehicle vehicle1 : vehicleList) {
			session.save(vehicle1);
		}
		System.out.println("Success");
		transaction.commit();
		session.close();
		factory.close();
	}

	public void deleteData(int key) {
		Configuration configure = new Configuration().configure();
		SessionFactory factory = configure.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			vehicle = (Vehicle) session.get(Vehicle.class, key);
			session.delete(vehicle);
			transaction.commit();
		}catch(Exception e) {
			System.out.println("Invalid Id");
		}finally {
			session.close();
		}
	}
	
	public void updateData(int vehicleId) {
		Configuration configure = new Configuration().configure();
		SessionFactory factory = configure.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			vehicle = (Vehicle) session.get(Vehicle.class, vehicleId);
			vehicle.setVehicleName("ford");
			Owner owner = vehicle.getUser();
			owner.setName("Mukesh");
			vehicle.setUser(owner);
			transaction.commit();
		}catch(Exception e) {
			System.out.println("Enter valid Id");
		}
		finally {
			session.close();
		}
	}
	
	public List<Vehicle> showData() {
		Configuration configure = new Configuration().configure();
		SessionFactory factory = configure.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery("from Vehicle");
		List<Vehicle> vehicleData = query.list();
		return vehicleData;

	}

}
