package com.virtusa.hibernate.many2one.mapping;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Vehicle")
public class Vehicle {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="VehicleId")
	private int id;
	
	@Column(name="VehicleName")
	private String vehicleName;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name ="OwnerId")
	private Owner user;

	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Vehicle(int id, String vehicleName, Owner user) {
		super();
		this.id = id;
		this.vehicleName = vehicleName;
		this.user = user;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public Owner getUser() {
		return user;
	}

	public void setUser(Owner user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Vehicle [id=" + id + ", vehicleName=" + vehicleName + ", user=" + user + "]";
	}
	
	

}
