package com.virtusa.hibernate.many2one.mapping;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AppRunner {

	public static void main(String[] args) {
		AllOperation operation = new AllOperation();

		Owner owner = new Owner();
		owner.setName("Jatin");
		Vehicle vehicle = new Vehicle();
		Vehicle vehicle1= new Vehicle();
		vehicle.setVehicleName("Jaguar");
		vehicle.setUser(owner);
		vehicle1.setVehicleName("BMW");
		vehicle1.setUser(owner);
		ArrayList<Vehicle> vehicleList = new ArrayList<Vehicle>();
		vehicleList.add(vehicle);
		vehicleList.add(vehicle1);
//		Configuration configure = new Configuration().configure();
//		SessionFactory factory = configure.buildSessionFactory();
//		Session session = factory.openSession();
//		Transaction transaction = session.beginTransaction();
//		session.save(vehicle);
//		session.save(vehicle1);
//		session.save(owner);
//		System.out.println("Success");
//		transaction.commit();
//		session.close();
//		factory.close();
//		operation.insertData(vehicle);
		operation.insertData(vehicleList);
	}
}
