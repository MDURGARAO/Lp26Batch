package com.virtusa.hibernate.one2many.mapping;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class AppMain {
	
	

	public static void main(String[] args) {
		
		AllOpertaion operation = new AllOpertaion();
//		Configuration config = new Configuration().configure();
//		SessionFactory factory = config.buildSessionFactory();
//		Session session = factory.openSession();
//		Transaction transaction = session.beginTransaction();
	

	/*	Student studentObj = new Student("arun", 1234567890L);
		session.save(studentObj);
		MarksDetail marksObj1 = new MarksDetail("English", 100, 90,  "Pass");  
        marksObj1.setStudent(studentObj);
        session.save(marksObj1);
        
        MarksDetail marksObj2 = new MarksDetail("Maths", 100, 99,  "Pass");  
        marksObj2.setStudent(studentObj);
        session.save(marksObj2);
        */
		
		
//		MarksDetail marksObj1 = new MarksDetail("English", 100, 80,  "Pass");
//		MarksDetail marksObj2 = new MarksDetail("Science", 100, 85,  "Pass"); 
//		List<MarksDetail> marksOfFirstStudent = new ArrayList<MarksDetail>();
//		marksOfFirstStudent.add(marksObj1);
//		marksOfFirstStudent.add(marksObj2);
//		
//		Student studentObj = new Student("Suresh", 7872345163L,marksOfFirstStudent);
//		marksObj1.setStudent(studentObj);
//		marksObj2.setStudent(studentObj);
//		operation.insertData(studentObj);
		
	//	 operation.showData();
		
		List<Student> studentList = operation.showData();
		System.out.println("stu size: "+studentList.size());
        System.out.println("---------------------------");
        
        for (int i = 0; i < studentList.size()-1; i++) {
			System.out.println(studentList.get(i));
		}
        
        
  	 /* for (Student student : studentList) {
  		  System.out.println("Student Details : " + student);
//            System.out.println("Student Marks Details: "
//                    + student.getMarksDetails());
  	  }*/
		
		
	
//		Student student = (Student) session.get(Student.class, 1);
//		session.delete(student);

		
//        System.out.println("success");
//		transaction.commit();
//		session.close();
//		factory.close();

	}

}
