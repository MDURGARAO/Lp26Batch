package com.virtusa.hibernate.one2many.mapping;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.many2many.mapping.Employee;
import com.virtusa.hibernate.many2many.mapping.Project;

public class AllOpertaion {
	Student student = new Student();
	public void insertData(Student student) {
		Configuration configure = new Configuration().configure();
		SessionFactory factory = configure.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(student);
		System.out.println("Success");
		transaction.commit();
		session.close();
		factory.close();
	}

	public void deleteData(int key) {
		Configuration configure = new Configuration().configure();
		SessionFactory factory = configure.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			student = (Student) session.get(Student.class, key);
			session.delete(student);
			transaction.commit();
		}catch(Exception e) {
			System.out.println("Invalid Id");
		}finally {
			session.close();
			factory.close();
		}
	}
	
	public void updateData(int studentId) {
		Configuration configure = new Configuration().configure();
		SessionFactory factory = configure.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			student = (Student) session.get(Student.class, studentId);
			student.setName("Tarun");
			Collection<MarksDetail> marks = student.getMarksDetails();
			Iterator<MarksDetail> iterator = marks.iterator();
			while(iterator.hasNext()) {
				MarksDetail next = iterator.next();
				next.setObtainedMarks(78);
				next.setSubject("Maths");
			}
			student.setMobile(6453287123L);
			session.persist(student);
			transaction.commit();
		}catch(Exception e) {
			System.out.println("Enter valid Id");
		}
		finally {
			session.close();
		}
	}

	public List<Student> showData() {
		Configuration configure = new Configuration().configure();
		SessionFactory factory = configure.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery("from Student");
		List<Student> studentData = query.list();
		return studentData;

	}
}
