package com.virtusa.hibernate.one2many.mapping;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Marks")
public class MarksDetail {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int testId;
	
	@Column(name="subject")
	private String subject;
	
	@Column(name="MaxMarks")
	private int maximumMarks;
	
	@Column(name="ObtainedMarks")
	private int obtainedMarks;
	
	@Column(name = "result")
    private String result;
 
    @ManyToOne
    @JoinColumn(name = "studentId")
    private Student student;

	public MarksDetail() {
	}

/*	public MarksDetail(String subject, int maximumMarks, int obtainedMarks, String result) {
		super();
		//this.testId = testId;
		this.subject = subject;
		this.maximumMarks = maximumMarks;
		this.obtainedMarks = obtainedMarks;
		this.result = result;
		//this.student = student;
	}
	
	

	public MarksDetail(int testId, String subject, int maximumMarks, int obtainedMarks, String result,
			Student student) {
		super();
		this.testId = testId;
		this.subject = subject;
		this.maximumMarks = maximumMarks;
		this.obtainedMarks = obtainedMarks;
		this.result = result;
		this.student = student;
	}
*/
	public int getTestId() {
		return testId;
	}

	public void setTestId(int testId) {
		this.testId = testId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public int getMaximumMarks() {
		return maximumMarks;
	}

	public void setMaximumMarks(int maximumMarks) {
		this.maximumMarks = maximumMarks;
	}

	public int getObtainedMarks() {
		return obtainedMarks;
	}

	public void setObtainedMarks(int obtainedMarks) {
		this.obtainedMarks = obtainedMarks;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public String toString() {
		return "MarksDetail [testId=" + testId + ", subject=" + subject + ", maximumMarks=" + maximumMarks
				+ ", obtainedMarks=" + obtainedMarks + ", result=" + result + "]";
	}

	

}
