package com.virtusa.hibernate.one2many.mapping;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="studentId")
	private int id;
	
	@Column(name="StudentName")
	private String name;
	
	@Column(name="mobile")
	private long mobile;
	
	@OneToMany(cascade=CascadeType.ALL,mappedBy = "student")
	private List<MarksDetail> marksDetails;//@JoinColumn(name = "studentId")

	public Student() {
	}

/*	
	public Student(String name, long mobile, List<MarksDetail> marksDetails) {
		super();
		//this.id = id;
		this.name = name;
		this.mobile = mobile;
		this.marksDetails = marksDetails;
	}
	
	public Student(String name, long mobile) {
		super();
		//this.id = id;
		this.name = name;
		this.mobile = mobile;
		//this.marksDetails = marksDetails;
	}
*/

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public List getMarksDetails() {
		return marksDetails;
	}

	public void setMarksDetails(List marksDetails) {
		this.marksDetails = marksDetails;
	}


	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", mobile=" + mobile + ", marksDetails=" + marksDetails + "]";
	}
	
	
}
