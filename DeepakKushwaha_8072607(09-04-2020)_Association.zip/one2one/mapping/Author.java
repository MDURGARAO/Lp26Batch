package com.virtusa.hibernate.one2one.mapping;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="author")
public class Author {
 
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="AuthorId")
	private int id;
	@Column(name="AuthorName")
	private String name;
	
	public Author(String name, Book book) {
		super();
		this.name = name;
		this.book = book;
	}
	@OneToOne(cascade=CascadeType.ALL, mappedBy="author")
	private Book book;
	
	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Author(String name) {
		super();
		//this.id = id;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	
}
