package com.virtusa.hibernate.one2one.mapping;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.entity.Student;

public class AppRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Configuration config = new Configuration().configure();
		SessionFactory factory = config.buildSessionFactory();
		Session session = factory.openSession();
		Author author = new Author("abc");
		Book book = new Book("C++",new Date(),author); 
		Transaction transaction = session.beginTransaction();
		//session.save(book);
		//session.save(author);
		Author author1 = (Author) session.get(Author.class, 2);
//		Book book1 = (Book) session.get(Book.class, 1L);
//		session.delete(book1);
		session.delete(author1);
		System.out.println("success");
		transaction.commit();
		session.close();
		factory.close();
	}

}
