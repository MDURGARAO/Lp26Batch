package com.virtusa.hibernate.one2one.mapping;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Cascade;

@Entity
public class Book {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="BookId")
	private long id;
	
	@Column(name="BookTitle")
	private String title;
	
	@Column(name="PublishDate")
	private Date publishDate;
	
	@JoinColumn(name="AuthorId")
	@OneToOne(cascade= CascadeType.ALL)
	private Author author;

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Book( String title, Date publishDate, Author author) {
		super();
		//this.id = id;
		this.title = title;
		this.publishDate = publishDate;
		this.author = author;
	}
	
}
