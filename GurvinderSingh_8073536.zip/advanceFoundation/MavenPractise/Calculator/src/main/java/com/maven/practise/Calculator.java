package com.maven.practise;

 
public class Calculator
{

	public static int sub(int a, int b){
	if(a>b){
		return a-b;
	}
	else{
	return b-a;
	}
   
}
}