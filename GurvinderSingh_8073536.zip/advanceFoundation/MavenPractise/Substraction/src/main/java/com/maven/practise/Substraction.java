package com.maven.practise;


public class Substraction
{
    public static void main( String[] args )
    {
      
        System.out.println(Calculator.sub(40,20));

    }
}
