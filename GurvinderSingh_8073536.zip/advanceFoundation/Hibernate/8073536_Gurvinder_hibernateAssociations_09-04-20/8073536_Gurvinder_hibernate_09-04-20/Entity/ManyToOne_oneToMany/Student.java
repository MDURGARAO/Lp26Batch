package com.hibernate.oneToMany;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Student {

	@Id @GeneratedValue
	private int StudntID;
	private String StudntName;
	@ManyToOne
	@JoinColumn(name ="universityId")
	private University university;
	public int getStudntID() {
		return StudntID;
	}
	public void setStudntID(int studntID) {
		StudntID = studntID;
	}
	public String getStudntName() {
		return StudntName;
	}
	public void setStudntName(String studntName) {
		StudntName = studntName;
	}
	public University getUniversity() {
		return university;
	}
	public void setUniversity(University university) {
		this.university = university;
	}

}
