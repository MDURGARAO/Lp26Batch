package com.hibernate.ManyToMany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Representative {
	
	
	@Id @GeneratedValue
	private int representativeId;
	private String representativeName;
	
	
	
	@ManyToMany(mappedBy = "representative",cascade = CascadeType.ALL)
	@JoinTable(name = "JoinedTable",
	joinColumns = {@JoinColumn(name="representativeId")},
	inverseJoinColumns = {@JoinColumn(name="eventId")})
	private List<Event> event = new ArrayList<Event>();
	
	public int getRepresentativeId() {
		return representativeId;
	}
	public void setRepresentativeId(int representativeId) {
		this.representativeId = representativeId;
	}
	public String getRepresentativeName() {
		return representativeName;
	}
	public void setRepresentativeName(String representativeName) {
		this.representativeName = representativeName;
	}
	public List<Event> getEvent() {
		return event;
	}
	public void setEvent(List<Event> event) {
		this.event = event;
	}

	
	
}
