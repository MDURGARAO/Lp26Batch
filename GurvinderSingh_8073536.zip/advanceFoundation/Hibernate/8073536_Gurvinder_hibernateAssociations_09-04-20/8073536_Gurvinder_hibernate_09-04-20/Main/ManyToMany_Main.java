package com.virtusa.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.ManyToMany.Event;
import com.hibernate.ManyToMany.Representative;

public class ManyToMany_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Representative representative1=new Representative();
		representative1.setRepresentativeName("Gurvinder");
		
		Representative representative2=new Representative();
		representative2.setRepresentativeName("Kanhu");
		
		Representative representative3=new Representative();
		representative3.setRepresentativeName("Shubham");
		
		Event event1=new Event();
		event1.setEventName("java");
		
		Event event2=new Event();
		event2.setEventName("Hibernate");
		
		Event event3=new Event();
		event3.setEventName("Spring");
		
		event1.getRepresentative().add(representative1);
		event1.getRepresentative().add(representative2);
		event1.getRepresentative().add(representative3);
		event2.getRepresentative().add(representative1);
		event2.getRepresentative().add(representative3);
		event3.getRepresentative().add(representative2);
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory session = configuration.buildSessionFactory();
		Session openSession = session.openSession();
		Transaction beginTransaction = openSession.beginTransaction();
		openSession.save(event1);
		openSession.save(event2);
		openSession.save(event3);
		openSession.save(representative1);
		openSession.save(representative2);
		openSession.save(representative3);
		beginTransaction.commit();
		openSession.close();
	}

}
