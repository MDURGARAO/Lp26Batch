package com.virtusa.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.oneToMany.Student;
import com.hibernate.oneToMany.University;

public class Student_Main {
	
	public static void main(String[] args) {
		
		University university = new University();
		university.setUniversityName("LPU University");
		university.setAddress("Punjab");
		
		Student std1 = new Student();
		std1.setStudntName("Gurvinder");
		
		Student std2 = new Student();
		std2.setStudntName("Tarandeep");
		
	
		std1.setUniversity(university);
		std2.setUniversity(university);
	
	
	Configuration configuration = new Configuration();
	configuration.configure("hibernate.cfg.xml");
	SessionFactory session = configuration.buildSessionFactory();
	Session openSession = session.openSession();
	Transaction beginTransaction = openSession.beginTransaction();
	openSession.save(university);
	openSession.save(std1);
	openSession.save(std2);
	beginTransaction.commit();
	openSession.close();

}
}
