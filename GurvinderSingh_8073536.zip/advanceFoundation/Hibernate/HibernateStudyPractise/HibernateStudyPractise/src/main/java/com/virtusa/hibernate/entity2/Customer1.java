package com.virtusa.hibernate.entity2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
//import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table (name="Customer1")
@SecondaryTable(name = "CustomerDetails1")
public class Customer1 {
	
	@Id @GeneratedValue
	private int CustId;
	private String CustName;
	
	@Column(table = "CustomerDetails1")
	private String CustAddress;
	@Column(table = "CustomerDetails1")
	private int CustPhno; 
	@Column(table = "CustomerDetails1")
	private int CreditScore;

	//@Column (table = "CustomerDetails1")
	public int getCustPhno() {
		return CustPhno;
	}

	
	public void setCustPhno(int custPhno) {
		CustPhno = custPhno;
	}
	public int getCustId() {
		return CustId;
	}
	
	
	public void setCustId(int custId) {
		CustId = custId;
	}
//	@Column (table = "Customer1")
	public String getCustName() {
		return CustName;
	}
	public void setCustName(String custName) {
		CustName = custName;
	}
	
//	@Column (table = "CustomerDetails1")
	public String getCustAddress() {
		return CustAddress;
	}
	public void setCustAddress(String custAddress) {
		CustAddress = custAddress;
	}
	
//	@Column (table = "CustomerDetails1")
	public int getCreditScore() {
		return CreditScore;
	}
	public void setCreditScore(int creditScore) {
		CreditScore = creditScore;
	}
	
}
