package com.virtusa.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entity1.*;
import com.virtusa.entity1.CustomerAddress;

public class CustomerMain {

	public static void main(String[] args) {

		CustomerAddress addr = new CustomerAddress();
		addr.setHno(831);
		addr.setCityName("Hyderabad");
		addr.setStateName("Telangana");
		
		
		Customer add = new Customer();
		add.setCust_id(1);
		add.setCustName("Gurvinder");
		add.setPayment("online");
		add.setPhnNo(123456789);
		add.setAddress(addr);
		
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory session = configuration.buildSessionFactory();
		Session openSession = session.openSession();
		Transaction beginTransaction = openSession.beginTransaction();
		openSession.persist(add);
		beginTransaction.commit();
		openSession.close();
		
	}

}
