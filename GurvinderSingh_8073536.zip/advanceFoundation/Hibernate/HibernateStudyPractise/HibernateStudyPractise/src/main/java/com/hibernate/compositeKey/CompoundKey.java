package com.hibernate.compositeKey;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CompoundKey implements Serializable{
	
	
	
	public CompoundKey(int userId, int accountId) {
		super();
		UserId = userId;
		AccountId = accountId;
	}
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public int getAccountId() {
		return AccountId;
	}
	public void setAccountId(int accountId) {
		AccountId = accountId;
	}
	private int UserId;
	private int AccountId;

}
