package com.virtusa.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.inheritance.Project;
import com.virtusa.inheritance.Module;
import com.virtusa.inheritance.Task;

public class InheritanceMain {

	public static void main(String[] args) {
		
		Project project = new Project();
		project.setProjectName("Training Project");
		
		Module module = new Module();
		module.setProjectName("Meeting Organizer");
		module.setModuleName("PZ-Module");
		
		Task task = new Task();
		task.setProjectName("LastMile");
		task.setModuleName("Hibernate");
		task.setTaskName("Jdbc");
		

		

		Configuration configuration = new Configuration();
//		configuration.addAnnotatedClass(Project.class);
//		//configuration.addAnnotatedClass(Module.class);
//		configuration.addAnnotatedClass(Task.class); 
//		
		configuration.configure("hibernate.cfg.xml");
		SessionFactory session = configuration.buildSessionFactory();
		Session openSession = session.openSession();
		Transaction beginTransaction = openSession.beginTransaction();
		openSession.persist(project);
		openSession.persist(module);
		openSession.persist(task);
		beginTransaction.commit();
		openSession.close();
	}
}
