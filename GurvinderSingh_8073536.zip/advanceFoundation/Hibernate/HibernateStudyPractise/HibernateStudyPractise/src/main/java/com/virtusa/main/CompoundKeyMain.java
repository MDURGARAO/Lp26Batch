package com.virtusa.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.compositeKey.Account;
import com.hibernate.compositeKey.CompoundKey;

public class CompoundKeyMain {

	public static void main(String[] args) {
		
		CompoundKey key = new CompoundKey(01, 100001);
		Account acc = new Account();
		acc.setCompoundKey(key);
		acc.setAccountBalance(200000);
		acc.setAccountHolder("Gurvinder");
		
		
		CompoundKey key1 = new CompoundKey(02, 100002);
		Account acc1 = new Account();
		acc1.setCompoundKey(key1);
		acc1.setAccountBalance(300000);
		acc1.setAccountHolder("Sonu");
		
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory session = configuration.buildSessionFactory();
		Session openSession = session.openSession();
		Transaction beginTransaction = openSession.beginTransaction();
		openSession.save(acc);
		openSession.save(acc1);
		beginTransaction.commit();
		openSession.close();
		
	}
}
