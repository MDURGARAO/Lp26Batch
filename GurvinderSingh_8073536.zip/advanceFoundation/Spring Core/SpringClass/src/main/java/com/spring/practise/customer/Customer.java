package com.spring.practise.customer;

import java.util.Arrays;
import java.util.List;

import com.spring.practise.shops.Market;

public class Customer extends Market {
	private int custId;
	private String custName;
	private String payment;
	
	
	
	public Customer(int custId, String custName, String payment, long phnNo) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.payment = payment;
		this.phnNo = phnNo;
	}

	private long phnNo;
	private CustomerAddress customerAddress;
	private List<String> shoes;
	private String[] purchase;

	public void disp() {
		System.out.println(shoes);
		System.out.println(purchase);
	}

	public List<String> getShoes() {
		return shoes;
	}

	public void setShoes(List<String> shoes) {
		this.shoes = shoes;
	}

	public String[] getPurchase() {
		return purchase;
	}

	public void setPurchase(String[] purchase) {
		this.purchase = purchase;
	}

	public CustomerAddress getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(CustomerAddress customerAddress) {
		this.customerAddress = customerAddress;
	}

	public Customer() {

	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getPayment() {
		return payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}

	public long getPhnNo() {
		return phnNo;
	}

	public void setPhnNo(long phnNo) {
		this.phnNo = phnNo;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", payment=" + payment + ", phnNo=" + phnNo
				+ ", customerAddress=" + customerAddress + ", shoes=" + shoes + ", purchase="
				+ Arrays.toString(purchase) + "]";
	}

}