package com.spring.practise.shops;

import java.util.Arrays;
import java.util.List;

public class Market {
	private List<String> shoes;
	private String[] purchase;
	public List<String> getShoes() {
		return shoes;
	}
	public void setShoes(List<String> shoes) {
		this.shoes = shoes;
	}
	public String[] getPurchase() {
		return purchase;
	}
	public void setPurchase(String[] purchase) {
		this.purchase = purchase;
	}
	@Override
	public String toString() {
		return "Market [shoes=" + shoes + ", purchase=" + Arrays.toString(purchase) + "]";
	}
	
	
}
