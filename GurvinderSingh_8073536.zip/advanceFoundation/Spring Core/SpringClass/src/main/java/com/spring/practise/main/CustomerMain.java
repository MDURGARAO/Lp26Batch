package com.spring.practise.main;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.spring.practise.customer.Customer;
import com.spring.practise.customer.CustomerAddress;
import com.spring.practise.shops.Market;

public class CustomerMain {

	public static void main(String[] args) {
		
		ApplicationContext context1 = new ClassPathXmlApplicationContext("SpringCustomer.xml");
	
		 Customer cust=(Customer) context1.getBean("Customer");
//		 Market market = context1.getBean(Market.class, "Market");
		 System.out.println(cust);
		 
		}
}
