package com.spring.practise.customer;

public class CustomerAddress {


	private int hno;	
	private String cityName;
	private	 String stateName;
	public int getHno() {
		return hno;
	}
	public void setHno(int hno) {
		this.hno = hno;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	@Override
	public String toString() {
		return "CustomerAddress [hno=" + hno + ", cityName=" + cityName + ", stateName=" + stateName + "]";
	}


}
