package com.spring.jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class StudentDao {

	NamedParameterJdbcTemplate template;
	private JdbcTemplate temp;

	public void setTemp(JdbcTemplate temp) {
		this.temp = temp;
	}
	
//	public int saveStudent(Student stu) {
//		  String query="insert into student_details values('"+stu.getStudentId()+"','"+stu.getStudentName()+"','"+stu.getStudentAddress()+"')";  
//				    return temp.update(query);  		
//	}
//	
//	public int updateStudent(Student stu) {
//		 String query="update employee set name='"+stu.getStudentName()+"',address='"+stu.getStudentAddress()+"' where id='"+stu.getStudentId()+"' ";  
//		 return temp.update(query);	}
//}
	//PREPARED STATEMENT
//	public Boolean saveEmployeeByPreparedStatement(final Student stu){  
//	    String query="insert into student_details values(?,?,?)";  
//	    return temp.execute(query,new PreparedStatementCallback<Boolean>(){  
//	    public Boolean doInPreparedStatement(PreparedStatement ps)  
//	            throws SQLException, DataAccessException {  
//	              
//	        ps.setInt(1,stu.getStudentId());  
//	        ps.setString(2,stu.getStudentName());  
//	        ps.setString(3,stu.getStudentAddress());  
//	              
//	        return ps.execute();  
//	              
//	    }  
//	    });  
//	}  
	
	//RESULTSET EXTRACTOR
//	public List<Student>getAllStudents(){
//		return temp.query("select * from student_details", new ResultSetExtractor<List<Student>>() {
//
//			public List<Student> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//				List<Student> list = new ArrayList<Student>();
//				while(rs.next()) {
//					Student stu = new Student();
//					stu.setStudentId(rs.getInt(1));
//					stu.setStudentName(rs.getString(2));
//					stu.setStudentAddress(rs.getString(3));
//					list.add(stu);
//					
//				}
//				
//				
//				return list;
//			}
//			
//		});
//	}
	
	//ROWMAPPER
//	public List<Student> getAllStudentRowMapper(){  
//		 return temp.query("select * from student_details",new RowMapper<Student>(){  
//		    public Student mapRow(ResultSet rs, int rownumber) throws SQLException {  
//		        Student s=new Student();  
//		        s.setStudentId(rs.getInt(1));  
//		        s.setStudentName(rs.getString(2));  
//		        s.setStudentAddress(rs.getString(3));  
//		        return s;  
//		    }  
//		    });  
//	
//	}
	
	
	public  void save (Student s){  
		String query="insert into student_details values (:StudentId,:StudentName,:StudentAddress)";  
		  
		Map<String,Object> map=new HashMap<String,Object>();  
		map.put("StudentId",s.getStudentId());  
		map.put("StudentName",s.getStudentName());  
		map.put("StudentAddress",s.getStudentAddress());  
		  
		template.execute(query,map,new PreparedStatementCallback() {  
		    public Object doInPreparedStatement(PreparedStatement ps)  
		            throws SQLException, DataAccessException {  
		        return ps.executeUpdate();  
		    }  
		});  
		}  
	
	
}
