package com.spring.jdbc;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class StudentMain {

	public static void main(String[] args) {

//		 ApplicationContext ctx=new ClassPathXmlApplicationContext("student.xml");  
//	      
//		    StudentDao dao=(StudentDao)ctx.getBean("studentdao");  
//		    int status=dao.saveStudent(new Student(1,"Gurvinder","Hyderabad"));  
//		    System.out.println(status);  
//		   boolean bool =   dao.saveEmployeeByPreparedStatement(new Student(3,"Sonu","Hyderabad"));  
//		   System.out.println(bool);
		    
		  //  List<Student> list = dao.getAllStudents();
		    
//		    List<Student> list=dao.getAllStudentRowMapper();  
//		    for(Student s : list)
//		    	System.out.println(s);
		
		Resource r=new ClassPathResource("student.xml");  
	    BeanFactory factory=new XmlBeanFactory(r);  
	      
	    StudentDao dao=(StudentDao)factory.getBean("studentdao");  
	    dao.save(new Student(4,"Abcd","Chennai"));  
	}

}
