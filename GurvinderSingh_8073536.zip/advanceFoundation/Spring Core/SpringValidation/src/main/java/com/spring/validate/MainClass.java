package com.spring.validate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.ObjectError;

public class MainClass {
public static void main(String[] args) {
	
	ApplicationContext context = new ClassPathXmlApplicationContext("springValidate.xml");
	
	User user = (User) context.getBean("user");
	UserValidator userValidator = (UserValidator) context.getBean("userValidator");
	Map<String,String> map = new HashMap<String, String>();
	MapBindingResult err = new MapBindingResult(map, User.class.toString());
	userValidator.validate(user, err);
	List<ObjectError> allErrors = err.getAllErrors();
	for(ObjectError obj:allErrors)
	{
		System.out.println(obj.getDefaultMessage());
	}

}	
}