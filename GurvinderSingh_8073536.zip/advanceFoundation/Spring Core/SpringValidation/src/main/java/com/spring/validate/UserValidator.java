package com.spring.validate;

import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
public class UserValidator implements Validator {
	
	private Resource location;
	@Required
	public void setLocation(Resource location) {
		this.location = location;
	}

	public boolean supports(Class clazz) {
	        return User.class.equals(clazz);
	    }

		public void validate(Object obj, Errors err) {
			Properties prop=null;
			try {
				prop = PropertiesLoaderUtils.loadProperties(location);
			}
			catch(IOException e) {
				e.printStackTrace();
			}
			
			String msg1 = prop.getProperty("errormsg.name");
	        ValidationUtils.rejectIfEmpty(err, "name", "errormsg.name", msg1 );
	        User user = (User) obj;
	        if (user.getAge() < 18) {
	        	String msg2 = prop.getProperty("errormsg.age");
	            err.rejectValue("age", "errormsg.age", msg2);
	        } else if (user.getAge() > 110) {
//	        	String msg2 = prop.getProperty("errormsg.age");
	            err.rejectValue("age", "errormsg.age");
	        }
	    }

}
