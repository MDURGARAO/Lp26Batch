package com.spring.javabased;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Iphone {
	@Autowired
	Mobile mobile;
	
	public Mobile getMobile() {
		return mobile;
	}

	public void setMobile(Mobile mobile) {
		this.mobile = mobile;
	}

	public void iosVersion() {
		
		System.out.println("version is ios13");
		mobile.topMobile();
	}

	
	
	
}
