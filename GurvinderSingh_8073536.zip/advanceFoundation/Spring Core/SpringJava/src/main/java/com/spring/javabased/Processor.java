package com.spring.javabased;

import org.springframework.stereotype.Component;

@Component
public class Processor implements Mobile {

	
	public void topMobile() {
		
		System.out.println("Processor used is: A13microchip ");
		
	}

}