package com.spring.javabased;

public interface Mobile {

	void topMobile();
}
