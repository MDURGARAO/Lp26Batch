package com.spring.javabased;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.spring.javabased")
public class AppConfig {
	
//	@Bean
//	public Iphone display() {
//		return new Iphone();
//		
//	}
//	
//	@Bean
//	public Mobile getProcessor() {
//		return new Processor();
//	}
}
