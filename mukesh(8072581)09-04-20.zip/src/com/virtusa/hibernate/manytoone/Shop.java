package com.virtusa.hibernate.manytoone;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
@Entity
public class Shop {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int shopId;
private String shopName;
private String shopAddress;
//@OneToOne(cascade=CascadeType.ALL)
//private Customer customer;
/*public Customer getCustomer() {
	return customer;
}
public void setCustomer(Customer customer) {
	this.customer = customer;
}*/
public Shop() {
	super();
	// TODO Auto-generated constructor stub
}
public int getShopId() {
	return shopId;
}
public String getShopName() {
	return shopName;
}
public String getShopAddress() {
	return shopAddress;
}

public void setShopId(int shopId) {
	this.shopId = shopId;
}
public void setShopName(String shopName) {
	this.shopName = shopName;
}
public void setShopAddress(String shopAddress) {
	this.shopAddress = shopAddress;
}

public Shop(String shopName, String shopAddress) {
	this.shopName = shopName;
	this.shopAddress = shopAddress;
	
}


}
