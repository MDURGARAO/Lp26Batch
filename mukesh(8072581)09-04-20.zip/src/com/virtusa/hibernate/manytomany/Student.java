package com.virtusa.hibernate.manytomany;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="student")
public class Student implements Serializable{
	@Id
	//below two lines are used for automated generation of pk
	@GeneratedValue(generator="xr")
	@GenericGenerator(name="xr",strategy="increment")
	private int id;
	@Column(name="student_name")
	private String name;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", course=" + course + ", stars=" + stars + ", teachers="
				+ teachers + "]";
	}
	private String course;
	@Column(name="student_stars")
	private String stars;
	public Student(String name, String course, String stars) {
		super();
		this.name = name;
		this.course = course;
		this.stars = stars;
		//this.teachers = teachers;
	}
	@ManyToMany
	List<Teacher> teachers;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getStars() {
		return stars;
	}
	public void setStars(String stars) {
		this.stars = stars;
	}
	public List<Teacher> getTeachers() {
		return teachers;
	}
	public void setTeachers(List<Teacher> teachers) {
		this.teachers = teachers;
	}

}
