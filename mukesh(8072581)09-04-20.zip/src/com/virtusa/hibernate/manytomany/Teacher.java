package com.virtusa.hibernate.manytomany;


import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="teacher")
public class Teacher implements Serializable{
	@Id
	//below two lines are used for automated generation of pk
	@GeneratedValue(generator="xr")
	@GenericGenerator(name="xr",strategy="increment")
	private int id;
	public Teacher(String name, String subject, String experiance, List<Student> students) {
		super();
		this.name = name;
		this.subject = subject;
		this.experiance = experiance;
		this.students = students;
	}
	public Teacher() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Column(name="teacher_name")
	private String name;
	@Column(name="teacher_subject")
	private String subject;
	@Column(name="teacher_experiance")
	private String experiance;
	@ManyToMany
	List<Student> students;
	@Override
	public String toString() {
		return "Teacher [id=" + id + ", name=" + name + ", subject=" + subject + ", experiance=" + experiance
				+ ", students=" + students + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getExperiance() {
		return experiance;
	}
	public void setExperiance(String experiance) {
		this.experiance = experiance;
	}
	public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}

}
