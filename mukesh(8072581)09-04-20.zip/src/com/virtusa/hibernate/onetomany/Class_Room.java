package com.virtusa.hibernate.onetomany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Class_Room {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int classId;
private String className;
@OneToMany(cascade=CascadeType.ALL)
private List<Student> students;
public Class_Room() {
	super();
	// TODO Auto-generated constructor stub
}
public int getClassId() {
	return classId;
}
public String getClassName() {
	return className;
}
public List<Student> getStudents() {
	return students;
}
public void setClassId(int classId) {
	this.classId = classId;
}
public void setClassName(String className) {
	this.className = className;
}
public void setStudents(List<Student> students) {
	this.students = students;
}
public Class_Room(String className, List<Student> students) {
	this.className = className;
	this.students = students;
}

}
