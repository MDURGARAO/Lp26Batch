package com.virtusa.hibernate.composite;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
	
Session session=factory.openSession();
Transaction transaction=session.beginTransaction();
/*Course course1=new Course(1, "java", 500, "mukesh");
Course course2=new Course(2, "sql", 800, "prajal");
Course course3=new Course(3, "python", 400, "vivek");
session.save(course1);
session.save(course2);
session.save(course3);*/

Course course=session.get(Course.class,1 );
System.out.println(course);
//session.delete(course);
course.setName("html");
session.update(course);
transaction.commit();
session.close();
		
	}

}
