package com.virtusa.hibernate.inheritance;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="EmployeeTable")
@Inheritance(strategy=InheritanceType.JOINED)
public class Employee {
	@Id
	//below two lines are used for automated generation of pk
	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="empId")	
	protected int employeeId;
	protected String employeeName;
	protected double employeeSalary;
	protected long contact;


	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public Employee() {

	}
	public int getEmployeeId() {
		return employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	public Employee( String employeeName, double employeeSalary,long contact) {
		super();
		//this.employeeId =id;
		this.contact=contact;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}

}
