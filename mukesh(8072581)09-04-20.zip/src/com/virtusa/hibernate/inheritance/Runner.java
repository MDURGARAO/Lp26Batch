package com.virtusa.hibernate.inheritance;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.embedded.Employee;
import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
	
Session session=factory.openSession();
Transaction transaction=session.beginTransaction();
/*Tester tester1=new Tester("deepak", 20000, 9993200768l, "tester", new Date());
Tester tester2=new Tester("vivek", 20000, 9993200769l, "tester", new Date());
Tester tester3=new  Tester("pranjal", 20000, 9993200698l, "tester", new Date());

Developer developer1=new Developer("mukesh", 30000, 7354347878l, "facebook", 10);	
Developer developer2=new Developer("chandan", 30000, 7354347879l, "flipcart", 20);	
Developer developer3=new Developer("deepak", 30000, 7354347870l, "amazon", 30);	
session.save(developer1);
session.save(developer2);
session.save(developer3);

session.save(tester1);
session.save(tester2);
session.save(tester3);*/
Tester tester=session.get(Tester.class, 1);
System.out.println(tester);
tester.setProfile("team-lead");
//session.update(tester);
session.delete(tester);

transaction.commit();
session.close();
		
	}

}
