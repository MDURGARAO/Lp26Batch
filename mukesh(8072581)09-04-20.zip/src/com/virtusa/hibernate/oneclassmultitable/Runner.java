package com.virtusa.hibernate.oneclassmultitable;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.virtusa.hibernate.util.HibernateUtil;

public class Runner {

	public static void main(String[] args) {
		SessionFactory factory=HibernateUtil.getFactory();
	
Session session=factory.openSession();
Transaction transaction=session.beginTransaction();
/*Author Author1=new Author("mukesh", "Sahu", 99993200768l, "technical");
Author Author2=new Author("vivek", "gupta", 99993200769l, "sales");
Author Author3=new Author("pranjal", "bakshi", 99993200760l, " digital marketing");
session.save(Author1);
session.save(Author2);
session.save(Author3);*/
Author author=session.get(Author.class, 2);
System.out.println(author);
//session.delete(author);
author.setFirstName("deepak");
session.update(author);

//Query quary=session.createQuery("from author");

List<Author> lst=session.createCriteria(Author.class).list();
for (Author author2 : lst) {
	System.out.println(author2);
	if(author2.getFirstName().equals("mukesh"))
	session.delete(author2);
}
transaction.commit();
session.close();
		
	}

}
