package com.virtusa.hibernate.oneclassmultitable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "author")
@SecondaryTable(name = "author_details")
public class Author {
 
    @Override
	public String toString() {
		return "Author [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", contact=" + contact
				+ ", category=" + category + "]";
	}

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(updatable = false, nullable = false)
    private int id;
 
    private String firstName;
 
    private String lastName;
 
    @Column(table = "author_details")
    private long contact;
 
    @Column(table = "author_details")
    private String category;

	public int getId() {
		return id;
	}

	

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public Author(String firstName, String lastName, long contact, String category) {
		super();
		//this.id = id;
	//	this.version = version;
		this.firstName = firstName;
		this.lastName = lastName;
		this.contact = contact;
		this.category = category;
	}

	public long getContact() {
		return contact;
	}

	public String getCategory() {
		return category;
	}

	public void setId(int id) {
		this.id = id;
	}

	

	

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}
 
  
}