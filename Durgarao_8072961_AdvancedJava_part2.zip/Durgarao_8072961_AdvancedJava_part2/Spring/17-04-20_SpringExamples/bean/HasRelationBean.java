package com.virtusa.spring.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.pojo.Admin;

public class HasRelationBean {

	public static void main(String ...mdr) {
		ApplicationContext context=new ClassPathXmlApplicationContext("spring-core-config.xml");
		Admin adminBean=context.getBean(Admin.class,"adminBean");
		System.out.println(adminBean.toString());
	
	}

}
