package com.virtusa.spring.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.pojo.Writer;

public class CollectionsBean {
	
	public static void main(String ...mdr) {
		ApplicationContext context=new ClassPathXmlApplicationContext("spring-core-config.xml");
		Writer writerBean=context.getBean(Writer.class,"writerBean");
		System.out.println(writerBean.toString());
	}
}
