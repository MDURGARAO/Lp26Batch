package com.virtusa.spring.pojo;


public class Book extends BaseBook {
	 
	   
    private String properties;
    
   
	public String getProperties() {
        return properties;
    }

	public void setProperties(String properties) {
		this.properties = properties;
	}

	@Override
	public String toString() {
		return "Book [properties=" + properties + "]";
	}
	
	
 
}
