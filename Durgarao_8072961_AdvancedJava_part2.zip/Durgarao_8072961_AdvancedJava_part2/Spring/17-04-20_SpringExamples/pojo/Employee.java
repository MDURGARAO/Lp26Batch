package com.virtusa.spring.pojo;



public class Employee {
	
	private int employeeId;
	private String empName;
	private String empDesignation;
	private double salary;
	private char gender;
	private String address;
	
	
	
	
	public Employee(int employeeId, String empName, String empDesignation, double salary, char gender, String address) {
		super();
		this.employeeId = employeeId;
		this.empName = empName;
		this.empDesignation = empDesignation;
		this.salary = salary;
		this.gender = gender;
		this.address = address;
	}



	public int getEmployeeId() {
		return employeeId;
	}



	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}



	public String getEmpName() {
		return empName;
	}



	public void setEmpName(String empName) {
		this.empName = empName;
	}



	public String getEmpDesignation() {
		return empDesignation;
	}



	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}



	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary) {
		this.salary = salary;
	}



	public char getGender() {
		return gender;
	}



	public void setGender(char gender) {
		this.gender = gender;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", empName=" + empName + ", empDesignation=" + empDesignation
				+ ", salary=" + salary + ", gender=" + gender + ", address=" + address + "]";
	}
	

	
	
}
