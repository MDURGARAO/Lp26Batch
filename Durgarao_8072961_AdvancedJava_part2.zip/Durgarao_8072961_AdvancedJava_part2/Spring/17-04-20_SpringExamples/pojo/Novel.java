package com.virtusa.spring.pojo;

public class Novel {

	private Integer novelId;
    private String novelName;
    private double novelCost;
   

	public Integer getNovelId() {
		return novelId;
	}

	public void setNovelId(Integer novelId) {
		this.novelId = novelId;
	}

	public String getNovelName() {
		return novelName;
	}

	public void setNovelName(String novelName) {
		this.novelName = novelName;
	}

	public double getNovelCost() {
		return novelCost;
	}

	public void setNovelCost(double novelCost) {
		this.novelCost = novelCost;
	}

	@Override
	public String toString() {
		return "Novel [novelId=" + novelId + ", novelName=" + novelName + ", novelCost=" + novelCost + "]";
	}
	
	
}
