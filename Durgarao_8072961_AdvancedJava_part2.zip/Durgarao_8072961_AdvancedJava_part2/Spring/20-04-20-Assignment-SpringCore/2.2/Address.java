package com.virtusa.spring.pojo;

public class Address {
	private int no;
	private String street;
	private String village;
	private String city;
	
	public Address(int no, String street, String village, String city) {
		super();
		this.no = no;
		this.street = street;
		this.village = village;
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address [no=" + no + ", street=" + street + ", village=" + village + ", city=" + city + "]";
	}
	

}
