package com.virtusa.spring.pojo;

public class Admin {
	
	private int adminId;
	private String adminName;
	private String adminEmail;
	private String password;
	private Address address;
	private PhoneNumbers phoneNumbers;
	
	
	public Admin(int adminId, String adminName, String adminEmail, String password, Address address,
			PhoneNumbers phoneNumbers) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.adminEmail = adminEmail;
		this.password = password;
		this.address = address;
		this.phoneNumbers = phoneNumbers;
	}


	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminName=" + adminName + ", adminEmail=" + adminEmail + ", password="
				+ password + ", address=" + address + ", phoneNumbers=" + phoneNumbers + "]";
	}
	
	
	

}
