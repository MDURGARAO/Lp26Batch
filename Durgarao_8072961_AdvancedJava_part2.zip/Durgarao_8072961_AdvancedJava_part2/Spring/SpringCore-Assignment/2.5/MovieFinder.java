package com.virtusa.spring.pojo;

import org.springframework.beans.factory.annotation.Required;

public class MovieFinder {
	
	private String searchName;
	private int year;
	
	
	public String getSearchName() {
		return searchName;
	}
	@Required
	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	@Override
	public String toString() {
		return "MovieFinder [searchName=" + searchName + ", year=" + year + "]";
	}

}
