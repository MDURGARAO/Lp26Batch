package com.virtusa.spring.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.pojo.Movie;

public class MovieBean {

	public static void main(String  ...mdr) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("annotation-config.xml");
		
		Movie movieBean=context.getBean(Movie.class,"movieBean");
		System.out.println(movieBean.toString());
		

	}

}
