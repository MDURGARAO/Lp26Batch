package com.virtusa.spring.pojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class Movie {

	 @Autowired(required=false)
    private String movieName;
	 
	 @Autowired(required=false)
    private int releaseYear;
    
    @Autowired
    private MovieFinder movieFinder;

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}


	public int getReleaseYear() {
		return releaseYear;
	}


	public void setReleaseYear(int releaseYear) {
		this.releaseYear = releaseYear;
	}


	public MovieFinder getMovieFinder() {
		return movieFinder;
	}


	public void setMovieFinder(MovieFinder movieFinder) {
		this.movieFinder = movieFinder;
	}


	@Override
	public String toString() {
		return "Movie [movieName=" + movieName + ", releaseYear=" + releaseYear + ", movieFinder=" + movieFinder + "]";
	}

	
   
}
