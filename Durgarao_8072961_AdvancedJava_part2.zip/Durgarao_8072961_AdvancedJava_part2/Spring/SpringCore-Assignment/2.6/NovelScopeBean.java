package com.virtusa.spring.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.pojo.Novel;


public class NovelScopeBean {
public static void main(String  ...mdr) {
		
	ApplicationContext context=new ClassPathXmlApplicationContext("annotation-config.xml");
		//singleton scope example
//		Novel novelA=context.getBean(Novel.class,"novelBean");
//		novelA.changeCost(3000.0);
//		System.out.println(novelA.toString());
//		Novel novelB=context.getBean(Novel.class,"novelBean");
//		System.out.println(novelB.toString());

	//here cost of novelA is taken to cost of novelB because only one bean created ... in singleton
	
	//prototype scope example

		Novel novelA=context.getBean(Novel.class,"novelBeanPrototype");
		novelA.changeCost(3000.0);
		System.out.println(novelA.toString());
		Novel novelB=context.getBean(Novel.class,"novelBeanPrototype");
		System.out.println(novelB.toString());
		
		//here cost of novelA is not cost of novelB because only two instance beans created  ... in prototype
}
}