package com.virtusa.spring.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.virtusa.javabasedannotation.MobileConfig;
import com.virtusa.spring.pojo.Apple;
import com.virtusa.spring.pojo.Mobile;

public class MobileBean {
	   public static void main(String[] args) {
		   
		      ApplicationContext context = new AnnotationConfigApplicationContext(MobileConfig.class);
		   
		      Mobile mobile = context.getBean(Mobile.class);
		      mobile.test();
		   }

}
