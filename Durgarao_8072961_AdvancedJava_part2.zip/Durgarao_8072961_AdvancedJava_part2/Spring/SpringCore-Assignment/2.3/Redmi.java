package com.virtusa.spring.pojo;

public class Redmi {
	private int model;
	private int year;
	private double cost;

	public int getModel() {
		return model;
	}
	public void setModel(int model) {
		this.model = model;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	@Override
	public String toString() {
		return "Redmi [model=" + model + ", year=" + year + ", cost=" + cost + "]";
	}
	
	

}
