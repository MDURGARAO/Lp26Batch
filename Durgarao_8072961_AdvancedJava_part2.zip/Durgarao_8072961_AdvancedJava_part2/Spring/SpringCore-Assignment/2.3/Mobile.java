package com.virtusa.spring.pojo;

public class Mobile {
	
	private String message;
	private Apple apple;
	private Redmi redmi;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Apple getApple() {
		return apple;
	}
	public void setApple(Apple apple) {
		this.apple = apple;
	}
	public Redmi getRedmi() {
		return redmi;
	}
	public void setRedmi(Redmi redmi) {
		this.redmi = redmi;
	}
	
	public void test()
	{
		System.out.println(apple.getCost());
		System.out.println(redmi.getModel());
		System.out.println("Message "+message);
	}
	
	
	@Override
	public String toString() {
		return "Mobile [message=" + message + ", apple=" + apple + ", redmi=" + redmi + "]";
	}
	
	   
	   
}

