package com.virtusa.javabasedannotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.virtusa.spring.pojo.Apple;
import com.virtusa.spring.pojo.Mobile;
import com.virtusa.spring.pojo.Redmi;

@Configuration
public class MobileConfig {
	
	
	@Bean
	public Mobile mobile() {
		Mobile mobile=new Mobile();
		mobile.setMessage("Welcome");
		mobile.setApple(apple());
		mobile.setRedmi(redmi());
		return mobile;
	}
	
	@Bean
	public Redmi redmi() {
		Redmi redmi=new Redmi();
		redmi.setCost(2000.0);
		redmi.setModel(2716);
		redmi.setYear(2020);
		
		return  redmi;
	}
	
	@Bean
	public Apple apple() {
		Apple apple=new Apple();
		apple.setCost(2000.0);
		apple.setModel(2716);
		apple.setYear(2020);
		return apple;
	}
	

}
