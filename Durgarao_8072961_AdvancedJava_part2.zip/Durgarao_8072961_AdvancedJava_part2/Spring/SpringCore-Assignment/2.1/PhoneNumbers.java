package com.virtusa.spring.pojo;

public class PhoneNumbers {
	
	private long personalNumber;
	private long homeNumber;
	public long getPersonalNumber() {
		return personalNumber;
	}
	public void setPersonalNumber(long personalNumber) {
		this.personalNumber = personalNumber;
	}
	public long getHomeNumber() {
		return homeNumber;
	}
	public void setHomeNumber(long homeNumber) {
		this.homeNumber = homeNumber;
	}
	@Override
	public String toString() {
		return "PhoneNumbers [personalNumber=" + personalNumber + ", homeNumber=" + homeNumber + "]";
	}
	
	
}
