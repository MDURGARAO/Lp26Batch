package com.virtusa.spring.pojo;

public class Apple {
	private int model;
	private int year;
	private double cost;
	
	
	public Apple(int model, int year, double cost) {
		super();
		this.model = model;
		this.year = year;
		this.cost = cost;
	}
	public double getCost() {
		return cost;
		
	}

	@Override
	public String toString() {
		return "Apple [model=" + model + ", year=" + year + ", cost=" + cost + "]";
	}
	
	

}
