package com.virtusa.spring.pojo;

public class Mobile {
	
	private String message;
	private Apple apple;
	private Redmi redmi;
	
	
	public Mobile(String message, Apple apple, Redmi redmi) {
		super();
		this.message = message;
		this.apple = apple;
		this.redmi = redmi;
	}


	public void test()
	{
		System.out.println(apple.getCost());
		System.out.println(redmi.getModel());
		System.out.println("Message "+message);
	}
	
	
	@Override
	public String toString() {
		return "Mobile [message=" + message + ", apple=" + apple + ", redmi=" + redmi + "]";
	}
	
	   
	   
}

