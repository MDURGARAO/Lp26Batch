package com.virtusa.javabasedannotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.virtusa.spring.pojo.Apple;
import com.virtusa.spring.pojo.Mobile;
import com.virtusa.spring.pojo.Redmi;

@Configuration
public class MobileConfig {
	
	
	@Bean
	public Mobile mobile() {
		Mobile mobile=new Mobile("Welcome",apple(),redmi());
		
		return mobile;
	}
	
	@Bean
	public Redmi redmi() {
		Redmi redmi=new Redmi(2716,2020,2000.0);
		
		
		return  redmi;
	}
	
	@Bean
	public Apple apple() {
		Apple apple=new Apple(2716,2020,2000.0);
		return apple;
	}
	

}
