package com.virtusa.spring.pojo;

public class Redmi {
	private int model;
	private int year;
	private double cost;
	
	
	
	public Redmi(int model, int year, double cost) {
		super();
		this.model = model;
		this.year = year;
		this.cost = cost;
	}
	public int getModel()
	{
		return model;
	}



	@Override
	public String toString() {
		return "Redmi [model=" + model + ", year=" + year + ", cost=" + cost + "]";
	}
	
	

}
