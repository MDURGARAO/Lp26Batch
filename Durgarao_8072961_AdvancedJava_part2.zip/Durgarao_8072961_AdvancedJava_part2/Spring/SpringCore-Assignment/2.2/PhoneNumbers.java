package com.virtusa.spring.pojo;

public class PhoneNumbers {
	
	private long personalNumber;
	private long homeNumber;
	
	
	public PhoneNumbers(long personalNumber, long homeNumber) {
		super();
		this.personalNumber = personalNumber;
		this.homeNumber = homeNumber;
	}


	@Override
	public String toString() {
		return "PhoneNumbers [personalNumber=" + personalNumber + ", homeNumber=" + homeNumber + "]";
	}
	
	
}
