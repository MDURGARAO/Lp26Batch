package com.virtusa.hibernate.client;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.entity.AdminDetails;
import com.virtusa.hibernate.entity.Employee;

public class ClientMain {
	public static void main(String ...mdr) {
//		Employee employee1=new Employee();
//		employee1.setEmpName("emp3");
//		employee1.setGender('F');
//		employee1.setAddress("Rampura");
//		employee1.setEmpDesignation("AssociateEngineer");
//		employee1.setSalary(25000);
		
		//AdminDetails adminDetails=new AdminDetails(100,"ram","ram@gmail.com","ram@123");
				
		Configuration config=new Configuration();
		config.configure("hibernate.cfg.xml");
		SessionFactory factory =  config.buildSessionFactory(); 
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();

//		Employee emp=(Employee) session.load(Employee.class, 2);
	//	System.out.println(emp.toString());
		
	//session.save(employee1);
		
//		Query query=session.createQuery("from Employee");
		
//		List<Employee> list=query.list();
//		
//		list.forEach(System.out::println);
//		
		
//		Query query=session.createQuery("from Employee as e where e.salary<50000");
//		Iterator<Employee> list=query.iterate();// this one executes query every time 
//		while(list.hasNext())
//		{
//			System.out.println(list.next() +" ");
//		}
//		

//		Query query=session.createQuery("select e.empName from Employee as e order by e.empName");
//		
//		Iterator<String> list=query.iterate();
//		while(list.hasNext())
//		{
//			System.out.println(list.next() +" ");
//		}
		
		
//		Query query=session.createQuery("select avg(salary), max(salary), sum(salary) from Employee");
//		
//		List<Object []> list=query.list();
//		
//		for(Object[] array:list) {
//			System.out.println(array[0]+" "+array[1]+ " " +array[2]);
//		}
		
		
		
		
		
//		Query query=session.createQuery("select e.empName, e.salary from Employee as e where e.salary<25000");
//		List<Object []> list=query.list();
//		
//		for(Object[] array:list) {
//			System.out.println(array[0]+" "+array[1]);
//		}
		
//Using Placeholder	 through positional parameters	
//		Query query=session.createQuery("select e.empName, e.salary from Employee as e where e.salary<?");
//		query.setDouble(0, new Scanner(System.in).nextDouble());//25000
		
//	Using named parameters	
//		Query query=session.createQuery("select e.empName, e.salary from Employee as e where e.salary< :salary");
//		query.setDouble("salary", new Scanner(System.in).nextDouble());
//		
//		 List<Object []> list=query.list();
//		
//		for(Object[] array:list) {
//			System.out.println(array[0]+" "+array[1]);
//		}

		
	// //Paging	
//		Query query=session.createQuery("from Employee" );
//		query.setFirstResult(2);//
//		query.setMaxResults(1);
//		List<Employee> list=query.list();
//	
//	list.forEach(System.out::println);
//		
		
	// using entity object instead of using object[] array 	
		Query query=session.createQuery("select new Employee(empName, salary) from Employee ");
		
		List<Employee> list=query.list();
		
			//list.forEach(System.out::println);
		
		for(Employee emp:list)
		{
			System.out.println(emp.getEmpName()+ " "+ emp.getSalary());
		}
		
		transaction.commit();
		session.close();
	}

}
