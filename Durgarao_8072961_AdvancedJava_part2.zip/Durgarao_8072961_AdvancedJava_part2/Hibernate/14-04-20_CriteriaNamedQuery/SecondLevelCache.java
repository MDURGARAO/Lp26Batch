package com.virtusa.hibernate.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.entity.EmployeeSecondLevelCache;

public class SecondLevelCache {

public static void main(String... mdr) {
	// second level cache applied on SessionFactory object which has more session objects..
	// hibernate does not fire query twice. If you don't use second level cache, 
	//hibernate will fire query twice because both query uses different session objects.
		
		Configuration config=new Configuration();
		config.configure("hibernate.cfg.xml");
		SessionFactory factory =  config.buildSessionFactory(); 
		
		
		
		
		Session session1=factory.openSession();    
		EmployeeSecondLevelCache emp1=(EmployeeSecondLevelCache)session1.load(EmployeeSecondLevelCache.class,2);    
	    System.out.println(emp1.getEmployeeId()+" "+emp1.getEmpName()+" "+emp1.getSalary());    
	    session1.close();    
	        
	    Session session2=factory.openSession();    
	    EmployeeSecondLevelCache emp2=(EmployeeSecondLevelCache)session2.load(EmployeeSecondLevelCache.class,2);    
	    System.out.println(emp2.getEmployeeId()+" "+emp2.getEmpName()+" "+emp2.getSalary());     
	    session2.close();    
		
		
	}

}
