package com.virtusa.hibernate.client;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.PropertyProjection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import com.virtusa.hibernate.entity.Employee;
import com.virtusa.hibernate.entity.EmployeeCriteria;

public class EmployeeCriteriaMain {

	public static void main(String... mdr) {
		
		
		Configuration config=new Configuration();
		config.configure("hibernate.cfg.xml");
		SessionFactory factory =  config.buildSessionFactory(); 
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		
//		//Criteria we can avoid sql language completely
//		//simple Select query
		
//		Criteria criteria=session.createCriteria(EmployeeCriteria.class);
//		
//		List<EmployeeCriteria> empList=criteria.list();
//		empList.forEach(System.out::println);
		
		
//		//Applying like where condition using SimpleExpression  and restrictions 
//		
//		Criteria criteria=session.createCriteria(EmployeeCriteria.class);
//		
//		SimpleExpression  expression= Restrictions.eq("empName", "emp");
//		// adding expression to the select query
//		criteria.add(expression);
//		// now it will be select * from employeeCriteria where empName='emp';
//	
//		
//		List<EmployeeCriteria> empList=criteria.list();
//		empList.forEach(System.out::println);
//		
		
//		// Applying AND operation using logical expression
//		
//		Criteria criteria=session.createCriteria(EmployeeCriteria.class);
//		SimpleExpression  expression1= Restrictions.eq("empName", "emp");
//		SimpleExpression  expression2= Restrictions.eq("salary", 25000.00);
//		
//		LogicalExpression  expression3= Restrictions.and(expression1, expression2);
//		criteria.add(expression3);
//		
//		List<EmployeeCriteria> empList=criteria.list();
//		empList.forEach(System.out::println);
		
		
//		//applying order by on select query with where condition
//		
//		Criteria criteria=session.createCriteria(EmployeeCriteria.class);
//		SimpleExpression  expression1= Restrictions.le("salary", 25000.00);
//		criteria.add(expression1);
//		criteria.addOrder(Order.desc("empName"));
//		
//		List<EmployeeCriteria> empList=criteria.list();
//		empList.forEach(System.out::println);
		
		
		//Retrieving the columns individually using PropertyProjection and ProjectionList
		
		Criteria criteria=session.createCriteria(EmployeeCriteria.class);
		//PropertyProjection property1=Projections.property("empName");
		ProjectionList projectionList=Projections.projectionList();
		
		projectionList.add(Projections.property("empName"))
					  .add(Projections.property("salary"))
					  .add(Projections.property("gender"));
		
		criteria.setProjection(projectionList);
		
		List<Object[]> empList=criteria.list();
		for(Object[] array:empList)
		{
			System.out.println(array[0]+"  "+array[1]+ " "+array[2]);
		}
	
		transaction.commit();
		session.close();

	}

}
