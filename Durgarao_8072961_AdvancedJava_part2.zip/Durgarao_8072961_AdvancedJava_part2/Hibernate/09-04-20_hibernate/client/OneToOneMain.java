package com.virtusa.hibernate.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.entity.ReportCard;
import com.virtusa.hibernate.entity.Student;

public class OneToOneMain {
	public static void main(String ...mdr) {
//   Student student1=new Student();
//   student1.setsId(101);
//   student1.setsName("Raj");
//   student1.setAddress("Rampuram");
//////		Student student2=new Student(101,"Ravi","Ramapuram");
//////		Student student3=new Student(102,"Raj","Ramapuram");
//////		Student student4=new Student(103,"Ramana","Ramapuram");
//	ReportCard reportCard1=new ReportCard();
//	
//	
//	
//	reportCard1.setrId(201);
//	reportCard1.setPercentage(34);
//	reportCard1.setStatus("Fail");
	
	
		
	Configuration config=new Configuration();
	config.configure("hibernate.cfg.xml");
	SessionFactory factory =  config.buildSessionFactory(); 

	Session session=factory.openSession();
	Transaction transaction=session.beginTransaction();
	
	
	ReportCard reportCard1=(ReportCard) session.get(ReportCard.class, 200);
	System.out.println(reportCard1.toString());
	
	Student student=(Student) session.get(Student.class, 100);
	System.out.println(student.toString());
	//Student student1=session.get(student, 100);
	
	//session.saveOrUpdate(student); 
	
//	session.save(student1);
//	session.save(reportCard1);
	
	transaction.commit();
	session.close();
	
	/* webapplication
	 * properties...
	 * java facet --dynamic application...
	 * deployment assembly --- java build path
	 * add maven dependencies....
	 */
	
	

}
}