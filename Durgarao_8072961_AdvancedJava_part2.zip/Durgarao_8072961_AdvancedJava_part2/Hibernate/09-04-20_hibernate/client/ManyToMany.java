package com.virtusa.hibernate.client;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.entity.Reader;
import com.virtusa.hibernate.entity.Subscription;

public class ManyToMany {
	public static void main(String ...mdr) {
	
	Configuration config=new Configuration();
	config.configure("hibernate.cfg.xml");
	SessionFactory factory =  config.buildSessionFactory(); 

	Session session=factory.openSession();
	Transaction transaction=session.beginTransaction();
	
	//Add subscription
    Subscription subOne = new Subscription();
    subOne.setSubscriptionName("Entertainment");
     
    Subscription subTwo = new Subscription();
    subTwo.setSubscriptionName("Horror");
     
    Set<Subscription> subs = new HashSet<Subscription>();
    subs.add(subOne);
    subs.add(subTwo);
     
    //Add readers
    Reader readerOne = new Reader();
    readerOne.setEmail("user1@mail.com");
    readerOne.setFirstName("ram");
    readerOne.setLastName("laxman");
     
    Reader readerTwo = new Reader();
    readerTwo.setEmail("user2@mail.com");
    readerTwo.setFirstName("ram");
    readerTwo.setLastName("raju");
     
    Set<Reader> readers = new HashSet<Reader>();
    readers.add(readerOne);
    readers.add(readerTwo);
     
    readerOne.setSubscriptions(subs);
    readerTwo.setSubscriptions(subs);

    session.save(readerOne);
    session.save(readerTwo);
	
	
	transaction.commit();
	session.close();

}

}