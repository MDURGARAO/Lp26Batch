package com.virtusa.hibernate.client;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hibernate.entity.Novel;
import com.virtusa.hibernate.entity.Writer;

public class OnetoManyandManytoOneMain {

	public static void main(String[] args) {
		
		Configuration config=new Configuration();
		config.configure("hibernate.cfg.xml");
		SessionFactory factory =  config.buildSessionFactory(); 

		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		
		
		Novel novel1 = new Novel();
        novel1.setNovelName(" The Pilgrim’s Progress ");
        novel1.setNovelCost(500);
        
        Novel novel2 = new Novel();
        novel2.setNovelName(" Robinson Crusoe ");
        novel2.setNovelCost(600);
        
        Novel novel3 = new Novel();
        novel3.setNovelName(" Gulliver’s Travels ");
        novel3.setNovelCost(700);
 
        //Add new Writer object
        Writer firstWriter = new Writer();
        firstWriter.setEmail("userfirst@mail.com");
        firstWriter.setName("John Bunyan ");
 
        Writer secondWriter = new Writer();
        secondWriter.setEmail("usersecond@mail.com");
        secondWriter.setName("Daniel Defoe ");
 
        Set<Novel> novelsOfFirstWriter = new HashSet<Novel>();
        novelsOfFirstWriter.add(novel1);
        novelsOfFirstWriter.add(novel3);
 
        Set<Novel> novelsOfSecondWriter = new HashSet<Novel>();
        novelsOfSecondWriter.add(novel2);
        
        
        firstWriter.setNovels(novelsOfFirstWriter);
        secondWriter.setNovels(novelsOfSecondWriter);
 
        //Save Writer
        session.save(firstWriter);
        session.save(secondWriter);
		
		
		
		
		transaction.commit();
		session.close();

	}

}
