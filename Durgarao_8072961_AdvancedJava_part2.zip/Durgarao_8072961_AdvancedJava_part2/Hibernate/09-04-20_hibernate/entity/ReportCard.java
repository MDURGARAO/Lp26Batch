package com.virtusa.hibernate.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="reportCard")
public class ReportCard {
	@Id
	private int rId;
	private int percentage;
	private String status;
	
	//Eager loading by default changed to lazy loading using fetch 
	//(fetch = FetchType.LAZY)
	@OneToOne(fetch = FetchType.LAZY)
	private Student student;
	
	public ReportCard() {
		
	}

	public int getrId() {
		return rId;
	}

	public void setrId(int rId) {
		this.rId = rId;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public String toString() {
		return "ReportCard [rId=" + rId + ", percentage=" + percentage + ", status=" + status + ", student=" + student
				+ "]";
	}


	
	

}
