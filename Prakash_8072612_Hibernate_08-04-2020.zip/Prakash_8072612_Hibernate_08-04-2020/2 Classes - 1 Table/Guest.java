package com.virtusa.entities;

import java.util.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.virtusa.sub.Address;

@Entity
public class Guest {
	
	@Id
	private int guestid;
	private String name;
	private String email;
	private Date dob;
	private String password;
	@Embedded
	private Address address;
	
	public Guest() {
		super();
	}
	
	public Guest(int guestid, String name, String email, Date dob, String password, Address address) {
		super();
		this.guestid = guestid;
		this.name = name;
		this.email = email;
		this.dob = dob;
		this.password = password;
		this.address = address;
	}
	
	public int getGuestid() {
		return guestid;
	}
	
	public void setGuestid(int guestid) {
		this.guestid = guestid;
	} 
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public Date getDob() {
		return dob;
	}
	
	public void setDob(Date dob) {
		this.dob = dob;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "Guest [guestid=" + guestid + ", name=" + name + ", email=" + email + ", dob=" + dob + ", password="
				+ password + ", address=" + address + "]";
	}
	
}
