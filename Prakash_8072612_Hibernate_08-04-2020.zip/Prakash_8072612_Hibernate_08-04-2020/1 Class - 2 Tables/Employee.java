package com.virtusa.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name = "Personal_Info")
@SecondaryTable(name = "Company_Info")
public class Employee {
	
	@Id
	@Column(table = "Personal_Info")
	private int id;
	@Column(table = "Personal_Info")
	private String empName;
	@Column(table = "Personal_Info")
	private String personalMail;
	
	
	
	@Column(table = "Company_Info")
	private int empId;
	@Column(table = "Company_Info")
	private String cmpnyMail;
	
	public Employee() {
		super();
	}

	public Employee(int id,String empName, String personalMail, int empId, String cmpnyMail) {
		super();
		this.id = id;
		this.empName = empName;
		this.personalMail = personalMail;
		this.empId = empId;
		this.cmpnyMail = cmpnyMail;
	}
	
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getPersonalMail() {
		return personalMail;
	}

	public void setPersonalMail(String personalMail) {
		this.personalMail = personalMail;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getCmpnyMail() {
		return cmpnyMail;
	}

	public void setCmpnyMail(String cmpnyMail) {
		this.cmpnyMail = cmpnyMail;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", empName=" + empName + ", personalMail=" + personalMail + ", empId=" + empId
				+ ", cmpnyMail=" + cmpnyMail + "]";
	}
	
}
