package com.virtusa.hibernate.operation;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.virtusa.hibernate.manytomany.UserDetail;
import com.virtusa.hibernate.util.HibernateUtil;
import com.virtusa.hibernate.manytomany.Vehicle;

public class ManyToMany_Operation {
	UserDetail user = new UserDetail();
	
	public void insertDataIntoTable(List<UserDetail> userList) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Iterator<UserDetail> iterator = userList.iterator();
		while(iterator.hasNext())
		{
			UserDetail next = iterator.next();
			session.persist(next);
		}	
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}

	public void viewDataOfTable() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from UserDetail");
		List<UserDetail> fetchData = query.list();
		Iterator<UserDetail> iterator = fetchData.iterator();
		while(iterator.hasNext())
		{
			user = (UserDetail)iterator.next();
			System.out.println(user);
		}		
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}
	
	public void updateDataOfTable(int userId) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		try {
			user = (UserDetail) session.get(UserDetail.class, userId);
			user.setUserName("Baba");
			List<Vehicle> vehicle = user.getVehicle();
			Vehicle vehicle1 = vehicle.get(0);
			vehicle1.setVehicleName("Nano");
			Vehicle vehicle2 = vehicle.get(1);
			vehicle2.setVehicleName("Audi");
			vehicle.clear();
			vehicle.add(vehicle1);
			vehicle.add(vehicle2);
			user.setVehicle(vehicle);
			session.persist(user);
			session.getTransaction().commit();
		} catch (Exception e) {
			System.err.println("!!!!Please Enter valid Id");
			HibernateUtil.shutdown();
		}
		finally {
			HibernateUtil.shutdown();
		}
	}
	public void deleteDataFormTable() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.getTransaction().begin();
		try {
			user = (UserDetail) session.get(UserDetail.class, 3);	
			session.delete(user);
			session.getTransaction().commit();
		} catch (Exception e) {
			System.err.println("!!!!Please Enter valid Id");
			HibernateUtil.shutdown();
		}
		finally {
			HibernateUtil.shutdown();
		}	
	}
}
