package com.virtusa.hibernate.main;

import java.util.Date;
import com.virtusa.hibernate.onetoone.Passport;
import com.virtusa.hibernate.onetoone.Person;
import com.virtusa.hibernate.operation.OneToOne_Operation;

public class OneToOne_RunnerApp {

	public static void main(String[] args) {
		
		OneToOne_Operation operation = new OneToOne_Operation();
		Person person = new Person();
		Passport passport = new Passport();
    // To save a data 		
		
	    person.setName("Pranjal");
		person.setNumber(9876543210l);
		
		passport.setPassportLocation("LasVegas");
		passport.setPassportExpiry(new Date());
		passport.setPerson(person);
		
		//operation.saveData(passport);
	
	// Update a data 
		// operation.updateData(3);		
		 
	// delete a data 
		 //operation.deleteData(3);
		
	// read data
		operation.viewAllData();
	}
	
}
