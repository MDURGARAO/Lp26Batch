package com.virtusa.hibernate.main;

import org.hibernate.*;
import org.hibernate.cfg.*;

import com.virtusa.hibernate.entity.Address;
import com.virtusa.hibernate.entity.Developer;
import com.virtusa.hibernate.entity.Employee;
import com.virtusa.hibernate.entity.Employee1;
import com.virtusa.hibernate.entity.Product;
import com.virtusa.hibernate.entity.Teacher;
import com.virtusa.hibernate.entity.Tester;

public class Runner {
	public static void main(String[] args)
	{

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml"); 

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		
		Address address = new Address("12","annexeRoad",400001);
	    Employee emp1 = new Employee(101,"pranjal",30000,"java developer",address);
	    
	    Teacher te = new Teacher();
	    te.setFirstName("pranjal");
	    te.setLastName("bakshi");
	    te.setElectrical("machine");
	    te.setComputer("java");
	    
	    Employee1 emp = new Employee1(101,"chandu",30000,"employee");
		Developer developer = new Developer(102,"scott",40000,"developer",10,"java","hibernate");
		Tester tester = new Tester(103,"martin",35000,"tester","selenium","webdeveloper");
		
		session.save(emp);
		session.save(developer);
		session.save(tester);
		
		session.getTransaction().commit();

		Product p=new Product();

		p.setProductId(02);
		p.setProName("samsung");
		p.setPrice(30300); 

		Transaction tx = session.beginTransaction();
		session.save(emp1);
		session.save(p);
		session.save(te);
		System.out.println("Object Loaded successfully.....!!");
		tx.commit();     

		session.close();
		factory.close();
	}
}
