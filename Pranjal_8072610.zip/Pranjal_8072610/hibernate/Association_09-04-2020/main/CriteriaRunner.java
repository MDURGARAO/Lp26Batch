package com.virtusa.hibernate.main;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.PropertyProjection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;
import com.virtusa.hibernate.onetoone.Person;
import com.virtusa.hibernate.util.HibernateUtil;

public class CriteriaRunner {
	public static void main(String[] args) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
//		 Criteria criteria = session.createCriteria(Person.class);
//		 List list = criteria.list();
//		 list.stream();
//		 for (Object object : list) {
//			System.out.println(object);
//		 }
		
		//equal to in restriction
//		Criteria criteria = session.createCriteria(Person.class);
//		SimpleExpression eq = Restrictions.eq("personId", 5);
//		criteria.add(eq);
//		List list = criteria.list();
//	    list.stream().forEach(System.out::println);

		//greterequal to in restriction
//		Criteria criteria = session.createCriteria(Person.class);
//		SimpleExpression ge = Restrictions.ge("salary",10000.00);
//		criteria.add(ge);
//		List list = criteria.list();
//	    list.stream().forEach(System.out::println);

		
		
		//Criteria criteria = session.createCriteria(Person.class);
//		SimpleExpression eq = Restrictions.eq("name", "mukesh");
//		criteria.add(eq);
//		SimpleExpression ge = Restrictions.ge("salary", 10000.0);
//		criteria.add(ge);
//		 List list = criteria.list();
//		 list.stream().forEach(System.out::println);\
		
//		Criteria criteria = session.createCriteria(Person.class);
//		SimpleExpression eq = Restrictions.eq("name", "ram");
//		criteria.add(eq);
//		SimpleExpression ge = Restrictions.ge("salary", 25200.00);
//		criteria.add(ge);
//		criteria.addOrder(Order.desc("personId"));
//	     List list = criteria.list();
//		 list.stream().forEach(System.out::println);
		
//		Criteria criteria = session.createCriteria(Person.class);
//		SimpleExpression eq = Restrictions.eq("name", "deepak");
//		SimpleExpression ge = Restrictions.ge("salary",30000.0);
//		LogicalExpression or = Restrictions.or(eq, ge);
//		criteria.add(or);
//		criteria.addOrder(Order.desc("personID"));
//	     List list = criteria.list();
//		 list.stream().forEach(System.out::println);
		
		

		//Projection 
//		Criteria criteria = session.createCriteria(Person.class);
//		 PropertyProjection empName = Projections.property("name");
//		 criteria.setProjection(empName);
//		 List list = criteria.list();
//     	 list.stream().forEach(System.out::println);
		
		session.close();
				
	}
}
