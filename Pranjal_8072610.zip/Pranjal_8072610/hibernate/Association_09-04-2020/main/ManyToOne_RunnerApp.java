package com.virtusa.hibernate.main;

import java.util.ArrayList;

import org.hibernate.Session;

import com.virtusa.hibernate.manytoone.Person;
import com.virtusa.hibernate.manytoone.Property;
import com.virtusa.hibernate.operation.ManyToOne_Operation;

public class ManyToOne_RunnerApp {
	public static void main(String[] args) {
		Person person = new Person();
		ManyToOne_Operation operation = new ManyToOne_Operation();
		
		// save a data 
		Property property1 = new Property();
		Property property2 = new Property();
		
		person.setPersonName("lalbhadur");
		
		property1.setPropertyname("goaProperty");
		property1.setPerson(person);
		
		property2.setPropertyname("keralaProperty");
		property2.setPerson(person);		
		
		ArrayList<Property> propertyList = new ArrayList<Property>();
		propertyList.add(property1);
		propertyList.add(property2);
		
		//operation.insertDataIntoTable(propertyList);
		
		//update a delete
		//operation.updateDataOfTable(11);
		
		//retrive a data
		//operation.viewDataOfTable();
		
		//delete a data
		operation.deleteDataFormTable();
	}
}
