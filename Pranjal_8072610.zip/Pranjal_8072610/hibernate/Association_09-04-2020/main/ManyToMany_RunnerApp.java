package com.virtusa.hibernate.main;

import java.util.ArrayList;
import java.util.List;

import com.virtusa.hibernate.manytomany.UserDetail;
import com.virtusa.hibernate.manytomany.Vehicle;
import com.virtusa.hibernate.operation.ManyToMany_Operation;

public class ManyToMany_RunnerApp {

	public static void main(String[] args) {	
	ManyToMany_Operation operation = new ManyToMany_Operation();
	
	Vehicle vehicle1 = new Vehicle();
	vehicle1.setVehicleName("honda");
	
	Vehicle vehicle2 = new Vehicle();
	vehicle2.setVehicleName("Bmw");
	
	UserDetail user1 = new UserDetail();
	user1.setUserName("Vicky");
	
	UserDetail user2 = new UserDetail();
	user2.setUserName("Kaushal");
	
	List<Vehicle> vehicleList = new ArrayList<Vehicle>();
	vehicleList.add(vehicle1);
	vehicleList.add(vehicle2);
	
	user1.setVehicle(vehicleList);
	user2.setVehicle(vehicleList);
	
	List<UserDetail> userList = new ArrayList<UserDetail>();
	userList.add(user1);
	userList.add(user2);
	
	vehicle1.setUser(userList);
	vehicle2.setUser(userList);
	
	//operation.insertDataIntoTable(userList);
	//operation.updateDataOfTable(3);
//	operation.viewDataOfTable();
	operation.deleteDataFormTable();
	
	
	}
}
