package com.virtusa.hibernate.main;

import java.util.ArrayList;
import java.util.Collection;

import org.hibernate.Session;

import com.virtusa.hibernate.onetomany.User;
import com.virtusa.hibernate.onetomany.Vehicle;
import com.virtusa.hibernate.operation.OneToMany_Operation;

public class OneToMany_RunnerApp {

	public static void main(String[] args) {
		User user = new User();
		OneToMany_Operation operation = new OneToMany_Operation();
		Collection<Vehicle> vehicleList = new ArrayList<Vehicle>();
		
		Vehicle vehicle1 = new Vehicle();
		Vehicle vehicle2 = new Vehicle();
		
		vehicle1.setVehicleName("Honda");
		vehicle2.setVehicleName("Audi");
		vehicleList.add(vehicle1);
		vehicleList.add(vehicle2);
				
		user.setUserName("Chandu");
		user.setVehicle(vehicleList);
		
			//Session session= OneToMany_Operation.getSessionObject();	
			//session.close();
		
		//Save  a data
		//operation.saveData(user);
		
		// Update a data (userID,VehicleID)
		//operation.updateData(4,8);
		
		//delete a data 
		//operation.deleteData(4);
		
		// read data
		  operation.viewAllData();
	}
	
}
