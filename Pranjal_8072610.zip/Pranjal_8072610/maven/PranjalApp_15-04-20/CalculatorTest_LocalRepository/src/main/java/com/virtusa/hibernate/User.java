package com.virtusa.hibernate;

import com.virtusa.hibernate.Calculator;

public class User{
	public static void main(String... args)
	{	
		Calculator cal = new Calculator();
		System.out.println(cal.sum(2,5));
		System.out.println(cal.multiply(2,5));
	}
}