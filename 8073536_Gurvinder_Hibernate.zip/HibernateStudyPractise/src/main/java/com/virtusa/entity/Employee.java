package com.virtusa.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="Employee")
public class Employee {
	
	
	public Employee() {
		
	}
	@Id
	@Column(name="id")
	int id ;
	@Column(name="Name")
	String EmpName;
	@Column(name="Salary")
	double salary;
	@Column(name="address")
	String address;
	public void setId(int id) {
		this.id = id;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Employee(int id, String empName, double salary, String address) {
		super();
		this.id = id;
		EmpName = empName;
		this.salary = salary;
		this.address = address;
	}
	

	
}
