package com.hibernate;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CompositeKey implements Serializable {

	private Name name;
    private int mobile;
	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public CompositeKey(Name name, int mobile) {
		super();
		this.name = name;
		this.mobile = mobile;
	}
	public CompositeKey() {
		
	}
}
