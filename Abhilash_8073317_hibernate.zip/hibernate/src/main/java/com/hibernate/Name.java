package com.hibernate;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Embeddable
public class Name implements Serializable{
	
	private String firstName;
	private String middleName;
	private String laseName;
	
	public Name(String firstName, String middleName, String laseName) {
		super();
		this.firstName = firstName;
		this.middleName = middleName;
		this.laseName = laseName;
	}
	public Name() {
		
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLaseName() {
		return laseName;
	}
	public void setLaseName(String laseName) {
		this.laseName = laseName;
	}
	

}
