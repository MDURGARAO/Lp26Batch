package com.hibernate;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employeee {
    
	@Id
	private int empid;
	private double salary;
	private boolean isPemanent;
	private String name;
	private byte dept;
	private short shortt;
	private long longg;
	private float floatt;
	
	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public boolean isPemanent() {
		return isPemanent;
	}

	public void setPemanent(boolean isPemanent) {
		this.isPemanent = isPemanent;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public byte getDept() {
		return dept;
	}

	public void setDept(byte dept) {
		this.dept = dept;
	}

	public short getShortt() {
		return shortt;
	}

	public void setShortt(short shortt) {
		this.shortt = shortt;
	}

	public long getLongg() {
		return longg;
	}

	public void setLongg(long longg) {
		this.longg = longg;
	}

	public float getFloatt() {
		return floatt;
	}

	public void setFloatt(float floatt) {
		this.floatt = floatt;
	}

	

}
