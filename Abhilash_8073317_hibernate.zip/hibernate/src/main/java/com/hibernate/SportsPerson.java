package com.hibernate;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("sports_person")  
public class SportsPerson extends Person {
	
	private String sport;
	private String teamName;
	public SportsPerson(String sport, String teamName) {
		super();
		this.sport = sport;
		this.teamName = teamName;
	}
	
	public SportsPerson() {
		
	}

	public String getSport() {
		return sport;
	}

	public void setSport(String sport) {
		this.sport = sport;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	
	

}
