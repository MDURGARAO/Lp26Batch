package com.hibernate;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name = "person")
@SecondaryTable(name = "address")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type" ,discriminatorType= DiscriminatorType.STRING)
@DiscriminatorValue(value = "person")
public class Person {
	
	//@Id
	@GeneratedValue
	private int personId;
	//@Column(table = "address")
	@Id
	private CompositeKey key;
	private int age;
	@Column(table = "address")
	private String colony;
	@Column(table = "address")
	private String city;
	@Column(table = "address")
	private String state;
	@Column(table = "address")
	private String country;
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

	public int getPersonId() {
		return personId;
	}
	public void setPersonId(int personId) {
		this.personId = personId;
	}
	@Column(table = "address")
	public String getColony() {
		return colony;
	}
	public void setColony(String colony) {
		this.colony = colony;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	
	public CompositeKey getKey() {
		return key;
	}
	public void setKey(CompositeKey key) {
		this.key = key;
	}
	public Person(int personId, CompositeKey key, int age, String colony, String city, String state, String country) {
		super();
		this.personId = personId;
		this.key = key;
		this.age = age;
		this.colony = colony;
		this.city = city;
		this.state = state;
		this.country = country;
	}
	public Person() {
		
	}
	
	
	

}
