package com.hibernate;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("employee")  
public class Employee extends Person {
	
	private int salary;
	private int experience;
	private String role;
	
	public  Employee() {
		
	}
	
	
	
	
	public Employee(int personId, CompositeKey key, int age, String colony, String city, String state, String country) {
		super(personId, key, age, colony, city, state, country);
		// TODO Auto-generated constructor stub
	}




	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	

}
