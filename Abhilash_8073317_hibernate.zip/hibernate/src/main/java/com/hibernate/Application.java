package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Application {

	public static void main(String[] args) {
		
	    Person person = new Person(1, new CompositeKey(new Name("Neil", "Nitin", "Mukesh"), 1212121212), 25, "krishna", "chennai", "Tamil Nadu", "India");
	    Employee employee = new Employee(2, new CompositeKey(new Name("Om", "Jai", "Jagadesh"), 1212121213), 22, "MG", "Bangalore", "karnataka", "India");
	    employee.setExperience(6);
	    employee.setSalary(30000);
	    employee.setRole("Dev");
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory = configuration.buildSessionFactory();
		Session session = buildSessionFactory.openSession();
		Transaction beginTransaction = session.beginTransaction();
		session.save(person);
		session.save(employee);
		beginTransaction.commit();
		session.close();
		

	}

}
