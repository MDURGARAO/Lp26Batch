package com.hibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Test1 {

	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory = configuration.buildSessionFactory();
		Session session = buildSessionFactory.openSession();
		Transaction beginTransaction = session.beginTransaction();
//		for (int i = 0;i<10;i++) {
//			Employeee employeee = new Employeee(i, 200000+i, "bill"+i, (byte) i);
//			session.save(employeee);
//		}
		//session.update(new Employeee(103, 1000, "cill", (byte) 30));
//      Query query = session.createQuery("from Employee");
//		Query query = session.createQuery("select new Employeee(salary,name) from Employeee");
//		Query query = session.createQuery("select salary,name from Employeee");
//		Query query = session.createQuery("update Employeee set name = 'Abhi' where empid = 1");
//		query.executeUpdate();
//		Query query = session.createQuery("delete from Employeee where empid=0");
//		query.executeUpdate();
		Query query = session.createQuery("delete from Employeee where empid=:a");
		query.setInteger("a", 3);
		query.executeUpdate();
//		query.setFirstResult(5);
//		query.setMaxResults(3);
//		List<Employeee> list = query.list();
//		for(Employeee l : list) {
//			System.out.println(l);
		//list.forEach(System.out::println);
	
		beginTransaction.commit();
		session.close();
		
	}

	}
	
