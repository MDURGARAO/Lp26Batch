package com.virtusa.spring.casestudy;

import java.util.List;

public class Order {
private int noOfProducts;
private double orderTotal;
private List<Product> products;
@Override
public String toString() {
	return "Order [noOfProducts=" + noOfProducts + ", orderTotal=" + orderTotal + ", products=" + products + "]";
}
public Order() {
}
public int getNoOfProducts() {
	return noOfProducts;
}
public void setNoOfProducts(int noOfProducts) {
	this.noOfProducts = noOfProducts;
}
public double getOrderTotal() {
	return orderTotal;
}
public void setOrderTotal(double orderTotal) {
	this.orderTotal = orderTotal;
}
public List<Product> getProducts() {
	return products;
}
public void setProducts(List<Product> products) {
	this.products = products;
}
public Order(int noOfProducts, double orderTotal, List<Product> products) {
	this.noOfProducts = noOfProducts;
	this.orderTotal = orderTotal;
	this.products = products;
}

}
