package com.virtusa.spring.casestudy;

public class UserBean extends PersonBean {
	private String email;
	private String password;
	private Order order;
	public  void logIn(String email,String password)
	{
		System.out.println("logged in with "+email);
		System.out.println("logged in with "+password);

	}
	
	
	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "User [email=" + email + ", password=" + password + "]";
	}
	public UserBean(String email, String password , Order order) {
		this.email = email;
		this.password = password;
		this.order = order;
	}
	public UserBean() {
	}


	public Order getOrder() {
		return order;
	}


	public void setOrder(Order order) {
		this.order = order;
	}
	
}
