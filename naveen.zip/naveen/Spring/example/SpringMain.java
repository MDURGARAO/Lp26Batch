package com.virtusa.spring.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.virtusa.spring.core.ApplicantBean;

public class SpringMain {
@SuppressWarnings("resource")
public static void main(String[] args) {
	ApplicationContext context = new ClassPathXmlApplicationContext("spring-core-config.xml");
	ApplicantBean applicantBean = (ApplicantBean)context.getBean(ApplicantBean.class);
	//System.out.println(applicantBean1==applicantBean);
	System.out.println(applicantBean);
	System.out.println(applicantBean.getNoOfMessages());
	System.out.println(applicantBean.getMessage());
	System.out.println(applicantBean.getNumberList());
	System.out.println(applicantBean.getStrMessages());
	System.out.println(applicantBean.getFirstName());
	System.out.println(applicantBean.getLastName());
	System.out.println(applicantBean.getMiddleName());
	System.out.println(applicantBean.getAddress());
}
}
