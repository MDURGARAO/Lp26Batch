package com.virtusa.spring.validate;


import org.springframework.core.io.Resource;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

public class UserValidator implements Validator{
	private Resource location;
	

	@Override
	public boolean supports(Class clazz) {
		return UserBean.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,"email", "errormsg.email","Email should not be empty or whitespace");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password","errormsg.password", "password should not be empty or whitespace");
		
	
	}

	public Resource getLocation() {
		return location;
	}

	public void setLocation(Resource location) {
		this.location = location;
	}

}
