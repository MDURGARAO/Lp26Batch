package com.virtusa.spring.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class UserDAOImpl implements UserDAO{

	private JdbcTemplate jdbcTemplate;


	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void insert(User user) {
		String sql = "INSERT INTO User " +
				"(email,password,firstName,lastName,middleName) VALUES (?, ?, ?, ?, ?)";
		jdbcTemplate.update(sql, new Object[] { user.getEmail(),user.getPassword(),user.getFirstName(),
				user.getLastName(), user.getMiddleName() });


	}

	@SuppressWarnings("rawtypes")
	@Override
	public List<User> findAll() {

		String sql = "SELECT * FROM user";

		List<User> users = new ArrayList<User>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
		for (Map row : rows) {
			User user = new User();
			user.setEmail((String)row.get("email"));
			user.setPassword((String)row.get("password"));
			user.setFirstName((String)row.get("firstName"));
			user.setLastName((String)row.get("lastName"));
			user.setMiddleName((String)row.get("middleName"));
			users.add(user);
		}

		return users;
	}  

	public List<User> getAllEmployeesRowMapper(){  
		return jdbcTemplate.query("select * from User",new RowMapper<User>(){  
			@Override  
			public User mapRow(ResultSet resultSet, int rownumber) throws SQLException {  
				User user=new User();  
				user.setEmail(resultSet.getString(1));  
				user.setPassword(resultSet.getString(2));  
				user.setFirstName(resultSet.getString(3));  
				return user;  
			}  
		});
	}

		public String findPasswordByEmail(String email){

			String sql = "SELECT password FROM user WHERE email = ?";

			String password = (String)jdbcTemplate.queryForObject(
					sql, new Object[] { email }, String.class);

			return password;
		}
		public int updateUser(String email , String password){  
			String sql="update user set Password = password where Email = email";
			return jdbcTemplate.update(sql);  
		}  
		public int deleteUser(String email){  
			String sql ="delete from user where Email = email";  
			return jdbcTemplate.update(sql);  
		}  
	} 

