package com.virtusa.spring.jdbc;

import java.util.List;

public interface UserDAO {
void insert(User user);
String findPasswordByEmail(String email);
List<User> findAll();
public List<User> getAllEmployeesRowMapper();
public int updateUser(String email , String password);
public int deleteUser(String email);

}
