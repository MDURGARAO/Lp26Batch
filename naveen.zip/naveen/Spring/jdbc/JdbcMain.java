package com.virtusa.spring.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.jdbc.User;
import com.virtusa.spring.jdbc.UserDAO;
import com.virtusa.spring.jdbc.UserDAOImpl;

public class JdbcMain {
	@SuppressWarnings({"resource" })
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-config-core3.xml");
		UserDAO userDAO = (UserDAO) context.getBean(UserDAOImpl.class);
		User user = (User) context.getBean(User.class);
		//userDAO.insert(user);      

		//userDAO.insert(user);
		List<User> users = userDAO.getAllEmployeesRowMapper();
		for(User u : users)
		{
			System.out.println(u.getEmail()+"  "+u.getPassword());

		}
		System.out.println(userDAO.findAll());
		// 		System.out.println(userDAO.updateUser("naveen@vrtusa.com","navin"));
		//		System.out.println(userDAO.deleteUser("navin@vrtusa.com"));
	}
}
