package com.virtusa.spring.Annotations;

public interface Person {
void getDetails();
}
