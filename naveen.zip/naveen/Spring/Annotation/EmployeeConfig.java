package com.virtusa.spring.Annotations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EmployeeConfig {
@Bean
public EmployeeBean employeeBean()
{
	return new EmployeeBean(45,"Human Resource","naveen@yahoo.com");
}

@Bean
public Address address()
{
	Address address = new Address();
	address.setCity("Hyd");
	address.setCountry("india");
	address.setPincode(517658);
	address.setDoorNo("1-3-456");
	return address;
}
}
