package com.virtusa.hibernate.manytoone;

import org.hibernate.cfg.Configuration;

public class OrderMain {
	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		configuration.buildSessionFactory();
}
}
