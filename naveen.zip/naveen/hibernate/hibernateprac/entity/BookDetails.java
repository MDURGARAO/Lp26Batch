package com.virtusa.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
@Embeddable
public class BookDetails {
	@Column(table = "bookDetails")
private String description;
	@Column(table = "bookDetails")
private String title;
	@Column(table = "bookDetails")
private int noOfPages;

public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public int getNoOfPages() {
	return noOfPages;
}
public void setNoOfPages(int noOfPages) {
	this.noOfPages = noOfPages;
}
public String getCategory() {
	return category;
}
public BookDetails() {
}
public void setCategory(String category) {
	this.category = category;
}
private String category;
}
