package com.virtusa.hibernate.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Officer extends Person{
	@Id
private int officerId;
public int getOfficerId() {
		return officerId;
	}
	public Officer() {
	super();
}
	public void setOfficerId(int officerId) {
		this.officerId = officerId;
	}
private double salary;
private String department;
private float absence;
private Date hireDate;
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public float getAbsence() {
	return absence;
}
public void setAbsence(float absence) {
	this.absence = absence;
}
public Date getHireDate() {
	return hireDate;
}
public void setHireDate(Date hireDate) {
	this.hireDate = hireDate;
}
}
