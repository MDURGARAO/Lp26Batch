package com.virtusa.hibernate.entity;

import java.io.*;
import java.math.*;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "hibemployee")
public class Employee {
@Id
@Column(name="empId")
private int employeeId;
public Employee(int employeeId, long mobileNumber, double salary, String employeeName, String address,
		char gender)
{
	this.employeeId = employeeId;
	this.mobileNumber = mobileNumber;
	this.salary = salary;
	this.employeeName = employeeName;
	this.address = address;
	this.gender = gender;
}
@Column(length=10)
private long mobileNumber;
private double salary;
@Column(length = 36 , nullable = false)
private String employeeName;
@Embedded
private Address address;
private boolean medicallyFit;
private Date hireDate;
private File resume;
private int[] marks;
private char gender;
private BigDecimal annualIncome;
//private List<String> subjectlist;
@Column(length = 99)
private char[] skills;

public boolean isMedicallyFit() {
	return medicallyFit;
}
public void setMedicallyFit(boolean medicallyFit) {
	this.medicallyFit = medicallyFit;
}
public Date getHireDate() {
	return hireDate;
}
public void setHireDate(Date hireDate) {
	this.hireDate = hireDate;
}
public File getResume() {
	return resume;
}
public void setResume(File resume) {
	this.resume = resume;
}
public int[] getMarks() {
	return marks;
}
public void setMarks(int[] marks) {
	this.marks = marks;
}
public char getGender() {
	return gender;
}
public void setGender(char gender) {
	this.gender = gender;
}
//public List<String> getSubjectlist() {
//	return subjectlist;
//}
//public void setSubjectlist(List<String> subjectlist) {
//	this.subjectlist = subjectlist;
//}
public char[] getSkills() {
	return skills;
}
public void setSkills(char[] skills) {
	this.skills = skills;
}
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public Employee() {
}
public long getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(long mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public BigDecimal getAnnualIncome() {
	return annualIncome;
}
public void setAnnualIncome(BigDecimal annualIncome) {
	this.annualIncome = annualIncome;
}

}
