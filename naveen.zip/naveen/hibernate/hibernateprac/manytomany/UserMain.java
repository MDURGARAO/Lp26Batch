package com.virtusa.hibernate.manytomany;

import org.hibernate.cfg.Configuration;

public class UserMain {
	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		configuration.buildSessionFactory();
	}
}
