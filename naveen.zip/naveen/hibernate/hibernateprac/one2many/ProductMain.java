package com.virtusa.hibernate.one2many;

import org.hibernate.cfg.Configuration;

public class ProductMain {
public static void main(String[] args) {
	Configuration configuration = new Configuration();
	configuration.configure();
	configuration.buildSessionFactory();
}
}
