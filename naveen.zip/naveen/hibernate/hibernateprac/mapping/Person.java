package com.virtusa.hibernate.mapping;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name=  "person")
public class Person {
	@Id
	private String AadharId;
	private String lastName;
	private String firstName;
//	@OneToOne
//	private Employee employee;
	public Person() {
	}

	public Person(String aadharId, String lastName, String firstName) {
		super();
		AadharId = aadharId;
		this.lastName = lastName;
		this.firstName = firstName;
	}

	public String getAadharId() {
		return AadharId;
	}
	public void setAadharId(String aadharId) {
		AadharId = aadharId;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

}
