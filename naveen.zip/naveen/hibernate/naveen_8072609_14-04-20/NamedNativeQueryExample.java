package com.virtusa.hibernate.hql;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class NamedNativeQueryExample {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		List<ProductList> products = session.getNamedNativeQuery("get_all_productlist").list();
		List<Object[]> productList = session.getNamedNativeQuery("get_all_namesprices").list();

		for(ProductList product : products)
			System.out.println(product.getId()+  "  " + product.getName() +" "+ product.getPrice());

		for(Object[] product : productList)
			System.out.println(product[0]+  "  " + product[1] );




		session.close();
	}

}
