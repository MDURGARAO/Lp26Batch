package com.virtusa.hibernate.hql;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.PropertyProjection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;


public class CriteriaMain {
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {

		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(ProductList.class);
//		Criteria categoryCriteria = criteria.createCriteria("category");
//		SimpleExpression expression = Restrictions.eq("price",24000);
//		SimpleExpression expression1 = Restrictions.le("price",24000);
//		SimpleExpression expression2 = Restrictions.gt("price",24000);
//		SimpleExpression expression3 = Restrictions.like("name", "L%", MatchMode.ANYWHERE);
//		SimpleExpression expression4 = Restrictions.isNull("name");
//		LogicalExpression orExp = Restrictions.or(expression,expression3);
//		LogicalExpression andExp = Restrictions.and(expression,expression3);
//		PropertyProjection property = Projections.property("id");
		ProjectionList propertyList = Projections.projectionList();
		propertyList.add(Projections.property("id")).add(Projections.property("name")).add(Projections.property("price"));
//		criteria.add(expression);
//		criteria.add(expression1);
//		criteria.add(expression2);
//		criteria.add(expression3);
//		criteria.add(expression4);
//		criteria.add(orExp);
//		criteria.add(andExp);


		
		
		criteria.setProjection(propertyList);
//		criteria.setProjection(property);
		criteria.addOrder(Order.asc("price"));
		criteria.addOrder(Order.desc("price"));
		criteria.setFirstResult(0);
		criteria.setMaxResults(10);
//		List<ProductList> productList   = criteria.list();
//		productList.forEach(System.out::println);

		List<Object[]> productObjectList   = criteria.list();
		for(Object[] product : productObjectList)
			System.out.println(product[0]+" "+product[1]+" "+product[2]+" ");
		session.close();

	}
}
