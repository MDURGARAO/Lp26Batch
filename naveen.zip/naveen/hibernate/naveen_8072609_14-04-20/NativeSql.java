package com.virtusa.hibernate.hql;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class NativeSql {
	public static void main(String[] args) {

		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		//		List<Object[]> productList= session.createNativeQuery("select * from productlist").getResultList();
		//		List<ProductList> products = session.createNativeQuery("select * from productlist",ProductList.class).list();
		List<Object[]> productList= session.createNativeQuery("select * from productlist where price >= :price")
				.setParameter("price", 14000).list();

		for(Object[] product : productList)
			System.out.println(product[0]+  "  " + product[1] +" "+ product[2]);
		//		for(ProductList product : products)
		//			System.out.println(product.getId()+  "  " + product.getName() +" "+ product.getPrice());
		//			
		session.close();
	}
}