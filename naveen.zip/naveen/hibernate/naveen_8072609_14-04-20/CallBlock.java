package com.virtusa.hibernate.hql;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.NativeQuery;

public class CallBlock {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();

		List<ProductList> list1 = session.createSQLQuery(
				"CALL GetAllDetailsOfProduct(:id)")
				.addEntity(ProductList.class)
				.setParameter("id",5).getResultList();

		List<ProductList> list = session.createSQLQuery(
				"CALL GetAllDetailsOfProductsgreaterThan(:price)")
				.addEntity(ProductList.class)
				.setParameter("price",15000).list();


		for(ProductList product : list)
			System.out.println(product.getId()+  "  " + product.getName() +" "+ product.getPrice());

		for(ProductList product : list1)
			System.out.println(product.getId()+  "  " + product.getName() +" "+ product.getPrice());



		session.close();
	}
}
