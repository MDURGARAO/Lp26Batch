package com.shubham.nativeSql;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CarList")
public class CarList {
	@Id
	@GeneratedValue
	@Column(name="carId")
	private long id;
	
	@Column(name="purchaseDate",columnDefinition="date")
	private Date purchaseDate;
	
	@Column(name="modelName")
	private String modelName;
	
	@Column(name="modelType")
	private String mType;
	
	@Column(name="engineType")
	private String eType;
	
	@Column(name="gearType")
	private String gType;

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getmType() {
		return mType;
	}

	public void setmType(String mType) {
		this.mType = mType;
	}

	public String geteType() {
		return eType;
	}

	public void seteType(String eType) {
		this.eType = eType;
	}

	public String getgType() {
		return gType;
	}

	public void setgType(String gType) {
		this.gType = gType;
	}

	public CarList(Date purchaseDate, String modelName, String mType, String eType, String gType) {
		super();
		this.purchaseDate = purchaseDate;
		this.modelName = modelName;
		this.mType = mType;
		this.eType = eType;
		this.gType = gType;
	}

	public CarList() {
	}
	
	@Override
	public String toString() {
		return "CarList [id=" + id + ", purchaseDate=" + purchaseDate + ", modelName=" + modelName + ", mType=" + mType
				+ ", eType=" + eType + ", gType=" + gType + "]";
	}
	
	
}
