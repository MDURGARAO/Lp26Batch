package com.virtusa.spring.bean;

public class Card extends Payment{
	
	private String cardType;

	public Card(String cardType) {
		super();
		this.cardType = cardType;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	@Override
	public String toString() {
		return "Card [cardType=" + cardType + "]";
	}

}
