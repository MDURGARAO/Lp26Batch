package com.virtusa.spring.bean;

public class Cheque extends Payment {
	
	private String chequeType;

	public String getChequeType() {
		return chequeType;
	}

	public void setChequeType(String chequeType) {
		this.chequeType = chequeType;
	}

	@Override
	public String toString() {
		return "Cheque [chequeType=" + chequeType + "]";
	}

}
