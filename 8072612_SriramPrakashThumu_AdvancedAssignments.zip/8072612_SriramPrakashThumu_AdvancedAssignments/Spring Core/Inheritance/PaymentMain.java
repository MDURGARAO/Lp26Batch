package com.virtusa.spring.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.bean.Card;
import com.virtusa.spring.bean.Cheque;

public class PaymentMain {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("spring-core-config.xml");
		
		Card card = context.getBean(Card.class, "card");
		System.out.println(card.getPaymentId());
		System.out.println(card.getAmount());
		System.out.println(card.getCardType());
		
		System.out.println();
		
		Cheque cheque = context.getBean(Cheque.class,"cheque");
		System.out.println(cheque.getPaymentId());
		System.out.println(cheque.getAmount());
		System.out.println(cheque.getChequeType());
		
	

	}

}
