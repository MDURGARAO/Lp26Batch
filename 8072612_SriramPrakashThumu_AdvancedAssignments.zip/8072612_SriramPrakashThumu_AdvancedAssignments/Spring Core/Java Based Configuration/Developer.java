package com.virtusa.spring.bean;

public class Developer {

	private int developerId;
	private String name;
	private String email;

	public int getDeveloperId() {
		return developerId;
	}

	public void setDeveloperId(int developerId) {
		this.developerId = developerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Developer [developerId=" + developerId + ", name=" + name + ", email=" + email + "]";
	}

}
