package com.virtusa.spring.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.virtusa.spring.bean.Developer;

@Configuration
public class DeveloperConfig {
	
	@Bean
	public Developer developer() {
		return new Developer();
	}

}
