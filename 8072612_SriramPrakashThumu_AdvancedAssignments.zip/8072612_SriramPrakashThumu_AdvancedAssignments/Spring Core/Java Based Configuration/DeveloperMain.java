package com.virtusa.spring.config;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.virtusa.spring.bean.Developer;

public class DeveloperMain {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(DeveloperConfig.class);
		Developer developer = context.getBean(Developer.class,"developer");
		
		developer.setDeveloperId(102);
		developer.setName("SriramPrakash");
		developer.setEmail("sriramprakash@gmail.com");
		
		
		System.out.println(developer.toString());
		

	}

}
