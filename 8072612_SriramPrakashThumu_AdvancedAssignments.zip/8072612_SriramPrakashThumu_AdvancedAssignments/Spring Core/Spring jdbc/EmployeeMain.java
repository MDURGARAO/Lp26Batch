package com.virtusa.spring.client;

import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.bean.Employee;
import com.virtusa.spring.dao.EmployeeDAO;

public class EmployeeMain {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("employee-config.xml");

		Employee employee1 = (Employee) context.getBean("employee1");
		
		Employee employee2 = (Employee) context.getBean("employee2");

		EmployeeDAO dao = context.getBean(EmployeeDAO.class, "employeeDAO");

		dao.createEmployee();

		int insertStatus = dao.saveEmployee(employee1);
		System.out.println(insertStatus);
		
		dao.saveEmployee(employee2);
		
		List<Map<String,Object>> list = dao.getList();
		
		for(Map<String,Object> map : list) {
			System.out.println(map.toString());
		}

//		int updateStatus = dao.updateEmployee(employee2);
//		System.out.println(updateStatus);
//		
//		int deleteStatus = dao.deleteEmployee(employee2);
//		System.out.println(deleteStatus);

	}

}
