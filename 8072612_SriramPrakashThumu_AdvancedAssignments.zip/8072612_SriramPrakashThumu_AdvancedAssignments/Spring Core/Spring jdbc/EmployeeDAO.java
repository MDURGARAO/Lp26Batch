package com.virtusa.spring.dao;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.virtusa.spring.bean.Employee;

public class EmployeeDAO {

	private JdbcTemplate jdbcTemplate;

	public List<Map<String, Object>> getList() {
		return jdbcTemplate.queryForList("select * from employees");
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void createEmployee() {
		String query = "create table employees(empId integer,empName varchar(50),salary double(7,2), constraint employees_pk  primary key(empId))";
		jdbcTemplate.execute(query);
	}

	public int saveEmployee(Employee e) {
		String query = "insert into employees values('" + e.getEmpId() + "','" + e.getEmpName() + "','" + e.getSalary()
				+ "')";
		return jdbcTemplate.update(query);
	}

	public int updateEmployee(Employee e) {
		String query = "update employees set empName='" + e.getEmpName() + "',salary='" + e.getSalary()
				+ "' where empId='" + e.getEmpId() + "' ";
		return jdbcTemplate.update(query);
	}

	public int deleteEmployee(Employee e) {
		String query = "delete from employees where empId='" + e.getEmpId() + "' ";
		return jdbcTemplate.update(query);
	}

}
