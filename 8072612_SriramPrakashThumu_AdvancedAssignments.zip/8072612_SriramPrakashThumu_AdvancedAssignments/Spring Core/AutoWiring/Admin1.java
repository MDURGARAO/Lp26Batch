package com.virtusa.spring.bean;

public class Admin1 {
	
	Admin1() {
		System.out.println("Admin1 is created");
	}
	
	void print() {
		System.out.println("Hi,Admin1");
	}

}
