package com.virtusa.spring.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.bean.Admin2;

public class AdminMain {
	
	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("autowiring.config.xml");
		Admin2 admin2 = context.getBean(Admin2.class,"admin2");
		admin2.display();
	}

}
	