package com.virtusa.spring.bean;

public class Admin2 {
	
	Admin1 admin1;

	Admin2() {
		super();
		System.out.println("Admin2 is created");
	}

	public Admin1 getAdmin1() {
		return admin1;
	}

	public void setAdmin1(Admin1 admin1) {
		this.admin1 = admin1;
	}
	
	void print() {
		System.out.println("Hi,Admin2");
	}
	
	public void display() {
		print();
		admin1.print();
	}

}
