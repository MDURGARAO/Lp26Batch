package com.virtusa.spring.client;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.ObjectError;

import com.virtusa.spring.bean.Person;
import com.virtusa.spring.validation.PersonValidator;

public class PersonMain {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("person-config.xml");
		Person person = context.getBean(Person.class,"person");
		
		PersonValidator personValidation = context.getBean(PersonValidator.class,"personValidator");
		
		Map<String,String> map = new HashMap<>();
		
		MapBindingResult err = new MapBindingResult(map,Person.class.toString());
		
		personValidation.validate(person, err);
		List<ObjectError> list = err.getAllErrors();
		
		for(ObjectError objErr:list) {
			System.out.println(objErr.getDefaultMessage());
		}

	}

}
