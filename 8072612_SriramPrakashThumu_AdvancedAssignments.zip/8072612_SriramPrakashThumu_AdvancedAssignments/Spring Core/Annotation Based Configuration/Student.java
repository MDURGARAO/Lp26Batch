package com.virtusa.spring.bean;

import org.springframework.beans.factory.annotation.Required;

public class Student {
	
	private int studentId;
	private String studentName;
	
	public int getStudentId() {
		return studentId;
	}
	@Required
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	@Required
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + "]";
	}

}
