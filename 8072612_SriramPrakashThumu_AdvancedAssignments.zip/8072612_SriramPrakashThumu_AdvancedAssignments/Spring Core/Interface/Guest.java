package com.virtusa.spring.bean;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Guest implements GuestI {

	private int guestId;
	private String name;
	private String[] projectsList;
	private List<Address> addressList;
	private Set<Long> phoneNos;
	private Map<Integer,String> debitCards;
	
	public int getGuestId() {
		return guestId;
	}
	public void setGuestId(int guestId) {
		this.guestId = guestId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String[] getProjectsList() {
		return projectsList;
	}
	public void setProjectsList(String[] projectsList) {
		this.projectsList = projectsList;
	}
	public List<Address> getAddressList() {
		return addressList;
	}
	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}
	public Set<Long> getPhoneNos() {
		return phoneNos;
	}
	public void setPhoneNos(Set<Long> phoneNos) {
		this.phoneNos = phoneNos;
	}
	public Map<Integer, String> getDebitCards() {
		return debitCards;
	}
	public void setDebitCards(Map<Integer, String> debitCards) {
		this.debitCards = debitCards;
	}
	
	public void display() {
		System.out.println("hi");
		
	}
	
	@Override
	public String toString() {
		return "Guest [guestId=" + guestId + ", name=" + name + ", projectsList=" + Arrays.toString(projectsList)
				+ ", addressList=" + addressList + ", phoneNos=" + phoneNos + ", debitCards=" + debitCards + "]";
	}	

}
