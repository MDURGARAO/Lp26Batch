package com.virtusa.spring.bean;

public interface GuestI {
	
	public void display();

}
