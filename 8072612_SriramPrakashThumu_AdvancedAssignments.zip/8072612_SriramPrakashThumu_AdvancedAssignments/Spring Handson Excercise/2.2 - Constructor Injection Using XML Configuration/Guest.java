package com.virtusa.spring.bean;

import java.util.List;

public class Guest {

	private int guestId;
	private String guestName;
	private String email;
	private String password;
	private List<Address> addressList;

	public Guest(int guestId, String guestName, String email, String password, List<Address> addressList) {
		super();
		this.guestId = guestId;
		this.guestName = guestName;
		this.email = email;
		this.password = password;
		this.addressList = addressList;
	}

	@Override
	public String toString() {
		return "Guest [guestId=" + guestId + ", guestName=" + guestName + ", email=" + email + ", password=" + password
				+ ", addressList=" + addressList + "]";
	}

}
