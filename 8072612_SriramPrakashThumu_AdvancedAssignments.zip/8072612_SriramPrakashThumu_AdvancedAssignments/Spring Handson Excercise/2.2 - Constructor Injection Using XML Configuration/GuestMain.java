package com.virtusa.spring.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.bean.Guest;

public class GuestMain {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("guest-core-config.xml");

		Guest guest = (Guest) context.getBean("guest");

		System.out.println(guest.toString());
	}

}
