package com.virtusa.spring.bean;

public class Address {

	private String dNo;
	private String street;
	private String district;
	private String state;
	private int pincode;

	public Address(String dNo, String street, String district, String state, int pincode) {
		super();
		this.dNo = dNo;
		this.street = street;
		this.district = district;
		this.state = state;
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [dNo=" + dNo + ", street=" + street + ", district=" + district + ", state=" + state
				+ ", pincode=" + pincode + "]";
	}

}
