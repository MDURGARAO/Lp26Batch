package com.virtusa.spring.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class StudentInformation {

	@Autowired
	@Qualifier("student2")
	private Student student;

	public StudentInformation() {
		super();
	}
	
	public void printInformation() {
		System.out.println(student.toString());
	}

}
