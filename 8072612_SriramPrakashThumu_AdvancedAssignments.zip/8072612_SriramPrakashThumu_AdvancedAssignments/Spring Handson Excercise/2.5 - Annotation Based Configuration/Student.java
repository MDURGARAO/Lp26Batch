package com.virtusa.spring.bean;


import org.springframework.beans.factory.annotation.Required;

public class Student {
	
	private int studentId;
	private String studentName;
	private long phoneNo;

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public long getPhoneNo() {
		return phoneNo;
	}
	@Required
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", phoneNo=" + phoneNo + "]";
	}

}
