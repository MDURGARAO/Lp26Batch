package com.virtusa.spring.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.bean.StudentInformation;

public class StudentMain {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("student-config.xml");
		
		StudentInformation studentInformation = (StudentInformation) context.getBean("studentInformation");
		
		studentInformation.printInformation();
	}

}
