package com.virtusa.spring.client;

import java.util.LinkedList;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.virtusa.spring.bean.Address;
import com.virtusa.spring.bean.Guest;
import com.virtusa.spring.config.AddressConfig;
import com.virtusa.spring.config.GuestConfig;

public class GuestMain {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(GuestConfig.class);

		Guest guest = context.getBean(Guest.class, "guest");

		System.out.println(guest.toString());

		context.registerShutdownHook();
	}

	public List<Address> getAddressList() {

		List<Address> addressList = new LinkedList<>();

		AnnotationConfigApplicationContext context2 = new AnnotationConfigApplicationContext(AddressConfig.class);

		Address address1 = (Address) context2.getBean("address1");

		Address address2 = (Address) context2.getBean("address2");

		addressList.add(address1);
		addressList.add(address2);

		return addressList;

	}

}
