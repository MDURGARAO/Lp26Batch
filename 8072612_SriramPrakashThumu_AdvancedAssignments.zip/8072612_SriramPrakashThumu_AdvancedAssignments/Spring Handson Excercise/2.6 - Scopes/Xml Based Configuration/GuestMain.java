package com.virtusa.spring.client;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.bean.Guest;

public class GuestMain {

	public static void main(String[] args) {

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("guest-config.xml");

		Guest guest = context.getBean(Guest.class, "guest");

		System.out.println(guest.toString());

		context.registerShutdownHook();
	}

}
