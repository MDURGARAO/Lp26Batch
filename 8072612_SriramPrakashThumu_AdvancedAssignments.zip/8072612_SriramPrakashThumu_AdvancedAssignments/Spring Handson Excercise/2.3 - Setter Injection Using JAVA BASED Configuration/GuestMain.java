package com.virtusa.spring.client;

import java.util.LinkedList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.bean.Address;
import com.virtusa.spring.bean.Guest;
import com.virtusa.spring.config.AddressConfig;
import com.virtusa.spring.config.GuestConfig;

public class GuestMain {

	public static void main(String[] args) {
		
		List<Address> addressList = new LinkedList<>();

		AnnotationConfigApplicationContext context1 = new AnnotationConfigApplicationContext(GuestConfig.class);
		AnnotationConfigApplicationContext context2 = new AnnotationConfigApplicationContext(AddressConfig.class);

		Guest guest = context1.getBean(Guest.class,"guest");
		
		Address address1 = (Address) context2.getBean("address1");
		
		address1.setdNo("6-456");
		address1.setStreet("Porur");
		address1.setDistrict("Chennai");
		address1.setState("TamilNadu");
		address1.setPincode(600089);
		
		addressList.add(address1);
		
		Address address2 = (Address) context2.getBean("address2");
		
		address2.setdNo("6-875");
		address2.setStreet("Panjagutta");
		address2.setDistrict("Hyderabad");
		address2.setState("Telangana");
		address2.setPincode(500082);
		
		
		addressList.add(address2);
		
		
		guest.setGuestId(101);
		guest.setGuestName("Prakash");
		guest.setEmail("prakash@gmail.com");
		guest.setPassword("prakash123");
		guest.setAddressList(addressList);

		System.out.println(guest.toString());
	}

	

}
