package com.virtusa.spring.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.virtusa.spring.bean.Guest;

@Configuration
public class GuestConfig {
	
	@Bean
	public Guest guest() {
		return new Guest();
	}

}
