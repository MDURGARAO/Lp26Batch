package com.virtusa.spring.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.virtusa.spring.bean.Address;
import com.virtusa.spring.bean.Guest;
import com.virtusa.spring.client.GuestMain;

@Configuration
public class GuestConfig {

	GuestMain guestMain = new GuestMain();

	@Bean
	public Guest guest() {

		List<Address> addressList = guestMain.getAddressList();

		return new Guest(101, "Sriram", "sriram@gmail.com", "sriram123", addressList);
	}

}
