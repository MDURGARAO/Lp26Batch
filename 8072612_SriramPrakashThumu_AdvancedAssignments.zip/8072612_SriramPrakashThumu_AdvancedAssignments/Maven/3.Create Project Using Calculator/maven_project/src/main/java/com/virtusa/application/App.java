package com.virtusa.application;
import com.virtusa.app.CalculatorOperations;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
	System.out.println("Two numbers are 20 & 10");
	CalculatorOperations calculator = new CalculatorOperations();
	System.out.println("Sum of two no's is: " + calculator.add(20,10));
	System.out.println("Difference of two no's is: " + calculator.substract(20,10));
	System.out.println("Product of two no's is: " + calculator.multiply(20,10));
	System.out.println("Division of two no's is: " + calculator.divide(20,10));
    }
}
