package com.virtusa.app;

public class CalculatorOperations {

	public int add(int a,int b){
		return a + b;
	}

	public int substract(int a,int b){
		return a - b;
	}

	public int multiply(int a,int b){
		return a * b;
	}

	public double divide(int a,int b){
		return a / b;
	}
}