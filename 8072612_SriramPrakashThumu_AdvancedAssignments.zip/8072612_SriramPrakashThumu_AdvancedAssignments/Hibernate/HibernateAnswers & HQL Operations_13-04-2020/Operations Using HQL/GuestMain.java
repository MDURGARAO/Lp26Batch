package com.virtusa.test;


import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.virtusa.entities.Guest;

public class GuestMain {
	
	public static void main(String args[]) {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		//Insert
		
		Query query1 = session.createQuery("insert into Guest(name,email,password) select h.name,h.email,h.password from Guest as h where h.guestid = :guestId");
		query1.setParameter("guestId", new Scanner(System.in).nextInt());
		query1.executeUpdate();
		
		//Update
		
		Query query2 = session.createQuery("update Guest as g set g.name = :newName where g.guestid = :empId");
		query2.setParameter("newName", new Scanner(System.in).next());
		query2.setParameter("empId",new Scanner(System.in).nextInt());
		query2.executeUpdate();
		
		//Delete
		
		Query query3 = session.createQuery("delete from Guest as g where g.guestid = 6");
		query3.executeUpdate();
		
		//Select

		Query query4 = session.createQuery("select new Guest(g.guestid,g.name) from Guest as g");

		List<Guest> list = query4.list();
		list.stream().forEach(System.out::println);
		
		
		Query query5 = session.createQuery("select g from Guest as g");

		List<Guest> list1 = query4.list();
		list1.stream().forEach(System.out::println);
		
		
		session.getTransaction().commit();
		session.close();
	}

}
