package com.virtusa.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Passport {
	@Id
	private int passportNo;

	
	private String issuedLocation;
	
	public Passport() {
		super();
	}

	public Passport(int passportNo, String issuedLocation) {
		super();
		this.passportNo = passportNo;
		this.issuedLocation = issuedLocation;
	}

	public int getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(int passportNo) {
		this.passportNo = passportNo;
	}

	public String getIssuedLocation() {
		return issuedLocation;
	}

	public void setIssuedLocation(String issuedLocation) {
		this.issuedLocation = issuedLocation;
	}

	@Override
	public String toString() {
		return "Passport [passportNo=" + passportNo + ", issuedLocation=" + issuedLocation + "]";
	}

}
