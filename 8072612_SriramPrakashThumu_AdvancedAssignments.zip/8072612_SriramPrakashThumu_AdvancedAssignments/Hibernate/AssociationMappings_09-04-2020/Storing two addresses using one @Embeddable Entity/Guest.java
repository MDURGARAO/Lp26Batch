package com.virtusa.entities;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.virtusa.sub.Address;

@Entity
public class Guest {
	
	@Id
	@Column(name = "guestId")
	private int guestid;
	private String name;
	private String email;
	private Date dob;
	private String password;
	@Embedded
	private Address temp_address;
	
	@Embedded
	@AttributeOverride(name = "doorNo", column = @Column(name = "perm_doorNo"))
	@AttributeOverride(name = "street", column = @Column(name = "perm_street"))
	@AttributeOverride(name = "district", column = @Column(name = "perm_district"))
	@AttributeOverride(name = "state", column = @Column(name = "perm_state"))
	@AttributeOverride(name = "pincode", column = @Column(name = "perm_pincode"))
						
	private Address perm_address;
	
	public Guest() {
		super();
	}
	
	public Guest(int guestid, String name, String email, Date dob, String password, Address temp_address,Address perm_address) {
		super();
		this.guestid = guestid;
		this.name = name;
		this.email = email;
		this.dob = dob;
		this.password = password;
		this.temp_address = temp_address;
		this.perm_address = perm_address;
	}
	
	public int getGuestid() {
		return guestid;
	}
	
	public void setGuestid(int guestid) {
		this.guestid = guestid;
	} 
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public Date getDob() {
		return dob;
	}
	
	public void setDob(Date dob) {
		this.dob = dob;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Address getTemp_address() {
		return temp_address;
	}
	
	public void setTemp_address(Address temp_address) {
		this.temp_address = temp_address;
	}

	public Address getPerm_address() {
		return perm_address;
	}

	public void setPerm_address(Address perm_address) {
		this.perm_address = perm_address;
	}

	@Override
	public String toString() {
		return "Guest [guestid=" + guestid + ", name=" + name + ", email=" + email + ", dob=" + dob + ", password="
				+ password + ", temp_address=" + temp_address + ", perm_address=" + perm_address + "]";
	}
	
	
	
}
