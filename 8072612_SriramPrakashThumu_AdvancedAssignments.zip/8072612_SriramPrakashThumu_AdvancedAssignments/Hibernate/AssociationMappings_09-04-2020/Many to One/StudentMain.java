package com.virtusa.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entities.College;
import com.virtusa.entities.Student;

public class StudentMain {
	
	public static void main(String args[]) {
		
		College college = new College(98,"REC");
		
		Student student1 = new Student(156,"Sriram");
		Student student2 = new Student(157,"Prakash");
		
		
		student1.setCollege(college);
		student2.setCollege(college);
		
		
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		session.save(student1);
		session.save(student2);
		
		
		transaction.commit();
		session.close();
	}


}
