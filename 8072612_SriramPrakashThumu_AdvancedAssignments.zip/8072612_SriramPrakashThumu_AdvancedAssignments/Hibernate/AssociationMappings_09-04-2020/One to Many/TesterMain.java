package com.virtusa.test;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entities.Project;
import com.virtusa.entities.Tester;



public class TesterMain {
	
	public static void main(String args[]) {
	
		Set<Project> projectSet = new HashSet<>();
	
		Project project1 = new Project(123,"Amazon");
		Project project2 = new Project(124,"Google");
		Project project3 = new Project(125,"Microsoft");
		projectSet.add(project1);
		projectSet.add(project2);
		projectSet.add(project3);
		
		Tester tester = new Tester(101,"Prakash");
		tester.setProject(projectSet);
		
		
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		session.save(tester);
		
		
		transaction.commit();
		session.close();
	}

}
