package com.virtusa.test;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entities.Customer;
import com.virtusa.entities.Product;


public class CustomerMain {
	
	public static void main(String args[]) {
		
		Customer customer1 = new Customer(901,"Prakash");
		Customer customer2 = new Customer(902,"Sriram");
		
		Set<Customer> customers = new HashSet<>();
		customers.add(customer1);
		customers.add(customer2);
		
		Product product1 = new Product(501,"Laptop");
		Product product2 = new Product(502,"Mobile");
		
		Set<Product> products = new HashSet<>();
		products.add(product1);
		products.add(product2);
		
		customer1.setProducts(products);
		customer2.setProducts(products);
		
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		session.save(customer1);
		session.save(customer2);
		
		transaction.commit();
		session.close();
	}

}
