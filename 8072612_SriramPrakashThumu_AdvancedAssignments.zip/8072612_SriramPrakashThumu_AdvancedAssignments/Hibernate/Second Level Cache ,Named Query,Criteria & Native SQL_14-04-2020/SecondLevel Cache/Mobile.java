package com.virtusa.entities;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name = "mobiles")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class Mobile {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "mobileId")
	private int mobileid;
	
	@Column(name = "brand")
	private String brand;
	
	@Column(name = "price")
	private double price;

	public Mobile() {
		super();
	}

	public Mobile(int mobileid, String brand, double price) {
		super();
		this.mobileid = mobileid;
		this.brand = brand;
		this.price = price;
	}

	public int getMobileid() {
		return mobileid;
	}

	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Mobile [mobileid=" + mobileid + ", brand=" + brand + ", price=" + price + "]";
	}

}
