package com.virtusa.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.virtusa.entities.Mobile;

public class MobileMain {

	public static void main(String args[]) {

		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");

		SessionFactory sessionFactory = configuration.buildSessionFactory();

		Session session1 = sessionFactory.openSession();
		

		Mobile mobile1 = session1.get(Mobile.class,2);
		System.out.println(mobile1);
		
		session1.close();
		
		Session session2 = sessionFactory.openSession();

		Mobile mobile2 = session1.get(Mobile.class,2);
		System.out.println(mobile2);
		
		session2.close();
	}

}
