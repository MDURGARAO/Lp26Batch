package com.virtusa.test;

import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.virtusa.entities.Book;

public class BookMain {

	public static void main(String args[]) {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");

		SessionFactory sessionFactory = configuration.buildSessionFactory();

		Session session = sessionFactory.openSession();
		session.beginTransaction();

		Scanner scanner = new Scanner(System.in);
		
//		int n = scanner.nextInt();
//		
//		String sql = "select * from books where bookId = :bookID";
//		SQLQuery sqlQuery = session.createSQLQuery(sql);
//		sqlQuery.addEntity(Book.class);
//		sqlQuery.setParameter("bookID", n);
		
		
		TypedQuery query = session.getNamedQuery("findBookByName");
		
		query.setParameter("name","Java");
		
		List<Book> bookList = query.getResultList();
		bookList.stream().forEach(System.out::println);
		
		
		

		session.getTransaction().commit();
		session.close();
	}

}
