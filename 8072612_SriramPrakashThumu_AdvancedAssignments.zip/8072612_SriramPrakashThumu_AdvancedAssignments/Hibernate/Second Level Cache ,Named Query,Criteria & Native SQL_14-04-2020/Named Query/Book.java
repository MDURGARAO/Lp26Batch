package com.virtusa.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@NamedQueries ( {
	@NamedQuery(
			name = "findBookByName",
			query = "from Book b where b.bookName = :name"
			)
	
	
})




@Entity
@Table(name = "books")
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bookId")
	private int bookid;

	@Column(name = "name")
	private String bookName;

	@Column(name = "author")
	private String authorName;

	@Column(name = "price")
	private double price;

	public Book() {
		super();
	}

	public Book(int bookid, String bookName, String authorName, double price) {
		super();
		this.bookid = bookid;
		this.bookName = bookName;
		this.authorName = authorName;
		this.price = price;
	}

	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	@Override
	public String toString() {
		return "Book [bookid=" + bookid + ", bookName=" + bookName + ", authorName=" + authorName + ", price=" + price
				+ "]";
	}

}
