package com.virtusa.test;


import java.util.List;
import java.util.Scanner;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.PropertyProjection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;
import org.hibernate.query.Query;

import com.virtusa.entities.Guest;

public class GuestMain {
	
	public static void main(String args[]) {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		Scanner scanner = new Scanner(System.in);
		
		//String name = scanner.nextLine();
		
		//int value = scanner.nextInt();
		
		
		//SimpleExpression expression1 = Restrictions.eq("name", name);
		
		//SimpleExpression expression2 = Restrictions.ge("guestid", value);
		
		
		//LogicalExpression expression3 = Restrictions.and(expression1,expression2);
		
		//PropertyProjection property1 = Projections.property("name");
		
		ProjectionList projectionList = Projections.projectionList();
		
		projectionList.add(Projections.property("guestid"));
		projectionList.add(Projections.property("name"));
		projectionList.add(Projections.property("email"));
		projectionList.add(Projections.property("password"));
		
		
		Criteria criteria = session.createCriteria(Guest.class);
		
		//criteria.add(expression3);
		//criteria.addOrder(Order.desc("guestid"));
		
		//criteria.setProjection(property1);
		
		criteria.setProjection(projectionList);
		
		List<Object[]> guestList = criteria.list();
		//guestList.stream().forEach(System.out::println);
		
		for(Object[] o:guestList) {
			for(int i = 0;i < o.length;i++) {
				System.out.print(o[i] + " ");
			}
			System.out.println();
		}
		
		
		
		
		session.getTransaction().commit();
		session.close();
	}

}
