package com.virtusa.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Developer implements Serializable {
	@Id
	private int devId;
	private String devName;
	@Id
	private long phnNo;
	
	public Developer() {
		super();
	}
	
	public Developer(int devId, String devName, long phnNo) {
		super();
		this.devId = devId;
		this.devName = devName;
		this.phnNo = phnNo;
	}



	public int getDevId() {
		return devId;
	}
	public void setDevId(int devId) {
		this.devId = devId;
	}
	public String getDevName() {
		return devName;
	}
	public void setDevName(String devName) {
		this.devName = devName;
	}
	public long getPhnNo() {
		return phnNo;
	}
	public void setPhnNo(long phnNo) {
		this.phnNo = phnNo;
	}
	
	@Override
	public String toString() {
		return "Developer [devId=" + devId + ", devName=" + devName + ", phnNo=" + phnNo + "]";
	}
	
	
	

}
