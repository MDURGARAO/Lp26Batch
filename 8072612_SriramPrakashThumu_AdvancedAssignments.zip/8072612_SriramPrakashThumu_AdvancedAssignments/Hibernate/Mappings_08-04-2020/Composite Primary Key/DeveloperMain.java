package com.virtusa.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entities.Developer;

public class DeveloperMain {

	public static void main(String[] args) {
		
		Developer developer = new Developer(501,"Sriram",987654321);
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		
		session.save(developer);
			
		transaction.commit();
		session.close();

	}

}
