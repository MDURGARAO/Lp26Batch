package com.virtusa.test;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entities.Guest;
import com.virtusa.sub.Address;

public class GuestMain {
	
	
	public static void main(String args[]) {
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date d1 = null;
		
		try {
			
			d1 = simpleDateFormat.parse("1998-10-07");
		}
		catch (ParseException e) {
			
			e.printStackTrace();
		}
		
		Address address = new Address("9-62","Porur","Chennai","TamilNadu",600089);
		
		Guest guest = new Guest(101,"Prakash","prakash@gmail.com",d1,"prakash123",address);
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Transaction transaction = session.beginTransaction();
		
		session.save(guest);
		
		transaction.commit();
		
		session.close();
	}

}
