package com.virtusa.entities;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class Cheque extends Payment {
	@Column(name = "ChequeType")
	private String chequeType;

	public Cheque() {
		super();
	}

	public Cheque(String chequeType) {
		super();
		this.chequeType = chequeType;
	}

	public String getChequeType() {
		return chequeType;
	}

	public void setChequeType(String chequeType) {
		this.chequeType = chequeType;
	}

	@Override
	public String toString() {
		return "Cheque [chequeType=" + chequeType + "]";
	}
	

}
