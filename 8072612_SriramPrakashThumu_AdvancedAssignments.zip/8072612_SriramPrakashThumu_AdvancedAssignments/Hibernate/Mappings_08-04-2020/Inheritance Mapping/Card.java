package com.virtusa.entities;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class Card extends Payment {
	
	@Column(name = "CardType")
	private String cardType;

	public Card() {
		super();
	}

	public Card(String cardType) {
		super();
		this.cardType = cardType;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	@Override
	public String toString() {
		return "Card [cardType=" + cardType + "]";
	}

}
