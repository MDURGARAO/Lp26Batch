package com.virtusa.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.entities.Card;
import com.virtusa.entities.Cheque;
import com.virtusa.entities.Payment;

public class PaymentMain {
	
	public static void main(String args[]) {
		
		Payment payment = new Payment(10001,5000);
		Card card = new Card("MasterCard");
		Cheque cheque = new Cheque("SBI");   
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		session.save(payment);
		session.save(cheque);
		session.save(card);
		
		transaction.commit();
		session.close();
	}

}
