package association;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Course {
	@Id
	private int cId;
	private String courseName;
	@ManyToMany(mappedBy = "course")
	private List<Student> student;
	public int getcId() {
		return cId;
	}
	public void setcId(int cId) {
		this.cId = cId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	public List<Student> getStudent() {
		return student;
	}
	public void setStudent(List<Student> student) {
		this.student = student;
	}
	
	public Course(int cId, String courseName, List<Student> student) {
		super();
		this.cId = cId;
		this.courseName = courseName;
		this.student = student;
	}
	public Course() {
		
	}
	

}
