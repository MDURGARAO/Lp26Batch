package association;

import java.util.Arrays;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory = configuration.buildSessionFactory();
		Session session = buildSessionFactory.openSession();
		Transaction beginTransaction = session.beginTransaction();
//		for(int i = 0;i<10;i++) {
//			
//			Student student = new Student();
//			student.setRoolno(i);
//			student.setName("rahul");
//			Laptop laptop = new Laptop();
//			laptop.setStud(student);
//			laptop.setBrand("MI");
//			laptop.setLid(i);
//			Course course = new Course(i, "EEE", Arrays.asList(student));
//			student.setLaptop(laptop);
//			student.setCourse(Arrays.asList(course));
//			student.setLaptop(laptop);
//			session.save(laptop);
//			session.save(course);
//			session.save(student);
//			//session.save(mobile1);
//		}
		Student student = session.get(Student.class, 2);
		student.getCourse().get(1).setCourseName("ECE");
		session.saveOrUpdate(student);
		beginTransaction.commit();
		session.close();
	}

}
