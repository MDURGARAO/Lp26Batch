package association;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Mobile {
      private String brand;
      private String color;
      @Id
      private int imeiNumber;
      @ManyToOne()
      private Person person;
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	public Mobile(String brand, String color, int imeiNumber) {
		super();
		this.brand = brand;
		this.color = color;
		this.imeiNumber = imeiNumber;
	}
	public Mobile() {
		super();
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getImeiNumber() {
		return imeiNumber;
	}
	public void setImeiNumber(int imeiNumber) {
		this.imeiNumber = imeiNumber;
	}
      
}
