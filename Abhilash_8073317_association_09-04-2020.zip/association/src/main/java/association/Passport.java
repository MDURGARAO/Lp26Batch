package association;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Passport {
	@GeneratedValue
	@Id
   private int passportId;
   private Date issueDate;
   private String issuedLocation;
   @OneToOne
   private Person person;
   
public Person getPerson() {
	return person;
}
public void setPerson(Person person) {
	this.person = person;
}
public Passport(int passportId, Date issueDate, String issuedLocation) {
	super();
	this.passportId = passportId;
	this.issueDate = issueDate;
	this.issuedLocation = issuedLocation;
	
}
public Passport() {
	super();
}
public int getPassportId() {
	return passportId;
}
public void setPassportId(int passportId) {
	this.passportId = passportId;
}
public Date getIssueDate() {
	return issueDate;
}
public void setIssueDate(Date issueDate) {
	this.issueDate = issueDate;
}
public String getIssuedLocation() {
	return issuedLocation;
}
public void setIssuedLocation(String issuedLocation) {
	this.issuedLocation = issuedLocation;
}

   
   
}
