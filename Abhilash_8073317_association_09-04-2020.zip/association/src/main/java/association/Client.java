package association;

import java.util.Arrays;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {

	public static void main(String[] args) {
	    Person person = new Person(1, "vicky", "mumbai", 1231231234);
	    Mobile mobile1 = new Mobile("MI", "black", 121212);
	    mobile1.setPerson(person);
	    Mobile mobile2 = new Mobile("nokia", "blue", 232323);
	    mobile2.setPerson(person);
	    Passport passport = new Passport(1,new Date() , "mum");
	    passport.setPerson(person);
	    person.setPassport(passport);
	    person.setMobile(Arrays.asList(mobile1,mobile2));
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory buildSessionFactory = configuration.buildSessionFactory();
		Session session = buildSessionFactory.openSession();
		
		Transaction beginTransaction = session.beginTransaction();
		session.save(passport);
		session.save(mobile1);
		session.save(mobile2);
		session.save(person);
		beginTransaction.commit();
		session.close();

	}

}
